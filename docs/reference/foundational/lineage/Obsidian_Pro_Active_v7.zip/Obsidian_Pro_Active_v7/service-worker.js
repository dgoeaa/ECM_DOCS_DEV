/**
 * OBSIDIAN v4.2 — Unified Service Worker
 * Network-First Offline Shell Caching with selective bypasses.
 */
const VERSION = 'obsidian-v4.2-unified-fix2';
const SHELL = [
  '/', '/index.html',
  '/styles/layers.css', '/styles/reset.css', '/styles/primitives.css',
  '/styles/layout.css',
  '/styles/shell.css', '/styles/components.css', '/styles/utilities.css',
  '/themes/tokens.css', '/themes/theme.light.css', '/themes/theme.dark.css',
  '/themes/theme.high-contrast.css', '/themes/subbrand.dgo.css',
  '/config/i18n/en.json',
  '/core/boot.js', '/core/platform.js',
  '/shared/components/index.js', '/modules/index.js',
  // FIX-6: Added manifest and favicon — required for reliable PWA install and offline icon rendering
  '/manifest.webmanifest',
  '/assets/subbrands/dgo/favicon.svg'
];

self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(VERSION)
      .then((c) => c.addAll(SHELL))
      .catch(() => {})
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== VERSION).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  const url = new URL(req.url);
  if (req.method !== 'GET' || url.origin !== self.location.origin) return;
  e.respondWith(
    fetch(req)
      .then((res) => {
        if (res && res.ok && res.type === 'basic') {
          const copy = res.clone();
          caches.open(VERSION).then((c) => c.put(req, copy));
        }
        return res;
      })
      .catch(() => caches.match(req).then((hit) => hit || (req.mode === 'navigate' ? caches.match('/index.html') : Response.error())))
  );
});
