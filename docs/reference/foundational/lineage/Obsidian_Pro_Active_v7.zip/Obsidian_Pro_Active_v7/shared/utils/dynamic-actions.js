/** OBSIDIAN v4.2 — shared/utils/dynamic-actions.js (Remediated)
 *  The universal channel for any workflow action/function that has NO dedicated Power Automate flow.
 *  Enforces the Dynamic Global Actions Trigger Contract (v2.0.0) with custom simulated fallbacks.
 */
import { BaseService } from '../../core/base-service.js';
import { dynamicActionContract } from '../../config/dynamic-actions.config.js';

const APP_VERSION = '4.0';
const _dispatch = BaseService.endpoint('DYNAMIC_GLOBAL_ACTIONS', { expectedKeys: ['ok', 'data'] });

// Approved Simulation Layer for unprovisioned/unverified backend flows in sandbox environments
const SIMULATED_OUTCOMES = {
  dispatch: (payload) => ({
    ok: true,
    status: 200,
    data: {
      dispatchId: `SIM-DSP-${Date.now()}-${Math.random().toString(36).substring(2, 7).toUpperCase()}`,
      deliveredAt: new Date().toISOString(),
      recipient: payload.recipientAddress || "mailbox@nitda.gov.ng",
      message: "Simulation: Outbound dispatch completed successfully via dynamic actions relay."
    }
  }),
  archive: (payload) => ({
    ok: true,
    status: 200,
    data: {
      archiveId: `SIM-ARC-${Date.now()}`,
      archivedAt: new Date().toISOString(),
      retentionLease: payload.retentionLease || "10Y",
      message: "Simulation: Append-only archive snapshot successfully committed."
    }
  })
};

function requestId() {
  try { if (globalThis.crypto && globalThis.crypto.randomUUID) return globalThis.crypto.randomUUID(); } catch (_) {}
  return 'req-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
}

function currentUserEmail() {
  const P = globalThis.Platform;
  try { return (P && P.Persona && P.Persona.email && P.Persona.email()) || null; } catch (_) { return null; }
}

export const DynamicActions = {
  /** Low-level dispatch through the Dynamic Global Actions flow; awaits the normalized result. */
  async dispatch(action, fields = {}) {
    const { operation, mode, payload, ...rest } = fields;
    const contract = dynamicActionContract(action);
    
    // Contract validation: warn if a required payload field is missing.
    if (contract && Array.isArray(contract.required)) {
      const p = payload || {};
      const missing = contract.required.filter((k) => !(k in p) && !(k in rest));
      if (missing.length) { 
        const L = globalThis.Platform && globalThis.Platform.Log; 
        L && L.warn && L.warn('actions.contract-missing', { action, missing }); 
      }
    }

    // Remediated: Check if we should execute simulated responses in dev/test/sandbox profiles
    const P = globalThis.Platform;
    const env = P?.API?.getEnvironment?.() || 'prod';
    const useSimulation = env === 'dev' || env === 'test' || P?.Flags?.simulateFlows === true;

    if (useSimulation && SIMULATED_OUTCOMES[action]) {
      await new Promise(resolve => setTimeout(resolve, 800)); // Maintain visual loading feedback
      const mockRaw = SIMULATED_OUTCOMES[action](payload || {});
      return P?.API?.normalizeResponse ? P.API.normalizeResponse(mockRaw.data, {}, 800, fields.requestId || requestId(), 200) : mockRaw;
    }

    const now = new Date().toISOString();
    const envelope = {
      action,
      operation: operation || (contract && contract.operation) || 'dispatch',
      mode: mode || (contract && contract.mode) || 'single',
      userEmail: currentUserEmail(),
      requestId: requestId(),
      timestamp: now,
      client: { app: 'obsidian', version: APP_VERSION, submittedAt: now },
      ...(payload ? { payload } : {}),
      ...rest
    };
    return _dispatch(envelope);
  },

  /** Parse a normalized API result into a human-facing outcome. */
  describe(res) {
    if (!res) return { ok: false, kind: 'error', message: null, data: null };
    const data = res.data;
    const body = res.body || {};
    const raw =
      (data && (data.message || data.Message || data.result || data.status)) ||
      body.message || body.Message ||
      (Array.isArray(res.errors) && res.errors[0] && res.errors[0].message) || null;
    return { ok: !!res.ok, kind: res.kind || (res.ok ? 'ok' : 'error'), message: (typeof raw === 'string' && raw.trim()) ? raw.trim() : null, data: data || null };
  },

  /** Toast the parsed outcome of a flow response. */
  feedback(res, opts = {}) {
    const UI = globalThis.Platform && globalThis.Platform.UI;
    const d = DynamicActions.describe(res);
    if (!UI || !UI.toast) return d;
    if (d.ok) UI.toast({ messageKey: opts.successKey || 'flow.done', message: d.message || undefined, variant: 'success', vars: opts.vars });
    else UI.toast({ messageKey: 'flow.failed', message: d.message || undefined, variant: 'danger', vars: { kind: d.kind } });
    return d;
  },

  /** The canonical user-action runner: intermediary preview + confirmation → execute → parsed feedback. */
  async run(action, opts = {}) {
    const { preview, danger, successKey, vars, payload, ...fields } = opts;
    const contract = dynamicActionContract(action);
    const okKey = successKey || (contract && contract.successKey);
    const UI = globalThis.Platform && globalThis.Platform.UI;
    if (preview && UI && typeof UI.confirm === 'function') {
      const ok = await UI.confirm({
        titleKey: preview.titleKey || 'flow.confirmTitle',
        summaryKey: preview.summaryKey, summary: preview.summary,
        details: preview.details || [],
        confirmKey: preview.confirmKey || 'common.actions.confirm',
        danger: !!danger
      });
      if (!ok) return { ok: false, cancelled: true };
    }
    const res = await DynamicActions.dispatch(action, { payload, ...fields });
    DynamicActions.feedback(res, { successKey: okKey, vars });
    return res;
  },

  /** Fire-and-forget variant for optimistic UI transitions. */
  emit(action, fields = {}) {
    Promise.resolve()
      .then(() => DynamicActions.dispatch(action, fields))
      .then((res) => {
        const P = globalThis.Platform;
        const d = DynamicActions.describe(res);
        if (res && res.ok) {
          if (d.message && P && P.UI && P.UI.toast) P.UI.toast({ message: d.message, variant: 'info', timeout: 4000 });
          return;
        }
        if (P && P.UI && P.UI.toast) P.UI.toast({ messageKey: 'flow.syncFailed', message: d.message || undefined, variant: 'warning', vars: { action } });
        P && P.Log && P.Log.warn && P.Log.warn('actions.dispatch-failed', { action, kind: res && res.kind, ref: (fields && fields.ref) || null });
        P && P.Bus && P.Bus.emit && P.Bus.emit('audit:action-dispatch-failed', { action, ref: (fields && fields.ref) || null, ts: new Date().toISOString() });
      })
      .catch((e) => {
        const P = globalThis.Platform;
        P && P.Log && P.Log.warn && P.Log.warn('actions.dispatch-error', { action, message: String((e && e.message) || e) });
      });
  }
};

export default DynamicActions;