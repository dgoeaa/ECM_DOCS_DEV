/**
 * OBSIDIAN v4.2 — pf-dispatch-panel Component
 * Remediated: Re-aligned layout variables for complete mobile responsive boundaries.
 */
import { PfBaseElement } from './_base.js';

class PfDispatchPanel extends PfBaseElement {
  constructor() {
    super();
    this._ref = null;
    this._rec = null;
    this._status = '';
    this._directorate = null;
    this._recipient = null;
    this._channel = 'mailbox';
    this._busy = false;
  }

  set item(rec) { this._rec = (rec && typeof rec === 'object') ? rec : null; this._ref = this._rec && this._rec.__ref ? String(this._rec.__ref) : (this._ref || null); this._hydrate(); }
  get item() { return this._rec || null; }
  set reference(ref) { this._ref = ref ? String(ref) : null; this._hydrate(); }
  get reference() { return this._ref || null; }

  onConnect() {
    this.render(`
      <style>
        :host {
          display: block;
        }
        .wrap {
          background: var(--color-surface-raised);
          border: 1px solid var(--color-border);
          border-radius: var(--radius-md);
          padding: var(--space-4);
          box-sizing: border-box;
        }
        .head {
          display: flex;
          align-items: center;
          justify-content: space-between;
          flex-wrap: wrap;
          gap: var(--space-2);
          margin-bottom: var(--space-4);
        }
        .badge {
          padding: 2px var(--space-2);
          border-radius: var(--radius-pill);
          font-size: var(--size-caption);
          font-weight: var(--fw-semibold);
        }
        .grid {
          display: grid;
          gap: var(--space-3);
          grid-template-columns: 1fr;
        }
        @media (min-width: 600px) {
          .grid {
            grid-template-columns: 120px 1fr;
            align-items: center;
          }
        }
        .label {
          font-size: var(--size-caption);
          color: var(--color-text-muted);
          font-weight: var(--fw-semibold);
          text-transform: uppercase;
          letter-spacing: var(--tracking-overline);
        }
        .val {
          font-size: var(--size-body-sm);
          color: var(--color-text);
          word-break: break-all;
        }
        select.pf-input {
          min-height: 44px;
        }
        .actions {
          display: flex;
          gap: var(--space-2);
          flex-wrap: wrap;
          margin-top: var(--space-4);
          padding-top: var(--space-3);
          border-top: 1px dashed var(--color-border);
        }
        .actions .pf-btn {
          flex: 1 1 auto;
          min-width: 120px;
        }
      </style>
      <div class="wrap">
        <div class="head">
          <span class="pf-overline">${this.t('dispatch.panelTitle')}</span>
          <span class="badge" id="status-badge"></span>
        </div>
        <div class="grid">
          <span class="label">${this.t('dispatch.directorate')}</span>
          <span class="val" id="dir-val">—</span>
          
          <span class="label">${this.t('dispatch.channel')}</span>
          <select id="channel-sel" class="pf-input">
            <option value="mailbox">${this.t('dispatch.channelMailbox')}</option>
            <option value="head">${this.t('dispatch.channelHead')}</option>
          </select>
          
          <span class="label">${this.t('dispatch.recipient')}</span>
          <span class="val" id="recipient-val">—</span>
        </div>
        <div class="actions">
          <button class="pf-btn pf-btn--primary" id="send-btn">${this.t('dispatch.dispatchBtn')}</button>
          <button class="pf-btn pf-btn--ghost" id="nodispatch-btn">${this.t('dispatch.noDispatchBtn')}</button>
          <button class="pf-btn pf-btn--ghost" id="close-btn" hidden>${this.t('dispatch.closeBtn')}</button>
        </div>
      </div>
    `);

    this.on(this.$('#channel-sel'), 'change', (e) => {
      this._channel = e.target.value;
      this._resolveRecipient();
      this._reflect();
    });

    this.on(this.$('#send-btn'), 'click', () => this._dispatch());
    this.on(this.$('#nodispatch-btn'), 'click', () => this._noDispatch());
    this.on(this.$('#close-btn'), 'click', () => this._close());

    this._hydrate();
  }

  get _E() { return globalThis.Platform && globalThis.Platform.Entities; }
  get _by() { const P = globalThis.Platform && globalThis.Platform.Persona; return (P && typeof P.email === 'function') ? P.email() : null; }

  _hydrate() {
    if (!this.shadowRoot) return;
    let status = '', directorate = null;
    const E = this._E;
    if (E && this._ref && typeof E.byReference === 'function') {
      const b = E.byReference(this._ref);
      const ref = b && b.reference;
      status = String((ref && ref.status) || '');
      directorate = (ref && ref.__directorate) || null;
    }
    this._status = status;
    this._directorate = directorate;
    this._resolveRecipient();
    this._reflect();
  }

  _resolveRecipient() {
    const D = globalThis.Platform && globalThis.Platform.Directory;
    this._recipient = (D && this._directorate) ? D.recipientFor(this._directorate, { preferHead: this._channel === 'head' }) : null;
  }

  _reflect() {
    const DISPATCH_BADGE_CLASS = {
      approved: 'pending',
      'approved-with-edit': 'pending',
      'dispatch-pending': 'pending',
      'dispatch-in-flight': 'routed',
      dispatched: 'replied',
      'dispatch-failed': 'action',
      'no-dispatch': 'archived',
      'partial-dispatch': 'escalated',
      closed: 'archived'
    };

    const statusEl = this.$('#status-badge');
    if (statusEl) {
      const raw = this._status || 'dispatch-pending';
      const tone = DISPATCH_BADGE_CLASS[raw] || 'pending';
      statusEl.textContent = raw.replaceAll('-', ' ').toUpperCase();
      statusEl.className = `badge pf-badge pf-badge--${tone}`;
    }

    const dirEl = this.$('#dir-val'); if (dirEl) dirEl.textContent = this._directorate || '—';
    const recipEl = this.$('#recipient-val'); if (recipEl) recipEl.textContent = this._recipient || '—';

    const dispatchable = ['approved', 'approved-with-edit', 'dispatch-pending', 'dispatch-failed'].includes(this._status);
    const sendBtn = this.$('#send-btn'); if (sendBtn) sendBtn.disabled = !dispatchable || !this._recipient || this._busy;
    const noBtn = this.$('#nodispatch-btn'); if (noBtn) noBtn.disabled = !['dispatch-pending', 'approved', 'approved-with-edit'].includes(this._status) || this._busy;
    const closeBtn = this.$('#close-btn'); if (closeBtn) closeBtn.hidden = !['dispatched', 'no-dispatch', 'partial-dispatch'].includes(this._status);
  }

  async _dispatch() {
    if (this._busy) return;
    this._busy = true; this._reflect();
    
    const E = this._E;
    const res = E.transitionStatus(this._ref, this._status, 'dispatched', this._by);
    this._busy = false;
    
    if (res && res.ok) {
      this._status = 'dispatched';
      this._toast('dispatch.sent', 'success', { ref: this._ref });
      this.emit('pf-dispatch:dispatched', { ref: this._ref, recipient: this._recipient });
    } else {
      this._toast('dispatch.failed', 'danger');
    }
    this._reflect();
  }

  async _noDispatch() {
    const res = this._E.transitionStatus(this._ref, this._status, 'no-dispatch', this._by);
    if (res && res.ok) {
      this._status = 'no-dispatch';
      this._toast('dispatch.markedNoDispatch', 'info', { ref: this._ref });
    }
    this._reflect();
  }

  async _close() {
    const res = this._E.transitionStatus(this._ref, this._status, 'closed', this._by);
    if (res && res.ok) {
      this._status = 'closed';
      this._toast('dispatch.closed', 'success', { ref: this._ref });
      this.emit('pf-dispatch:closed', { ref: this._ref });
    }
    this._reflect();
  }

  _toast(messageKey, variant, vars) {
    globalThis.Platform?.UI?.toast?.({ messageKey, variant, vars });
  }
}
customElements.define('pf-dispatch-panel', PfDispatchPanel);
export default PfDispatchPanel;
