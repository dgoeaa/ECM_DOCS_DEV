/** OBSIDIAN v4.2 — Development Control Panel
 *  Conditional floating developer tool for sandbox environments. */
import { PfBaseElement } from './_base.js';

class PfDevToolbox extends PfBaseElement {
  onConnect() {
    this._expanded = false;
    this.draw();
    this._updateStats();
  }

  draw() {
    this.render(`
      <style>
        :host {
          position: fixed;
          bottom: var(--space-4, 16px);
          left: var(--space-4, 16px);
          z-index: 15000;
          font-family: var(--dgo-family-sans, system-ui);
        }
        .trigger {
          width: 48px;
          height: 48px;
          border-radius: 50%;
          background: var(--dgo-color-action-danger, #dc3545);
          color: #fff;
          box-shadow: var(--shadow-lg);
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: bold;
          font-size: 12px;
          border: 2px solid #fff;
          cursor: pointer;
          touch-action: manipulation;
        }
        .panel {
          display: none;
          position: absolute;
          bottom: 60px;
          left: 0;
          width: 280px;
          background: var(--dgo-color-surface-raised, #fff);
          border: 1px solid var(--dgo-color-border-default, #ccc);
          border-radius: var(--radius-md, 8px);
          box-shadow: var(--shadow-xl);
          padding: var(--space-4, 16px);
          flex-direction: column;
          gap: var(--space-3, 12px);
        }
        :host([expanded]) .panel {
          display: flex;
        }
        .title {
          margin: 0;
          font-size: 14px;
          font-weight: bold;
          text-transform: uppercase;
          color: var(--dgo-color-fg-strong, #111);
          border-bottom: 1px solid var(--dgo-color-border-default, #eee);
          padding-bottom: var(--space-2, 8px);
        }
        .btn-list {
          display: flex;
          flex-direction: column;
          gap: var(--space-2, 8px);
        }
        .dev-btn {
          width: 100%;
          text-align: left;
          padding: var(--space-2, 8px) var(--space-3, 12px);
          border: 1px solid var(--dgo-color-border-strong, #ccc);
          border-radius: var(--radius-sm, 4px);
          font-size: var(--size-body-sm, 13px);
          background: var(--dgo-color-surface, #fff);
          color: var(--dgo-color-fg-default, #333);
          cursor: pointer;
          display: flex;
          align-items: center;
          gap: var(--space-2);
          min-height: 44px; /* Touch-friendly boundary */
        }
        .dev-btn:hover {
          background: var(--dgo-color-surface-sunken);
        }
        .dev-btn--primary {
          background: var(--dgo-color-action-primary);
          color: var(--dgo-color-fg-on-brand);
          border-color: var(--dgo-color-action-primary);
        }
        .dev-btn--danger {
          background: var(--dgo-color-action-danger);
          color: var(--color-text-inverse);
          border-color: var(--dgo-color-action-danger);
        }
        .meta-text {
          font-size: 11px;
          color: var(--dgo-color-fg-muted);
          line-height: 1.4;
        }
      </style>
      <button class="trigger" id="toggle" type="button" aria-haspopup="dialog" aria-expanded="false">\ud83d\udee0\ufe0f</button>
      <div class="panel" id="panel" role="dialog">
        <h3 class="pf-overline" style="margin: 0;">Platform Cockpit HUD</h3>
        <div class="meta" id="telemetry-info"></div>
        <div class="actions">
          <button class="pf-btn pf-btn--ghost" id="resend-btn" style="width:100%;margin-bottom:8px;">\ud83d\udd04 Reload Data Fabric</button>
          <button class="pf-btn pf-btn--primary" id="verify-btn" style="width:100%;margin-bottom:8px;">\u2714\ufe0f Verify Verification Gate</button>
          <button class="pf-btn pf-btn--ghost" id="clear-storage-btn" style="width:100%;color:var(--dgo-color-action-danger)">\ud83d\uddd1\ufe0f Clear local Cache</button>
        </div>
      </div>
    `);

    this._toggle = this.$('#toggle');
    this._panel = this.$('#panel');

    this.on(this._toggle, 'click', () => this.toggle());
    this.on(this.$('#resend-btn'), 'click', () => this._softReload());
    this.on(this.$('#verify-btn'), 'click', () => this._verifyReset());
    this.on(this.$('#clear-storage-btn'), 'click', () => this._clearAllData());

    // Close when tapping outside the toolbox area
    this._outsideHandler = (e) => { if (!this.contains(e.target)) this.close(); };
    document.addEventListener('click', this._outsideHandler);
  }

  onDisconnect() {
    document.removeEventListener('click', this._outsideHandler);
  }

  toggle() {
    this._expanded = !this._expanded;
    this.toggleAttribute('expanded', this._expanded);
    this._toggle.setAttribute('aria-expanded', this._expanded ? 'true' : 'false');
    if (this._expanded) {
      this._updateStats();
    }
  }

  close() {
    this._expanded = false;
    this.removeAttribute('expanded');
    this._toggle.setAttribute('aria-expanded', 'false');
  }

  async _updateStats() {
    const statsBox = this.$('#telemetry-info');
    if (!statsBox) return;

    let swCount = 0;
    if ('serviceWorker' in navigator) {
      const regs = await navigator.serviceWorker.getRegistrations();
      swCount = regs.length;
    }

    const P = globalThis.Platform;
    const isOnline = navigator.onLine ? 'ONLINE' : 'OFFLINE';
    const storageInfo = P?.Storage?.getDiagnostics?.() || { percent: 0, level: 'ok' };

    statsBox.className = 'meta';
    statsBox.style.cssText = 'font-size:11px; color:var(--dgo-color-fg-muted); padding:10px; background:var(--dgo-color-surface-sunken); border-radius:6px; line-height:1.5;';
    statsBox.innerHTML = `
      <strong>Network Status:</strong> ${isOnline}<br>
      <strong>Active Service Workers:</strong> ${swCount}<br>
      <strong>Storage Pressure:</strong> ${storageInfo.percent}% [${storageInfo.level.toUpperCase()}]
    `;
  }

  _softReload() {
    sessionStorage.clear();
    globalThis.location.reload(true);
  }

  async _verifyReset() {
    sessionStorage.clear();
    if ('caches' in window) {
      const keys = await caches.keys();
      await Promise.all(keys.map(k => caches.delete(k)));
    }
    if ('serviceWorker' in navigator) {
      const regs = await navigator.serviceWorker.getRegistrations();
      await Promise.all(regs.map(r => r.unregister()));
    }
    globalThis.location.reload(true);
  }

  _clearAllData() {
    localStorage.clear();
    sessionStorage.clear();
    globalThis.location.reload(true);
  }
}

customElements.define('pf-dev-toolbox', PfDevToolbox);
export default PfDevToolbox;