import { PfBaseElement } from './_base.js';

class PfIdentityBox extends PfBaseElement {
  onConnect() {
    const P = globalThis.Platform;
    const user = P.Persona.profile() || { fullName: 'Guest', email: '---' };
    const persona = P.Persona.current();

    this.render(`
      <style>
        :host { display: block; }
        .box {
          background: var(--dgo-color-surface-sunken);
          border: 1px solid var(--dgo-color-border-default);
          border-radius: var(--dgo-radius-card);
          padding: var(--dgo-s-3);
          display: flex;
          align-items: center;
          gap: var(--dgo-s-3);
        }
        .avatar {
          width: 36px; height: 36px; border-radius: 50%;
          background: var(--dgo-color-action-primary);
          color: white; display: grid; place-items: center;
          font-weight: 800; font-size: 14px;
        }
        .details { flex: 1; min-width: 0; }
        .name { font-size: 13px; font-weight: 700; color: var(--dgo-color-fg-strong); display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .role { font-size: 10px; color: var(--dgo-color-fg-muted); text-transform: uppercase; font-weight: 600; }
        .status { font-size: 9px; color: var(--dgo-smart-500); font-weight: 700; display: flex; align-items: center; gap: 4px; }
        .dot { width: 6px; height: 6px; border-radius: 50%; background: var(--dgo-smart-500); animation: pulse 2s infinite; }
        @keyframes pulse { 0% { opacity: 1; } 50% { opacity: 0.4; } 100% { opacity: 1; } }
        /* AUDIT-FIX P25/IB-04: reduced-motion in shadow DOM */
        @media (prefers-reduced-motion: reduce) { .dot { animation: none !important; } }
      </style>
      <div class="box">
        <!-- AUDIT-FIX P25/IB-05: null-guard on fullName -->
        <div class="avatar">${(user.fullName || '??').substring(0, 2).toUpperCase()}</div>
        <div class="details">
          <span class="name">${user.fullName}</span>
          <span class="role">${persona.toUpperCase()} / ${user.dsuKey || 'DGO'}</span>
          <div class="status"><span class="dot"></span> ${this.t('identity.status')}: ${this.t('identity.connected')}</div>
        </div>
      </div>
    `);
  }
}
customElements.define('pf-identity-box', PfIdentityBox);
