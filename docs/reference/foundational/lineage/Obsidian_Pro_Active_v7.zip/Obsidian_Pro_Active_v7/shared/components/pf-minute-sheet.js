import { PfBaseElement } from './_base.js';

class PfMinuteSheet extends PfBaseElement {
  static attrs = ['reference'];

  set reference(v) { 
    this.setAttribute('reference', v); 
    this._refresh(); 
  }
  get reference() { return this.getAttribute('reference'); }

  onConnect() {
    /* AUDIT-FIX P07: token-driven surface; removed hex literals and skeuomorphic styling */
    this.render(`
      <style>
        :host { display: block; }
        .sheet {
          background: var(--color-surface-raised);
          border: 1px solid var(--color-border);
          border-left: 3px solid var(--dgo-color-action-primary);
          border-radius: var(--radius-lg);
          padding: var(--space-6);
          box-shadow: var(--shadow-sm);
          min-height: 400px;
          position: relative;
        }
        .entry {
          margin-bottom: var(--space-6);
          border-bottom: 1px dashed var(--color-border);
          padding-bottom: var(--space-4);
          position: relative;
        }
        .entry-header {
          font-family: var(--font-mono);
          font-size: var(--size-caption);
          color: var(--color-brand-primary);
          font-weight: var(--fw-bold);
          text-transform: uppercase;
          letter-spacing: var(--tracking-overline);
          margin-bottom: var(--space-2);
        }
        .entry-body {
          font-size: var(--size-body-sm);
          color: var(--color-text);
          white-space: pre-wrap;
          margin-bottom: var(--space-2);
          line-height: var(--lh-relaxed);
        }
        .entry-footer {
          display: flex;
          flex-direction: column;
          align-items: flex-end;
          font-size: var(--size-caption);
          color: var(--color-text-muted);
        }
        .sig { font-weight: var(--fw-semibold); color: var(--color-text); }
      </style>
      <div class="sheet" id="sheet-body" role="log" aria-label="Official minutes"></div>
    `);
    this._refresh();
  }

  _refresh() {
    const body = this.$('#sheet-body');
    if (!body || !this.reference) return;

    const entries = globalThis.Platform.AuditLog.forRef(this.reference);
    
    if (!entries.length) {
      /* AUDIT-FIX P07 (MS-06): DOM construction for empty state */
      const empty = document.createElement('div');
      empty.style.cssText = 'text-align:center;padding:var(--space-10) var(--space-4);color:var(--color-text-muted);';
      empty.textContent = 'No official minutes recorded for this reference.';
      body.textContent = '';
      body.append(empty);
      return;
    }

    /* AUDIT-FIX P07 (MS-05): XSS-safe DOM construction — no innerHTML for user content */
    body.textContent = '';
    entries.forEach((e, i) => {
      const entry = document.createElement('div');
      entry.className = 'entry';

      const header = document.createElement('div');
      header.className = 'entry-header';
      header.textContent = `Minute ${entries.length - i} — ${e.kind.replace(/-/g, ' ')}`;

      const bodyEl = document.createElement('div');
      bodyEl.className = 'entry-body';
      bodyEl.textContent = this._extractText(e);

      const footer = document.createElement('div');
      footer.className = 'entry-footer';

      const sig = document.createElement('span');
      sig.className = 'sig';
      sig.textContent = e.payload.userEmail || 'System';

      const ts = document.createElement('span');
      ts.textContent = globalThis.Platform.Format.dateTime(e.ts);

      footer.append(sig, ts);
      entry.append(header, bodyEl, footer);
      body.append(entry);
    });
  }

  _extractText(e) {
    return e.payload.comment || e.payload.notes || e.payload.reason || `Reference transitioned to ${e.payload.to || e.kind}`;
  }
}
customElements.define('pf-minute-sheet', PfMinuteSheet);
