/** OBSIDIAN v4.3 — pf-app-shell — FIX-BATCH-2
 *
 *  BUGS FIXED:
 *  1. SCROLL BROKEN — `.main` had both `overflow-y: auto` AND `max-height` set,
 *     but the banner slot was not accounted for in the height calc. On pages with
 *     the connectivity banner the content area was too short, causing double
 *     scroll bars. Fixed: use CSS custom property `--banner-h` (set by the banner
 *     component) and subtract it from the calc.
 *  2. RESPONSIVENESS — On screens between 600–900 px the nav overlay had no
 *     `max-height`, causing it to extend past the viewport on short screens.
 *  3. MISSING BANNER SLOT — The banner `<slot name="banner">` was placed inside
 *     the header div in the old version, causing z-index conflicts and making the
 *     banner scroll away with the header. Fixed: banner gets its own grid row.
 *  4. NAV HEIGHT CALC — Used `100vh` not `100dvh` in the fixed-position nav on
 *     mobile, causing the bottom to be clipped on iOS. Fixed with dvh fallback.
 *  5. FOOTER IN NAV GRID AREA — The `grid-template-areas` had footer sharing the
 *     nav column (`"nav footer"`), which prevented the footer from spanning full
 *     width. Fixed with a dedicated row.
 */
import { PfBaseElement } from './_base.js';

class PfAppShell extends PfBaseElement {
  onConnect() {
    this.render(`
      <style>
        :host {
          display: block;
        }
        .shell {
          display: grid;
          min-height: 100vh;
          min-height: 100dvh;
          /* banner row collapses to 0 when empty */
          grid-template-rows:
            var(--header-h, 64px)
            auto
            1fr
            auto;
          grid-template-columns: var(--nav-w, 260px) 1fr;
          grid-template-areas:
            "header  header"
            "banner  banner"
            "nav     main"
            "footer  footer";
          overflow: clip;
          box-sizing: border-box;
        }
        .header {
          grid-area: header;
          position: sticky;
          top: 0;
          z-index: var(--z-sticky);
          display: flex;
          align-items: center;
          padding-inline: var(--space-5);
          background: var(--color-surface-raised);
          border-bottom: 1px solid var(--color-border);
          box-shadow: var(--shadow-xs);
          box-sizing: border-box;
        }
        .banner {
          grid-area: banner;
          /* Banner component sets --banner-h via its own style so shell can react */
        }
        .nav {
          grid-area: nav;
          position: sticky;
          top: var(--header-h, 64px);
          align-self: start;
          /* FIX-1: account for banner height */
          height: calc(100vh - var(--header-h, 64px) - var(--banner-h, 0px));
          height: calc(100dvh - var(--header-h, 64px) - var(--banner-h, 0px));
          overflow-y: auto;
          overflow-x: hidden;
          background: var(--color-surface);
          border-right: 1px solid var(--color-border);
          padding: var(--space-4) var(--space-3);
          box-sizing: border-box;
        }
        .main {
          grid-area: main;
          padding: var(--space-6) var(--space-7);
          background: var(--color-surface-sunken);
          min-width: 0;
          max-width: 100%;
          /* FIX-1: account for banner height so only one scroll bar exists */
          overflow-y: auto;
          overflow-x: clip;
          overscroll-behavior-inline: contain;
          max-height: calc(100vh - var(--header-h, 64px) - var(--banner-h, 0px));
          max-height: calc(100dvh - var(--header-h, 64px) - var(--banner-h, 0px));
          box-sizing: border-box;
          scroll-behavior: smooth;
        }
        .footer {
          grid-area: footer;
          padding: var(--space-4) var(--space-7);
          background: var(--color-surface);
          border-top: 1px solid var(--color-border);
          color: var(--color-text-muted);
          font-size: var(--size-body-sm);
          box-sizing: border-box;
        }
        .scrim {
          display: none;
          position: fixed;
          inset: 0;
          background: rgba(0, 0, 0, 0.4);
          z-index: calc(var(--z-drawer) - 1);
          animation: fade-in var(--duration-fast) var(--easing-standard);
        }
        @keyframes fade-in {
          from { opacity: 0; }
          to   { opacity: 1; }
        }

        /* ---- Tablet / Mobile ---- */
        @media (max-width: 900px) {
          .shell {
            grid-template-columns: 1fr;
            grid-template-areas:
              "header"
              "banner"
              "main"
              "footer";
          }
          .nav {
            position: fixed;
            top: var(--header-h, 64px);
            bottom: 0;
            left: 0;
            width: min(80vw, 300px);
            /* FIX-4: dvh so iOS address bar doesn't clip nav bottom */
            height: calc(100vh - var(--header-h, 64px));
            height: calc(100dvh - var(--header-h, 64px));
            /* FIX-2: prevent overflow on short screens */
            max-height: calc(100vh - var(--header-h, 64px));
            max-height: calc(100dvh - var(--header-h, 64px));
            z-index: var(--z-drawer);
            transform: translateX(-105%);
            max-width: 100vw;
            transition: transform var(--duration-base) var(--easing-standard);
            border-right: 1px solid var(--color-border);
            box-shadow: var(--shadow-lg);
          }
          :host([nav-open]) .nav {
            transform: translateX(0);
          }
          :host([nav-open]) .scrim {
            display: block;
          }
          .main {
            /* On mobile the main area fills the viewport minus header + banner */
            max-height: calc(100vh - var(--header-h, 64px) - var(--banner-h, 0px));
            max-height: calc(100dvh - var(--header-h, 64px) - var(--banner-h, 0px));
          }
        }

        @media (max-width: 600px) {
          .header {
            padding-inline-start: max(var(--space-4), env(safe-area-inset-left));
            padding-inline-end:   max(var(--space-4), env(safe-area-inset-right));
          }
          .main {
            padding: var(--space-4);
          }
          .footer {
            padding: var(--space-4);
            padding-bottom: max(var(--space-4), env(safe-area-inset-bottom));
          }
        }
      </style>
      <div class="shell">
        <div class="header"><slot name="header"></slot></div>
        <div class="banner"><slot name="banner"></slot></div>
        <div class="scrim" id="scrim"></div>
        <div class="nav"><slot name="nav"></slot></div>
        <div class="main"><slot name="main"></slot></div>
        <div class="footer"><slot name="footer"></slot></div>
      </div>`);

    this.on(this.$('#scrim'), 'click', () => {
      this.removeAttribute('nav-open');
    });

    this.bus('platform:nav:toggle', () => {
      this.toggleAttribute('nav-open');
    });

    // Close drawer on any navigation
    this.bus('platform:nav:changed', () => {
      this.removeAttribute('nav-open');
    });

    // Observe banner slot so --banner-h stays in sync
    const bannerSlot = this.$('.banner');
    if (bannerSlot && typeof ResizeObserver !== 'undefined') {
      const ro = new ResizeObserver(() => {
        const h = bannerSlot.offsetHeight;
        this.style.setProperty('--banner-h', h + 'px');
      });
      ro.observe(bannerSlot);
    }
  }
}

customElements.define('pf-app-shell', PfAppShell);
export default PfAppShell;
