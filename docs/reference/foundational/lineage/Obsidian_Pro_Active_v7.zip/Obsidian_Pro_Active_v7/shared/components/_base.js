/** OBSIDIAN v4.3 — PfBaseElement (_base.js) — FIX-BATCH-2
 *
 *  BUGS FIXED:
 *  1. BUS LISTENERS NOT CLEANED UP — bus() stored disposer functions but
 *     _disposers was never flushed in disconnectedCallback, causing ghost
 *     listeners to accumulate each time a shadow element was unmounted and
 *     remounted (e.g. when the app-shell slot is re-rendered). Fixed.
 *  2. $$() RETURNED null WHEN SHADOW NOT READY — $$() (querySelectorAll) used
 *     Array.from(...) which threw if shadowRoot was null. Added null guard.
 *  3. render() CALLED MULTIPLE TIMES — Some components called render() on every
 *     bus event (e.g. pf-app-header). Each call replaced shadowRoot innerHTML,
 *     re-attaching all event listeners and leaking old ones. Added _rendered
 *     guard flag; components that need full re-render must call _invalidate().
 *  4. MISSING t() METHOD — Several components called this.t() before it was
 *     available if the element connected before Platform.I18n was ready.
 *     Added graceful fallback.
 */

const SHARED = new CSSStyleSheet();
SHARED.replaceSync(`
  :host {
    box-sizing: border-box;
    font-family: var(--font-body);
    color: var(--color-text);
  }
  *, *::before, *::after { box-sizing: border-box; }
  button, input, select, textarea { font: inherit; color: inherit; }
  button { background: none; border: none; cursor: pointer; }
  a { color: inherit; text-decoration: none; }
  :where(button, a, input, select, textarea, [tabindex]):focus-visible {
    outline: none;
    box-shadow: var(--dgo-focus-ring);
    border-radius: var(--radius-sm);
  }
  .pf-overline {
    font-size: var(--size-caption);
    text-transform: uppercase;
    letter-spacing: var(--tracking-overline);
    color: var(--color-text-muted);
    font-weight: var(--fw-semibold);
  }
  .pf-btn {
    display: inline-flex; align-items: center; justify-content: center;
    gap: var(--space-2); min-height: 44px; padding-inline: var(--space-4);
    border-radius: var(--radius-md); font-weight: var(--fw-semibold);
    font-size: var(--size-body-sm); border: 1px solid transparent;
    cursor: pointer; user-select: none;
  }
  .pf-btn--primary { background: var(--color-brand-primary); color: var(--color-text-inverse); }
  .pf-btn--ghost { color: var(--color-text); border-color: var(--color-border-strong); background: transparent; }
  .pf-badge, .badge {
    display: inline-flex; align-items: center; justify-content: center;
    padding: 2px var(--space-2); border-radius: var(--radius-pill);
    font-size: var(--size-caption); font-weight: var(--fw-semibold); white-space: nowrap;
  }
  .pf-badge--pending   { background: var(--dgo-color-status-pending-bg);   color: var(--dgo-color-status-pending-fg); }
  .pf-badge--routed    { background: var(--dgo-color-status-routed-bg);    color: var(--dgo-color-status-routed-fg); }
  .pf-badge--replied   { background: var(--dgo-color-status-replied-bg);   color: var(--dgo-color-status-replied-fg); }
  .pf-badge--action    { background: var(--dgo-color-status-action-bg);    color: var(--dgo-color-status-action-fg); }
  .pf-badge--draft     { background: var(--dgo-color-status-draft-bg);     color: var(--dgo-color-status-draft-fg); }
  .pf-badge--archived  { background: var(--dgo-color-status-archived-bg);  color: var(--dgo-color-status-archived-fg); }
  .pf-badge--escalated { background: var(--dgo-color-status-escalated-bg); color: var(--dgo-color-status-escalated-fg); }
  @media (pointer: coarse) {
    :where(button, a, [role="button"]) { min-height: 44px; }
  }
  /* AUDIT-FIX P05: reduced-motion inside Shadow DOM — reset.css does not pierce shadow roots */
  @media (prefers-reduced-motion: reduce) {
    *, *::before, *::after {
      animation-duration: 0.01ms !important;
      animation-iteration-count: 1 !important;
      transition-duration: 0.01ms !important;
    }
  }
`);

export class PfBaseElement extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
    this.shadowRoot.adoptedStyleSheets = [SHARED];
    this._disposers = [];
    this._rendered = false;
  }

  connectedCallback() {
    this.onConnect?.();
  }

  disconnectedCallback() {
    // FIX-1: flush all bus + DOM listeners on unmount
    this._flush();
    this.onDisconnect?.();
  }

  _flush() {
    const d = this._disposers;
    this._disposers = [];
    for (const fn of d) { try { fn(); } catch { /* ignore */ } }
    this._rendered = false;
  }

  /** Render shadow HTML. Idempotent by default; pass force=true to re-render. */
  render(html, force = false) {
    if (this._rendered && !force) return;
    this._rendered = true;
    this.shadowRoot.innerHTML = html;
  }

  /** Force a full re-render (use sparingly — prefer targeted DOM updates). */
  _invalidate(html) {
    this._flush();
    this.shadowRoot.innerHTML = html;
    this._rendered = true;
  }

  /** Scoped querySelector inside shadow root. */
  $(sel) {
    return this.shadowRoot?.querySelector(sel) ?? null;
  }

  /** Scoped querySelectorAll — always returns an Array. */
  $$(sel) {
    if (!this.shadowRoot) return [];
    return Array.from(this.shadowRoot.querySelectorAll(sel));
  }

  /** Add a DOM event listener and register cleanup. */
  on(el, type, fn, opts) {
    if (!el) return () => {};
    el.addEventListener(type, fn, opts);
    const off = () => el.removeEventListener(type, fn, opts);
    this._disposers.push(off);
    return off;
  }

  /** Subscribe to a Bus event and register cleanup. */
  bus(event, fn) {
    const Bus = globalThis.Platform?.Bus;
    if (!Bus) return () => {};
    const off = Bus.on(event, fn);
    if (typeof off === 'function') this._disposers.push(off);
    return off;
  }

  /** i18n shortcut with graceful fallback. FIX-4 */
  t(key, vars) {
    if (!key) return '';
    return globalThis.Platform?.I18n?.t?.(key, vars) ?? key;
  }
}

export default PfBaseElement;
