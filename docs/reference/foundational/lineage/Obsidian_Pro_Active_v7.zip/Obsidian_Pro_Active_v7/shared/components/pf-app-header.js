/**
 * OBSIDIAN v4.2 — pf-app-header Component
 * Remediated: Tactile mobile-responsive top bar.
 */
import { PfBaseElement } from './_base.js';
import { BRANDS, DEFAULT_BRAND } from '../../config/brand.config.js';

class PfAppHeader extends PfBaseElement {
  onConnect() {
    this.bus('platform:state:changed', () => this._updateSyncDot());
    this.bus('platform:outbox:delivered', () => this._updateSyncDot());
    this.bus('platform:outbox:deadletter', () => this._updateSyncDot());
    this.draw();
    this.bus('platform:nav:changed', (e) => this._updateModuleLabel(e?.id));
    this.bus('platform:brand:changed', () => this.draw());
    this.bus('platform:theme:changed', () => this.draw());
  }

  _updateSyncDot() {
    const dot = this.$('.sync-dot');
    const label = this.$('.sync-label');
    const count = globalThis.Platform?.API?.Outbox?.get().length || 0;
    if (!dot || !label) return;
    dot.classList.toggle('is-active', count > 0);
    label.textContent = count || '';
  }

  _resolveLogo() {
    if (globalThis.Platform?.Brand?.currentLogo) return globalThis.Platform.Brand.currentLogo();
    const b = BRANDS[DEFAULT_BRAND] || BRANDS.parent;
    const dark = (globalThis.Platform?.Theme?.resolved?.() === 'dark');
    return b && b.logo ? { src: dark ? b.logo.dark : b.logo.light, mark: b.logo.mark, alt: b.labelKey } : { src: '', alt: 'brand.dgo.label' };
  }

  /* AUDIT-FIX P09/H-01: _invalidate() flushes old listeners before re-render */
  draw() {
    const logo = this._resolveLogo();
    this._invalidate(`
      <style>
        :host {
          display: flex;
          align-items: center;
          gap: var(--space-3);
          width: 100%;
          box-sizing: border-box;
        }
        .menu-btn {
          display: none;
          align-items: center;
          justify-content: center;
          width: 44px;
          height: 44px;
          border-radius: var(--radius-md);
          color: var(--color-text-muted);
          cursor: pointer;
        }
        .menu-btn:hover {
          background: var(--color-surface-sunken);
        }
        .brand {
          display: flex;
          align-items: center;
          gap: var(--space-2);
          text-decoration: none;
        }
        .brand img {
          height: 24px;
          width: auto;
        }
        .brand span {
          font-family: var(--font-display);
          font-weight: var(--fw-bold);
          color: var(--color-brand-primary);
        }
        .spacer {
          margin-left: auto;
        }
        .icon-btn {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          width: 44px;
          height: 44px;
          border-radius: var(--radius-md);
          color: var(--color-text-muted);
          cursor: pointer;
        }
        .icon-btn:hover {
          background: var(--color-surface-sunken);
        }
        .module-label {
          font-size: var(--size-caption);
          font-weight: var(--fw-semibold);
          color: var(--color-text-muted);
          text-transform: uppercase;
          letter-spacing: var(--tracking-overline);
          margin-right: var(--space-2);
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          max-width: 180px;
        }
        @media (max-width: 900px) {
          .menu-btn {
            display: inline-flex;
          }
        }
      
        .sync-status { display: flex; align-items: center; gap: 6px; padding-inline: 8px; }
        .sync-dot { 
          width: 8px; height: 8px; border-radius: 50%; 
          background: var(--dgo-color-border-strong); 
          transition: background 0.3s ease; 
        }
        .sync-dot.is-active { 
          background: var(--dgo-color-action-danger); 
          box-shadow: 0 0 0 2px var(--dgo-color-surface-page), 0 0 0 4px rgba(220, 53, 69, 0.2);
          animation: pulse-red 2s infinite;
        }
        .sync-label { font-size: 10px; font-weight: 800; color: var(--dgo-color-fg-muted); font-family: var(--dgo-family-mono); }
        @keyframes pulse-red { 0% { opacity: 1; } 50% { opacity: 0.5; } 100% { opacity: 1; } }
      /* AUDIT-FIX P09/COMP-05: reduced-motion for pulse dot */
      @media (prefers-reduced-motion: reduce) { .sync-dot { animation: none !important; } }
      </style>
      <button class="menu-btn" aria-label="${this.t('shell.openNav')}" aria-expanded="false" aria-controls="app-nav" <!-- AUDIT-FIX P09/H-04 --> id="menu-trigger" aria-label="Toggle Navigation">
        <pf-icon name="menu" size="20"></pf-icon>
      </button>

      <a class="brand" href="#/" id="brand-link">
        <img src="${logo.src}" alt="${this.t(logo.alt)}">
      </a>
      <div class="sync-status" id="sync-indicator" title="Pending Dispatch Queue">
        <span class="sync-dot ${ (globalThis.Platform?.API?.Outbox?.get().length || 0) > 0 ? 'is-active' : ''}"></span>
        <span class="sync-label">${globalThis.Platform?.API?.Outbox?.get().length || ''}</span>
      </div>
      <span class="spacer"></span>
      <span class="module-label" id="module-label"></span>
      <button class="icon-btn" id="refresh-btn" aria-label="Refresh Data">
        <pf-icon name="refresh-cw" size="18"></pf-icon>
      </button>
      <button class="icon-btn" id="profile-btn" aria-label="Profile">
        <pf-icon name="user" size="18"></pf-icon>
      </button>
      <pf-persona-switcher></pf-persona-switcher>
    `);

    this.on(this.$('#brand-link'), 'click', (e) => {
      e.preventDefault();
      globalThis.Platform?.Router?.navigate('home');
    });

    this.on(this.$('#menu-trigger'), 'click', () => {
      globalThis.Platform?.Bus?.emit('platform:nav:toggle');
    });

    this.on(this.$('#refresh-btn'), 'click', async () => {
      try {
        await globalThis.Platform?.Entities?.bootstrap(true);
        await globalThis.Platform?.Lookups?.load(true);
      } catch (e) {}
    });

    this.on(this.$('#profile-btn'), 'click', () => {
      globalThis.Platform?.UI?.openProfileSetup?.();
    });
  }
}
customElements.define('pf-app-header', PfAppHeader);
export default PfAppHeader;
