/** OBSIDIAN v4.3 — <pf-app-nav> — FIX-BATCH-2
 *
 *  BUGS FIXED:
 *  1. NAV ITEMS CLIPPED BY MASK — The scroll-fade mask covered the last nav item
 *     at certain window heights. Fixed: mask is now applied only when content
 *     actually overflows; a ResizeObserver toggles the mask class.
 *  2. UTILITY ACTIONS APPENDED OUTSIDE SHADOW ROOT — utils div was created with
 *     `document.createElement` and appended with `nav.after()`, putting it in the
 *     light DOM where shadow styles had no effect. Fixed: utils live inside the
 *     shadow nav container.
 *  3. NAV SCROLL BROKEN ON MOBILE — `.nav-utils` rendered outside shadow clipped
 *     the scroll container on mobile. Now it's inside and styled correctly.
 *  4. PAINT CALLED BEFORE SHADOW ROOT READY — If `platform:nav:rebuilt` fires
 *     during connectedCallback before render() completes, paint() was a no-op.
 *     Fixed: model is buffered and painted after render completes.
 */
import { PfBaseElement } from './_base.js';

class PfAppNav extends PfBaseElement {
  onConnect() {
    this.render(`
      <style>
        :host { display: block; overflow: hidden; }
        .nav-scroll {
          display: flex;
          flex-direction: column;
          height: 100%;
          overflow-y: auto;
          overflow-x: hidden;
          overscroll-behavior: contain;
          padding-bottom: var(--space-4);
          box-sizing: border-box;
        }
        nav {
          display: flex;
          flex-direction: column;
          gap: var(--space-5);
          flex: 1 0 auto;
        }
        .group__title {
          font-size: var(--size-caption);
          text-transform: uppercase;
          letter-spacing: var(--tracking-overline);
          color: var(--color-text-muted);
          font-weight: var(--fw-semibold);
          padding: 0 var(--space-3);
          margin-bottom: var(--space-2);
        }
        ul { list-style: none; display: flex; flex-direction: column; gap: 2px; }
        a {
          display: flex;
          align-items: center;
          gap: var(--space-3);
          padding: var(--space-2) var(--space-3);
          border-radius: var(--radius-md);
          color: var(--color-text);
          font-size: var(--size-body-sm);
          font-weight: var(--fw-medium);
          transition: background var(--duration-fast) var(--easing-standard);
          min-height: 36px;
        }
        a:hover { background: var(--color-surface-sunken); }
        a[aria-current="page"] {
          background: var(--color-brand-primary);
          color: var(--color-text-inverse);
        }
        a[aria-current="page"] pf-icon { color: var(--color-text-inverse); }
        .badge {
          margin-left: auto;
          min-width: 18px;
          height: 18px;
          padding: 0 5px;
          border-radius: var(--radius-pill);
          background: var(--color-brand-accent);
          color: var(--color-text-inverse);
          font-size: var(--size-caption);
          display: inline-grid;
          place-items: center;
        }
        .dep { margin-left: auto; font-size: var(--size-caption); color: var(--color-warning); }
        @media (pointer: coarse) { a { min-height: 44px; } }

        /* Scroll-fade: only applied via JS when content actually overflows */
        .nav-scroll.has-overflow {
          -webkit-mask-image: linear-gradient(to bottom, black calc(100% - 48px), transparent 100%);
          mask-image: linear-gradient(to bottom, black calc(100% - 48px), transparent 100%);
        }

        /* Utility actions live INSIDE the scroll container */
        .nav-utils {
          display: flex;
          flex-direction: column;
          gap: 2px;
          margin-top: var(--space-4);
          padding-top: var(--space-4);
          border-top: 1px solid var(--color-border);
          flex-shrink: 0;
        }
        .nav-utils button {
          display: flex;
          align-items: center;
          gap: var(--space-3);
          padding: var(--space-2) var(--space-3);
          border-radius: var(--radius-md);
          color: var(--color-text-muted);
          font-size: var(--size-body-sm);
          font-weight: var(--fw-medium);
          width: 100%;
          background: none;
          border: none;
          cursor: pointer;
          transition: background var(--duration-fast) var(--easing-standard);
          min-height: 36px;
        }
        .nav-utils button:hover { background: var(--color-surface-sunken); color: var(--color-text); }
        @media (pointer: coarse) { .nav-utils button { min-height: 44px; } }
      </style>
      <div class="nav-scroll" id="scroll-wrap">
        <nav aria-label="${this.t('shell.nav.aria')}"></nav>
        <div class="nav-utils" id="nav-utils"></div>
      </div>`);

    // FIX-4: paint any model that arrived before render finished
    this.bus('platform:nav:rebuilt', (m) => this.paint(m));
    const model = globalThis.Platform?.Nav?.model?.();
    if (model) this.paint(model);

    this.on(this.$('nav'), 'keydown', (e) => this.onKey(e));

    // FIX-1: Overflow-aware mask toggle
    const wrap = this.$('#scroll-wrap');
    if (wrap && typeof ResizeObserver !== 'undefined') {
      const ro = new ResizeObserver(() => {
        const overflows = wrap.scrollHeight > wrap.clientHeight + 4;
        wrap.classList.toggle('has-overflow', overflows);
      });
      ro.observe(wrap);
      this._disposers = this._disposers || [];
      this._disposers.push(() => ro.disconnect());
    }
  }

  paint(model) {
    const nav = this.$('nav');
    const utils = this.$('#nav-utils');
    if (!nav || !utils) return;

    // Full rebuild only when group structure changes; targeted aria-current toggle otherwise
    const newGroupSig = (model.groups || []).map((g) =>
      g.id + ':' + g.items.map((i) => i.id).join(',')
    ).join('|');

    if (this._groupSig !== newGroupSig) {
      this._groupSig = newGroupSig;
      nav.innerHTML = (model.groups || []).map((g) => `
        <div class="group">
          <div class="group__title">${this.t(g.labelKey)}</div>
          <ul role="list">${g.items.map((it) => `
            <li><a href="#/${it.id}" ${it.active ? 'aria-current="page"' : ''}>
              ${it.icon ? `<pf-icon name="${it.icon}"></pf-icon>` : ''}
              <span>${this.t(it.labelKey)}</span>
              ${it.badge ? `<span class="badge">${it.badge}</span>` : ''}
              ${it.status === 'deprecated' ? `<span class="dep">${this.t('nav.badge.deprecated')}</span>` : ''}
            </a></li>`).join('')}</ul>
        </div>`).join('');
    } else {
      // Group structure unchanged: only toggle aria-current on affected links
      const allLinks = this.$$('a');
      const activeItemId = model.activeId;
      allLinks.forEach((a) => {
        const linkId = (a.getAttribute('href') || '').replace(/^#\//, '');
        if (linkId === activeItemId) a.setAttribute('aria-current', 'page');
        else a.removeAttribute('aria-current');
      });
    }

    // FIX-2 & FIX-3: Utility actions rendered INSIDE shadow root
    utils.innerHTML = '';
    (model.utils || []).forEach((u) => {
      if (u.component) return; // persona switcher is in header
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.setAttribute('aria-label', this.t(u.labelKey));
      btn.innerHTML = `${u.icon ? `<pf-icon name="${u.icon}"></pf-icon>` : ''}<span>${this.t(u.labelKey)}</span>`;
      btn.addEventListener('click', () => {
        if (u.event) globalThis.Platform?.Bus?.emit(u.event);
      });
      utils.append(btn);
    });
  }

  onKey(e) {
    const links = this.$$('a');
    const i = links.indexOf(this.shadowRoot.activeElement);
    if (e.key === 'ArrowDown') { e.preventDefault(); links[Math.min(i + 1, links.length - 1)]?.focus(); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); links[Math.max(i - 1, 0)]?.focus(); }
    else if (e.key === 'Home') { e.preventDefault(); links[0]?.focus(); }
    else if (e.key === 'End') { e.preventDefault(); links[links.length - 1]?.focus(); }
  }
}

customElements.define('pf-app-nav', PfAppNav);
export default PfAppNav;
