/** OBSIDIAN v4.0 — tools/ui-smoke.mjs · REAL-BROWSER smoke for the single-assignment surface.
 *  Serves platform-root, mocks the two data flows (REFERENCE_DATA 'lookups' + FETCH_ALL 'fetchAll'),
 *  drives the form in Chromium (Playwright), and asserts the things static gates can't: the dropdowns
 *  actually populate and the category cascade reflects into the assignee picker + priority chips. */
