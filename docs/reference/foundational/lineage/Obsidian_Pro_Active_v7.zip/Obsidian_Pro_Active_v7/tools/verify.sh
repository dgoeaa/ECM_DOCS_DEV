#!/usr/bin/env bash
# OBSIDIAN v4 — static verification gate. Run from platform-root: bash tools/verify.sh
# Exits 0 only if every lock passes. Requires: python3, node.
set -u
cd "$(dirname "$0")/.." || exit 2
fail=0
say(){ printf '%-34s %s\n' "$1" "$2"; }
