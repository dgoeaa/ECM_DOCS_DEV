import time
from datetime import datetime

# Generate fresh dev build coordinates
timestamp = int(time.time())
date_str = datetime.now().strftime("%Y-%m-%d")
build_id = f"DEV-{timestamp}"

content = f"""/** OBSIDIAN v4.0 — config/build-info.js · generated build marker */
export const BUILD_INFO = {{ id: '{build_id}', date: '{date_str}' }};
export default BUILD_INFO;
"""

try:
    with open("config/build-info.js", "w", encoding="utf-8", newline="\n") as f:
        f.write(content)
    print(f"Build ID bumped to: {build_id}")
except Exception as e:
    print(f"Error writing build-info: {e}")