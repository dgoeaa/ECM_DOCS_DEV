#!/bin/bash
# Generates a fresh build ID and date stamp
TIMESTAMP=$(date +%s)
DATE_STR=$(date +%Y-%m-%d)
BUILD_ID="DEV-$TIMESTAMP"

cat << EOF > config/build-info.js
/** OBSIDIAN v4.0 — config/build-info.js · generated build marker */
export const BUILD_INFO = { id: '$BUILD_ID', date: '$DATE_STR' };
export default BUILD_INFO;
EOF

echo "Build ID bumped to: $BUILD_ID"