#!/usr/bin/env node
/** OBSIDIAN v4.0 — boot smoke test (zero deps).
 *  Stubs JUST enough browser globals to let _base.js, the components, and every module
 *  index.js load in Node, then verifies module registration + nav IA invariants.
 *  Catches component-init regressions that node --check (syntax only) misses. */
