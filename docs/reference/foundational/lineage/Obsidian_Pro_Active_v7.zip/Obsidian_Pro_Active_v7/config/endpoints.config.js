/**
 * OBSIDIAN v4.2 — Secure Direct Power Automate Endpoints
 * Consolidated active endpoints only.
 */
const ENV = 'https://defaultca6a4b3f912349bcbcb927085ebbf1.a1.environment.api.powerplatform.com:443';
const dec = (s) => {
  const str = String(s || '').trim();
  if (str.length === 43 && !str.endsWith('=')) {
    return str;
  }
  try {
    const normalized = str.replace(/-/g, '+').replace(/_/g, '/');
    return atob(normalized.padEnd(Math.ceil(normalized.length / 4) * 4, '='));
  } catch (_) {
    return str;
  }
};

const PATH = (wf, sig) =>
  `${ENV}/powerautomate/automations/direct/workflows/${wf}/triggers/manual/paths/invoke` +
  `?api-version=1&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=${dec(sig)}`;

const JSON_HEADERS = { 'Content-Type': 'application/json' };
const SOURCE = 'DGO_FAST_Track_WEB_OPS';

export const Endpoints = {
  GET_DOCS: {
    url: PATH('7995c1eb50d94d5daa2780e71391d874', 'Rzl0aTAtZnpWUnd0OGZkR0doZU5nU3J2SW9NQ0NYS0VpYkNhQmRjaTRvRQ=='),
    method: 'POST', headers: JSON_HEADERS, family: 'F1', envelope: 'v1', flowName: 'GET_DOCS_OPS_2',
    defaults: { action: 'getDocs', operation: 'read', mode: 'read', source: SOURCE }, expectedKeys: ['ok', 'data']
  },
  AI_EMAIL_ANALYSIS: {
    url: PATH('fe794e0139784ac694768e5a716e0be7', 'bEQ3NkNUQU1yNzdXY0lwbVpDeDdYcXYxMC02aHliRUI2aWVGZXdET3Qyaw=='),
    method: 'POST', headers: JSON_HEADERS, family: 'F5', envelope: 'v1', flowName: 'AI_Assisted_Email_Analysis',
    defaults: { action: 'aiAnalyseEmail', operation: 'analyse', mode: 'single', source: SOURCE }, requires: ['emailId'], expectedKeys: ['ok', 'data'], timeoutMs: 90000
  },
  DYNAMIC_GLOBAL_ACTIONS: {
    url: PATH('bc83d98acf474a088832d78f50085388', 'X0NvLXIzVEc2cnRQMHlHRERKWElNOTBXRDRXcHltMk5tUjVPeU9Tc2duWQ=='),
    method: 'POST', headers: JSON_HEADERS, family: 'F7', envelope: 'v1', flowName: 'Dynamic_Global_Actions',
    defaults: { action: 'dynamicGlobalAction', operation: 'dispatch', mode: 'single', source: SOURCE }, expectedKeys: ['ok', 'data']
  },
  FETCH_EMAIL_ATTACHMENTS: {
    url: PATH('20e6340941ce4b1bbb87b43c9102a777', 'YW9ETlJWanZHcFVXR3EyekI3SDVKRzEweFFURUZoRkx0MVBUeG1wQ1g2WT0='),
    method: 'POST', headers: JSON_HEADERS, family: 'F1', envelope: 'v1', flowName: 'Fech_Email Attachments',
    defaults: { action: 'fetchEmailAttachments', operation: 'read', mode: 'read', source: SOURCE }, expectedKeys: ['ok', 'data']
  },
  REFERENCE_DATA: {
    url: PATH('ff455c68e9ac493e858fb984bcfd01fb', 'amFqRlZ4YnY2N0hiY0txdlY4aDZKQlBtOVRPGjYweURuaFJqeTlXbXBQVT0='),
    method: 'POST', headers: JSON_HEADERS, family: 'F1', envelope: 'v1', flowName: 'Get_All_Reference_Data_POST',
    defaults: { action: 'lookups', operation: 'read', mode: 'read', source: SOURCE }, expectedKeys: ['ok']
  },
  AI_DOC_ANALYSIS: {
    url: PATH('20e3b003a57f47febae8a24ad5b9acd4', 'TVPVBWHGec5Yt7oY_jtUyIIF4yQdkZgFrxy3oCNG0pk'),
    method: 'POST', headers: JSON_HEADERS, family: 'F5', envelope: 'v1', flowName: 'AI_Assisted_Event Related_Document_Analysis_Processing',
    sharesWorkflowWith: 'REFERENCE_DATA',
    defaults: { action: 'aiAnalyseEventDocs', operation: 'analyse', mode: 'batch', source: SOURCE }, expectedKeys: ['ok', 'data'], timeoutMs: 90000
  },
  OTP_GENERATE: {
    url: PATH('314aaf27593147089b38322e5ca25936', 'OWBIO1ooq0y8Zh9BTPp3sBOQoyVWs_a463FhFUT66fU'),
    method: 'POST', headers: JSON_HEADERS, family: 'F6', envelope: 'v1', flowName: 'OTP Generate',
    defaults: { action: 'otpGenerate', operation: 'generate', mode: 'single', source: SOURCE }, expectedKeys: ['ok', 'data']
  },
  OTP_VERIFY: {
    url: PATH('43879c5165de439680055ab4258b3f27', 'zO21cB8Gn-LDklvld-xWtGUuZDvCleHWR6j5N6s5Dyo'),
    method: 'POST', headers: JSON_HEADERS, family: 'F6', envelope: 'v1', flowName: 'OTP Verify',
    defaults: { action: 'otpVerify', operation: 'verify', mode: 'single', source: SOURCE }, expectedKeys: ['ok', 'data']
  },
  AI_CHAT: {
    url: PATH('a13c8b577bd44f8787c50d095ea3faf9', 'gtXPGBgn00fpw7ORkWQvzaNNQ8qwSHUahBodUv7AyX8'),
    method: 'POST', headers: JSON_HEADERS, family: 'F5', envelope: 'v1', flowName: 'AI_Chat',
    defaults: { action: 'aiChat', operation: 'respond', mode: 'single', source: SOURCE }, expectedKeys: ['ok', 'data'], timeoutMs: 90000
  },
  FETCH_ALL: {
    url: PATH('2d576af599c0421eb37213634b85fc4b', '0HojCcv8dTygZpw8G1aCf6bVoZnSc4NgN2raNRaQPUk'),
    method: 'POST', headers: JSON_HEADERS, family: 'F1', envelope: 'v1', flowName: 'Fetch_All_Data_&_References-POST',
    defaults: { action: 'fetchAll', operation: 'read', mode: 'read', source: SOURCE }, expectedKeys: ['ok', 'data'], timeoutMs: 90000
  },
  BULK_ASSIGNMENT: {
    url: PATH('1154b50e1d17420dadb3b012e7e2a02c', 'Swbi7nJCn3-VSSz4KN1YxHfxFPfO-EUWsF-czBS3zs4'),
    method: 'POST', headers: JSON_HEADERS, family: 'F3', envelope: 'v1', flowName: 'Docoument_Bulk_Task_Assignment_Create',
    defaults: { action: 'bulkassignment', operation: 'create', mode: 'bulk', source: SOURCE }, expectedKeys: ['ok', 'data'], timeoutMs: 90000
  },
  BULK_ASSIGNMENT_DIRECT: {
    url: PATH('7e71fffe770a45ccb93bf216bb53786e', 'RtvNxwUI6kgsyM0rTjfV6b60OsCvmmJCyFqhb4L96NE'),
    method: 'POST', headers: JSON_HEADERS, family: 'F3', envelope: 'v1', flowName: 'Docoument_Bulk_Task_Assignment_Create_Direct',
    defaults: { action: 'bulkassignment', operation: 'create', mode: 'bulk', source: SOURCE }, expectedKeys: ['ok', 'data'], timeoutMs: 90000
  },
  SINGLE_ASSIGNMENT: {
    url: PATH('6b3bad3005b44bf6bced0f8074d3f2ed', '1kJge9P2IOMOLRZOK-cVb3bcDJbuDhbR8x9h0TvHspQ'),
    method: 'POST', headers: JSON_HEADERS, family: 'F2', envelope: 'v1', flowName: 'Docoument_Single_Task_Assignment_Create',
    defaults: { action: 'singleassignment', operation: 'create', mode: 'single', source: SOURCE }, expectedKeys: ['ok', 'data']
  },
  SUBSIDIARY_ACTIONS: {
    url: PATH('85c556f10b8244ba9d839a2ebe240b91', '8ikbMhXrOn_L4QRUBF94wiq2swh7GlNVY_GZ5BD5jK0'),
    method: 'POST', headers: JSON_HEADERS, family: 'F4', envelope: 'v4', flowName: 'Subsidiary_Actions',
    routeKeys: ['INIT', 'REFRESH_EMAILS', 'LOAD_EMAIL_DETAILS', 'AI_ANALYSE_EMAIL', 'CREATE_TASK',
      'UPDATE_TASK', 'LOAD_EVENT_INFO', 'AI_CHAT', 'TRACK', 'ACKNOWLEDGE', 'GET_ALL', 'GET_BOOTSTRAP',
      'LISTDOCS', 'GETDOC', 'BULKASSIGN', 'CREATESUPPORTREQUEST', 'GETREFERENCES', 'LIST-ACTIVITIES'],
    defaults: { action: 'INIT', operation: 'init', mode: 'switch', source: SOURCE }, expectedKeys: ['ok', 'data'], timeoutMs: 90000
  },
  EMAIL_RELATED_TASK: {
    url: PATH('a942d230337c4ddfa9a386e92bbd048b', 'S0FJdG5tZ2N6VVVFRGtkSlRRdmhCYlBUWjNJQjhwYVBQTXF6MEE3VQ=='),
    method: 'POST', headers: JSON_HEADERS, family: 'F2', envelope: 'v1', flowName: 'Email_Related_Task_Create',
    defaults: { action: 'emailtotaskassignment', operation: 'createTaskFromEmail', mode: 'single', source: SOURCE }, expectedKeys: ['ok', 'data']
  }
};
export const ENDPOINT_KEYS = Object.keys(Endpoints);
export const ACTIVE_ENDPOINT_KEYS = ENDPOINT_KEYS.slice();