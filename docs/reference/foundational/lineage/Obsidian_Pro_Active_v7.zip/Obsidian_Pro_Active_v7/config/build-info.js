/** OBSIDIAN v4.0 — config/build-info.js · generated build marker */
export const BUILD_INFO = { id: 'DEV-1782365336', date: '2026-06-25' };
export default BUILD_INFO;
