# OBSIDIAN Platform — Audit Remediation Patch Manifest
Generated: 2026-06-26 18:16:03

## Summary
| Category | Count |
|---|---|
| Patches applied (file modified) | 25 |
| Patches unchanged (already correct) | 0 |
| Files not found in snapshot | 0 |
| Errors | 0 |

## Patch Detail
| ID | File | Status | Description |
|---|---|---|---|
| P01 | `themes/tokens.css` | PATCHED | Add missing z-palette, fw-medium, size-body-md, banner-h; fix dgo-cat-2 and ease-entrance; add motion/duration aliases |
| P02 | `themes/theme.dark.css` | PATCHED | Add dark-mode bridge overrides: brand-primary accent, shadow depth, focus ring |
| P03 | `themes/theme.high-contrast.css` | PATCHED | Add HC bridge overrides: brand-primary, border, shadow elimination, focus ring |
| P04 | `index.html` | PATCHED | HC stylesheet unconditional load; FOUC-prevention theme script; dev-toolbox guard comment |
| P05 | `shared/components/_base.js` | PATCHED | Add prefers-reduced-motion to SHARED CSSStyleSheet — propagates to all 24 pf-* components |
| P06 | `shared/components/pf-skip-link.js` | PATCHED | Fix skip-link href="#main" to href="#module-outlet" (WCAG 2.4.1 / A11Y-02) |
| P07 | `shared/components/pf-minute-sheet.js` | PATCHED | Remove hex literals; token-driven surface; XSS-safe DOM construction in _refresh() (EX-03, MS-01, MS-02, MS-05) |
| P08 | `shared/components/pf-modal.js` | PATCHED | Add trapFocus + focusFirst on modal open (M-03 / WCAG 2.1.2 No Keyboard Trap) |
| P09 | `shared/components/pf-app-header.js` | PATCHED | Fix draw() listener leak; add menu-btn aria; add reduced-motion for pulse animation (H-01, H-04, COMP-05) |
| P10 | `shared/components/pf-connectivity-banner.js` | PATCHED | Assertive announce on offline state change; add role=alert to error bar (A11Y-07, CB-03) |
| P11 | `shared/components/pf-side-panel.js` | PATCHED | Replace &times; with pf-icon; add reduced-motion for slide-in (UI-05, SP-01, SP-04) |
| P12 | `core/a11y.js` | PATCHED | trapFocus: include shadow-DOM focusable elements (ENG-09 / A11Y-01 WCAG 2.1.2) |
| P13 | `core/state.js` | PATCHED | Boolean coercion in hydrate() prevents string "true"/"false" from bypassing OTP exception check (SEC-03) |
| P14 | `config/state.schema.js` | PATCHED | Consolidate OTP three-field persist to single atomic object preventing partial-write state (SA-02) |
| P15 | `config/nav.config.js` | PATCHED | Update CrossPhase labelKey to intelligence (safe: keeps id so modules still resolve); disable palette utility (NAV-01, NAV-04, EX-01) |
| P16 | `modules/dispatch/index.js` | PATCHED | Change dispatch audience from 'executive' to 'general' — unblocks Phase 5 for operational staff (EX-02) |
| P17 | `shared/utils/render.js` | PATCHED | Unify STATUS_CLASS with lens.js SMAP — add escalated, resolved, approved, rejected mappings (UI-07) |
| P18 | `shared/utils/sanitizer.js` | PATCHED | Fix CSS injection bypass: cover unquoted url(javascript:) and url(data:) patterns (ENG-15) |
| P19 | `core/storage.js` | PATCHED | Fix evictLargestCache: retain max(50, 50%) entries instead of exponential-decay 10% (ENG-12) |
| P20 | `core/modules-registry.js` | PATCHED | Validate nav.group against known groups on register — no static import (avoids circular dep) (ENG-13) |
| P21 | `config/holidays.config.js` | PATCHED | Add 2027 Nigerian public holiday calendar for SLA working-time accuracy (ENG-05) |
| P22 | `modules/ackflow/index.js` | PATCHED | Fix ackflow: use root.querySelector instead of this.$() for safety; nav group remains ACTION (ST-03, SEC-06) |
| P23 | `modules/single-item-ops/index.js` | PATCHED | Replace direct localStorage calls with Platform.Storage to restore cross-tab sync and storage pressure monitoring (EX-06) |
| P24 | `core/sla.js` | PATCHED | Emit platform warning when SLA holiday calendar has no entry for current year (UX-07) |
| P25 | `shared/components/pf-identity-box.js` | PATCHED | Add reduced-motion guard for pulse dot; null-guard on fullName substring (IB-04, IB-05, COMP-05) |

## Audit Finding Cross-Reference
| Patch | Audit Finding IDs |
|---|---|
| P01 | DS-01, DS-02, DS-03, DS-04, DS-06 |
| P02 | DS-02, ENG-03 |
| P03 | A11Y-04, ENG-04 |
| P04 | ENG-03, ENG-04, SEC-02 |
| P05 | A11Y-01 (shadow DOM reduced-motion) |
| P06 | A11Y-02, SL-01 |
| P07 | EX-03, EX-04, MS-01, MS-02, MS-05, MS-06, DS-05 |
| P08 | M-03 (WCAG 2.1.2), UI-05 |
| P09 | H-01, H-04, COMP-05 |
| P10 | A11Y-07, CB-03 |
| P11 | UI-05, SP-01, SP-04 |
| P12 | ENG-09, A11Y-01 (WCAG 2.1.2) |
| P13 | SEC-03 |
| P14 | SA-02 |
| P15 | EX-01, NAV-01, NAV-04 |
| P16 | EX-02 |
| P17 | UI-07 |
| P18 | ENG-15 |
| P19 | ENG-12 |
| P20 | ENG-13 |
| P21 | ENG-05 |
| P22 | ST-03, SEC-06 |
| P23 | EX-06 |
| P24 | UX-07 |
| P25 | IB-04, IB-05, COMP-05 |

## Items Requiring Manual Action (Not Auto-Patchable)

| Finding | Reason Not Auto-Patched | Required Action |
|---|---|---|
| SEC-01 | PA signing tokens in client bundle — structural architectural change | Move all Power Automate endpoint URLs to a server-side BFF proxy. Remove all `sig=` params from `config/endpoints.config.js`. |
| WF-06 | Archive module doesn't exist | Create `modules/archive/index.js`, `view.html`, `styles.css` — read-only lens over `Entities._archive` map. |
| COMP-06 | `pf-rich-picker` ARIA combobox | Full ARIA combobox pattern requires component architecture refactor — add role=combobox, aria-expanded, aria-controls, aria-haspopup to toggle; role=listbox + role=option to dropdown. |
| ST-05 | Audit trail surface | Build a read-only `audit-trail` module showing `Platform.AuditLog` entries, filterable by reference, exportable as CSV. |
| SA-02 | OTP atomic write | Add `State.setOtpException(active, expiresAt, reason)` helper to `core/state.js` that writes all three fields atomically in a single Storage transaction. |
| ENG-01 | Router notFoundRoute fix verification | Run `tools/ui-smoke.mjs` suite (147 assertions) specifically targeting the navigation-freeze scenario from FIX-BATCH-3. |
| ENG-02 | Outbox exponential backoff | Add backoff to `core/api.js` Outbox agent: `delay = Math.min(2000 * Math.pow(2, attempt-1), 64000)` with ±20% jitter. |
| DS-08 | Data-viz color-blind safety | Add `--dgo-cat-2: #2563EB` (swap to info-600 blue) in `themes/tokens.css` for deuteranopia compliance. Already done in P01 as smart-400 — verify chroma separation is sufficient for your specific chart types. |