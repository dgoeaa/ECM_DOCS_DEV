/**
 * OBSIDIAN v4.2 — Intake Triage Desk Module
 * Remediated: High-fidelity split workspace displaying email cards, triage status, and logs.
 */
import { BaseModule } from '../../core/base-module.js';
import { appendRichSections } from '../../shared/utils/lens.js';
import { Modules } from '../../core/modules-registry.js';
import { aiClassify, createCorrespondence } from './service.js';
import { el, clear } from '../../shared/utils/dom.js';
import { renderForm, emptyState } from '../../shared/utils/render.js';

class CorrespondenceModule extends BaseModule {
  static id = 'correspondence';
  static label = 'module.correspondence.title';
  static icon = 'mail';
  static nav = { group: 'INTAKE', order: 1 };
  static audience = 'general';
  static status = 'active';
  static base = new URL('.', import.meta.url);

    async onVisible(root, params) {
    this._splitEl = root.querySelector('.pf-corr__split');
    this._tableEl = root.querySelector('[data-region="table"]');
    this._detailEl = root.querySelector('[data-region="detail"]');
    const filterHost = root.querySelector('[data-region="filter"]');
    
    if (this._splitEl) {
      this._splitEl.setAttribute('data-view', 'list');
    }
    clear(filterHost);
    this._filter = document.createElement('pf-filter-bar');
    this._filter.statuses = [
      { value: 'pending', labelKey: 'status.pending' }, 
      { value: 'routed', labelKey: 'status.routed' },
      { value: 'replied', labelKey: 'status.replied' }, 
      { value: 'closed', labelKey: 'status.closed' }
    ];
    filterHost.appendChild(this._filter);
    this.on(this._filter, 'pf-filter:change', (e) => { 
      this._q = e.detail.query; 
      this._status = e.detail.status; 
      this.renderTable(); 
    });

    this.on(root.querySelector('[data-act="export"]'), 'click', () => this.exportCsv());
    this.on(root.querySelector('[data-act="new"]'), 'click', () => this.openCreate());

    const E = globalThis.Platform.Entities;
    if (!E.isHydrated()) await E.bootstrap().catch(() => {});
    this.bus('entity:email:changed', () => this.refresh());
    this.bus('entity:reference:updated', () => this.refresh());
    this.bus('context:reference:changed', (e) => { if (e.source !== this.id) this.selectRef(e.ref); });

    this.refresh();
    const deep = params && params.path && params.path[0];
    if (deep) this.selectRef(deep);
  }

  source() {
    return globalThis.Platform.Entities.all('document');
  }

  filtered() {
    return this.source().filter((r) => {
      const st = String(r.status || r.Status || '').toLowerCase();
      if (this._status && st !== this._status) return false;
      if (!this._q) return true;
      return [r.subject, r.sender, r.from, r.__ref, r.title, r.category].some((v) => 
        String(v || '').toLowerCase().includes(this._q)
      );
    });
  }

  refresh() { 
    this._rows = this.filtered(); 
    this.renderTable(); 
    if (!this._selRef) this.renderDetail(null); 
  }

  renderTable() {
    this._rows = this.filtered();
    this._filter.count = this._rows.length;
    clear(this._tableEl);
    
    if (!this._rows.length) { 
      emptyState(this._tableEl, 'common.state.empty'); 
      return; 
    }
    
    const listContainer = el('div', { class: 'pf-corr-list', style: 'max-height:600px;overflow-y:auto;display:flex;flex-direction:column;gap:12px;' });
    this._rows.forEach((r) => {
      const st = String(r.status || r.Status || 'Pending');
      const itemCard = el('button', { 
        class: 'pf-corr-card', 
        'data-ref': r.__ref || r.__id || '',
        style: `width:100%;text-align:left;padding:16px;background:var(--dgo-color-surface-raised);border:1px solid ${r.__ref === this._selRef ? 'var(--dgo-color-action-primary)' : 'var(--dgo-color-border-default)'};border-radius:10px;display:flex;flex-direction:column;gap:8px;cursor:pointer;box-shadow:var(--dgo-elevation-flat);`
      }, [
        el('div', { style: 'display:flex;justify-content:between;width:100%;align-items:center;' }, [
          el('span', { class: 'pf-overline', text: r.__ref || 'ORPHAN', style: 'color:var(--dgo-color-fg-muted);font-weight:600;' }),
          el('span', { class: 'pf-badge', text: st, style: `margin-left:auto;padding:2px 8px;border-radius:12px;font-size:11px;background:var(--dgo-color-status-${st.toLowerCase()}-bg || #f0f0f0);color:var(--dgo-color-status-${st.toLowerCase()}-fg || #333);` })
        ]),
        el('div', { text: r.title || r.subject || 'Untitled Correspondence', style: 'font-weight:600;font-size:14px;color:var(--dgo-color-fg-strong);' }),
        el('div', { style: 'display:flex;justify-content:between;width:100%;font-size:12px;color:var(--dgo-color-fg-muted);' }, [
          el('span', { text: r.sender || r.from || 'Central Registry' }),
          el('span', { text: r.ts ? this.fmt(r.ts) : '—', style: 'margin-left:auto;' })
        ])
      ]);

      itemCard.addEventListener('click', () => { 
        if (r.__ref) globalThis.Platform.Context.setActive(r.__ref, this.id); 
        this.selectRef(r.__ref || r.__id, r); 
      });
      listContainer.appendChild(itemCard);
    });

    this._tableEl.appendChild(listContainer);
    this.markSelected();
  }

  markSelected() {
    const cards = this._tableEl.querySelectorAll('.pf-corr-card');
    cards.forEach((card) => {
      const active = card.getAttribute('data-ref') === this._selRef;
      card.style.borderColor = active ? 'var(--dgo-color-action-primary)' : 'var(--dgo-color-border-default)';
      card.style.background = active ? 'var(--dgo-green-50)' : 'var(--dgo-color-surface-raised)';
    });
  }

    selectRef(ref, rec) {
    if (!ref) return;
    this._selRef = String(ref);
    const item = rec || this.source().find((r) => (r.__ref || r.__id) === this._selRef);
    this.markSelected();
    if (this._splitEl) {
      this._splitEl.setAttribute('data-view', 'detail');
    }
    this.renderDetail(item);
  }

    renderDetail(it) {
    clear(this._detailEl);
    if (!it) { 
      emptyState(this._detailEl, 'correspondence.selectHint'); 
      return; 
    }
    const ref = it.__ref || it.__id || '';
    
    // Mobile back navigation trigger
    const backBtn = el('button', {
      class: 'dgo-btn dgo-btn--secondary dgo-btn--sm pf-back-btn',
      style: 'margin-bottom:12px;display:none;width:100%;justify-content:center;',
      html: '← Back to Inbox',
      onClick: () => {
        if (this._splitEl) this._splitEl.setAttribute('data-view', 'list');
      }
    });
    
    const triageBar = document.createElement('pf-triage-bar');
    triageBar.item = it;
    this.on(triageBar, 'pf-triage:routed', () => this.refresh());
    this.on(triageBar, 'pf-triage:acknowledged', () => this.refresh());

    const contentArea = el('div', { class: 'pf-corr-detail__body', style: 'padding:16px;display:flex;flex-direction:column;gap:16px;' }, [
      el('div', { class: 'pf-corr-detail__meta' }, [
        el('h2', { text: it.subject || it.title || ref, style: 'font-size:20px;font-weight:700;color:var(--dgo-color-fg-strong);margin:0 0 4px 0;' }),
        el('p', { class: 'sender-info', text: this.t('correspondence.fromMeta', { who: it.sender || it.from || 'Central Registry', ref }), style: 'font-size:13px;color:var(--dgo-color-fg-muted);margin:0;' })
      ]),
      el('div', { class: 'pf-corr-detail__desc', style: 'background:var(--dgo-color-surface-sunken);border:1px solid var(--dgo-color-border-default);border-radius:8px;padding:16px;font-size:14px;line-height:1.6;white-space:pre-wrap;color:var(--dgo-color-fg-default);' }, [
        el('p', { text: it.body || it.summary || 'No payload description available.' })
      ]),
      el('div', { class: 'pf-corr-detail__actions', style: 'display:flex;gap:8px;flex-wrap:wrap;' }, [
        el('button', { class: 'dgo-btn dgo-btn--secondary dgo-btn--sm', html: `🧠 ${this.t('correspondence.aiClassify')}`, onClick: () => this.classify(it) }),
        el('button', { class: 'dgo-btn dgo-btn--secondary dgo-btn--sm', html: `📂 Open Folder`, onClick: () => globalThis.Platform.goToEntity(ref, 'ops-hub') }),
        el('button', { class: 'dgo-btn dgo-btn--primary dgo-btn--sm', html: `⚡ Allocate Task`, onClick: async () => { const r = await globalThis.Platform.UI.openEmailToTask(it); if (r && r.ok) this.refresh(); } })
      ])
    ]);

    this._detailEl.append(backBtn, triageBar, contentArea);
    appendRichSections(this._detailEl, it, this, { type: 'email' });
  }

  async classify(it) {
    const result = await this.call(aiClassify, { action: 'aiAnalyseEmail', emailId: it.__id, referenceId: it.__ref, subject: it.subject });
    if (result.ok) {
      const d = result.data || {};
      globalThis.Platform.Entities.upsert('email', { ...it, referenceId: it.__ref, category: d.category || it.category, priority: d.priority || it.priority, status: d.status || it.status });
      globalThis.Platform.UI.actionCompleted('correspondence.classified', { module: 'correspondence', target: it.__ref || it.referenceId || it.__id });
    }
  }

  openCreate() {
    globalThis.Platform.UI.modal({
      titleKey: 'correspondence.new', component: null, bodyKey: null,
      actions: [{ labelKey: 'common.actions.cancel' }]
    });
    const body = document.querySelector('pf-modal')?.shadowRoot?.querySelector('#m-body');
    if (body) renderForm(body, {
      fields: [
        { name: 'sender', labelKey: 'field.sender.label' },
        { name: 'subject', labelKey: 'field.subject.label' },
        { name: 'RefIDD', labelKey: 'field.referenceId.label' },
        { name: 'body', labelKey: 'correspondence.detailsLabel', type: 'textarea' },
        { name: 'priority', labelKey: 'field.priority.label', type: 'select',
          options: [
            { value: 'High', labelKey: 'priority.high' }, 
            { value: 'Medium', labelKey: 'priority.medium' }, 
            { value: 'Low', labelKey: 'priority.low' }
          ] 
        }
      ],
      submitKey: 'correspondence.new',
      onSubmit: async (values) => {
        const ok = await globalThis.Platform.UI.confirm({ 
          titleKey: 'correspondence.new', 
          summaryKey: 'action.confirmSummary',
          details: [ 
            { label: this.t('field.subject.label'), value: values.subject || '—' }, 
            { label: this.t('field.sender.label'), value: values.sender || '—' }, 
            { label: this.t('field.referenceId.label'), value: values.RefIDD || '—' } 
          ], 
          confirmKey: 'correspondence.new' 
        });
        if (!ok) return;
        const result = await this.call(createCorrespondence, { action: 'emailtotaskassignment', ...values });
        if (result.ok) {
          globalThis.Platform.Entities.upsert('email', { referenceId: values.RefIDD, subject: values.subject, sender: values.sender, body: values.body, priority: values.priority, status: 'Pending', ts: new Date().toISOString() });
          globalThis.Platform.UI.closeModal();
          globalThis.Platform.UI.actionCompleted('correspondence.created', { module: 'response-tracking' });
        }
      }
    });
  }

  exportCsv() {
    const cols = [['referenceId', 'Reference'], ['subject', 'Subject'], ['sender', 'Sender'], ['ts', 'Date'], ['priority', 'Priority'], ['status', 'Status']];
    const rows = (this._rows || []).map((r) => ({ referenceId: r.__ref, subject: r.subject || r.title, sender: r.sender || r.from, ts: r.ts, priority: r.priority, status: r.status || r.Status }));
    globalThis.Platform.Format.downloadCsv('correspondence.csv', globalThis.Platform.Format.toCsv(rows, cols.map(([key, label]) => ({ key, label }))));
  }

  fmt(v) { return globalThis.Platform?.Format?.dateTime ? globalThis.Platform.Format.dateTime(v) : String(v); }
}

Modules.register(CorrespondenceModule);
export default CorrespondenceModule;
