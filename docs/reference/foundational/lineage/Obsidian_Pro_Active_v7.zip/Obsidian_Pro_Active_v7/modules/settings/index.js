/**
 * OBSIDIAN v4.2 — Administrative Control Chamber
 * Remediated: Live locale toggle and mock environmental authorization controls.
 */
import { BaseModule } from '../../core/base-module.js';
import { Modules } from '../../core/modules-registry.js';
import { Endpoints } from '../../config/endpoints.config.js';
import { el, clear } from '../../shared/utils/dom.js';

const LS_PREFIX = 'obsidian.endpoint.';
const VALID_URL = /^https?:\/\/[^\s"'<>]+$/;

class SettingsModule extends BaseModule {
  static id = 'settings';
  static label = 'module.settings.title';
  static icon = 'settings';
  static nav = { group: 'System', order: 2 };
  static audience = 'admin';
  static status = 'active';
  static base = new URL('.', import.meta.url);

  async onVisible(root) {
    const region = root.querySelector('[data-region="content"]') || root;
    clear(region);

    const explainer = el('p', { class: 'pf-muted', style: 'margin-bottom:20px;line-height:1.5;',
      text: this.t('settings.endpointsExplainer') });
    const resetAllBtn = el('button', { class: 'dgo-btn dgo-btn--danger', type: 'button',
      html: `🔄 ${this.t('settings.resetAll')}` });
    resetAllBtn.addEventListener('click', () => this._resetAll(region));

    const toolbar = el('div', { class: 'pf-toolbar', style: 'margin-bottom:16px;display:flex;align-items:center;justify-content:space-between;width:100%;' }, [
      el('span', { class: 'pf-overline', text: this.t('settings.endpoints') }),
      resetAllBtn
    ]);

    // Endpoint list
    const list = el('div', { class: 'pf-settings__list', style: 'display:flex;flex-direction:column;gap:12px;' });
    const entries = Object.entries(Endpoints || {});
    let activeOverrides = 0;
    entries.forEach(([key, ep]) => {
      if (!ep.url) return;
      const overrideVal = this._getOverride(key);
      if (overrideVal) activeOverrides++;
      list.append(this._renderEndpointRow(key, ep, overrideVal));
    });

    const summary = el('div', { class: 'pf-card', style: 'padding:16px;margin-bottom:20px;background:var(--dgo-color-surface-sunken);border:1px solid var(--dgo-color-border-default);border-radius:10px;' }, [
      el('div', { style: 'display:flex;gap:16px;font-size:14px;' }, [
        el('span', { html: `<strong>${entries.filter(([_, e]) => e.url).length}</strong> ${this.t('settings.totalEndpoints')}` }),
        el('span', { html: `<strong>${activeOverrides}</strong> ${this.t('settings.activeOverrides')}` })
      ])
    ]);

    // Storage Pressure Telemetry Indicator
    const storageMetrics = globalThis.Platform?.Storage?.getDiagnostics?.();
    const storageSection = el('section', { class: 'pf-card', style: 'padding:16px;margin-bottom:20px;background:var(--dgo-color-surface-sunken);border:1px solid var(--dgo-color-border-default);border-radius:10px;' });
    if (storageMetrics) {
      const tone = storageMetrics.level === 'critical' ? 'action' : storageMetrics.level === 'warning' ? 'pending' : 'replied';
      storageSection.append(el('div', { class: 'pf-overline', style: 'margin-bottom:8px;', text: this.t('settings.storage.title') }));
      storageSection.append(el('div', { style: 'display:flex;align-items:center;justify-content:space-between;margin-top:8px;' }, [
        el('span', { html: `Utilization: <strong>${storageMetrics.percent}%</strong>` }),
        el('span', { class: `pf-badge pf-badge--${tone}`, text: storageMetrics.level.toUpperCase() })
      ]));
    }

    // Language switcher section
    const langSection = el('section', { class: 'pf-card', style: 'padding:16px;margin-bottom:20px;background:var(--dgo-color-surface-sunken);border:1px solid var(--dgo-color-border-default);border-radius:10px;' });
    langSection.append(el('div', { class: 'pf-overline', style: 'margin-bottom:8px;', text: this.t('settings.language') }));
    langSection.append(el('p', { class: 'pf-muted', style: 'font-size:13px;margin-bottom:12px;', text: this.t('settings.languageBlurb') }));
    const I = globalThis.Platform.I18n;
    const langs = [
      { code: 'en', label: 'English' },
      { code: 'fr', label: 'Français' },
      { code: 'ha', label: 'Hausa' }
    ];
    const langChips = el('div', { class: 'pf-chipgroup', role: 'radiogroup' });
    langs.forEach((l) => {
      const b = el('button', { type: 'button',
        class: 'pf-chip' + (I.locale() === l.code ? ' pf-chip--selected' : ''),
        text: l.label, 'data-lang': l.code });
      b.addEventListener('click', async () => {
        if (I.locale() === l.code) return;
        await I.switch(l.code);
        this.onVisible(root);
      });
      langChips.append(b);
    });
    langSection.append(langChips);
    region.append(storageSection, langSection, explainer, summary, toolbar, list);
  }

  _renderEndpointRow(key, ep, currentOverride) {
    const row = el('div', { class: 'pf-settings__row pf-card', style: 'padding:16px;margin-bottom:12px;background:var(--dgo-color-surface-raised);border:1px solid var(--dgo-color-border-default);border-radius:10px;' });
    const head = el('div', { class: 'pf-settings__row-head', style: 'font-weight:700;font-size:14px;display:flex;align-items:center;gap:8px;' }, [
      el('strong', { text: key }),
      el('span', { class: 'pf-muted', text: ` · ${ep.flowName || ''}`, style: 'font-weight:400;color:var(--dgo-color-fg-muted);' }),
      currentOverride ? el('span', { class: 'pf-badge pf-badge--pending', text: this.t('settings.overrideActive'), style: 'background:var(--dgo-color-status-pending-bg);color:var(--dgo-color-status-pending-fg);padding:2px 8px;border-radius:10px;font-size:10px;' }) : null
    ].filter(Boolean));
    const def = el('div', { class: 'pf-settings__row-default', style: 'font-size:12px;margin:8px 0;' }, [
      el('span', { class: 'pf-overline', text: this.t('settings.defaultUrl'), style: 'display:block;margin-bottom:4px;' }),
      el('code', { class: 'pf-settings__url', text: this._truncUrl(ep.url), style: 'display:block;padding:8px;background:var(--dgo-color-surface-sunken);border-radius:6px;font-family:var(--dgo-family-mono);word-break:break-all;' })
    ]);

    const inputId = `settings-${key}`;
    const input = el('input', { id: inputId, class: 'pf-input dgo-input', type: 'url',
      placeholder: this.t('settings.overridePlaceholder'),
      value: currentOverride || '', style: 'width:100%;margin-bottom:8px;' });
    const errorSlot = el('p', { class: 'pf-field__error', hidden: true });

    const saveBtn = el('button', { class: 'dgo-btn dgo-btn--primary dgo-btn--sm', type: 'button',
      text: this.t('settings.save') });
    const clearBtn = el('button', { class: 'dgo-btn dgo-btn--secondary dgo-btn--sm', type: 'button',
      text: this.t('settings.clear'),
      disabled: currentOverride ? null : 'disabled' });

    saveBtn.addEventListener('click', () => {
      errorSlot.hidden = true;
      const v = (input.value || '').trim();
      if (!v) { this._clearOverride(key); this._refreshRow(row, key, ep); return; }
      if (!VALID_URL.test(v)) {
        errorSlot.textContent = this.t('settings.invalidUrl'); errorSlot.hidden = false;
        input.focus(); return;
      }
      this._setOverride(key, v);
      this._refreshRow(row, key, ep);
      globalThis.Platform.UI.toast({ messageKey: 'settings.saved', vars: { key }, variant: 'success' });
    });
    clearBtn.addEventListener('click', () => {
      this._clearOverride(key); input.value = '';
      this._refreshRow(row, key, ep);
      globalThis.Platform.UI.toast({ messageKey: 'settings.cleared', vars: { key }, variant: 'info' });
    });

    const controls = el('div', { class: 'pf-settings__row-controls' }, [
      el('div', { class: 'pf-field', style: 'flex:1' }, [
        el('label', { class: 'pf-label', for: inputId, text: this.t('settings.override') }),
        input, errorSlot
      ]),
      el('div', { class: 'pf-settings__row-actions', style: 'display:flex;gap:8px;margin-top:8px;' }, [saveBtn, clearBtn])
    ]);

    row.append(head, def, controls);
    return row;
  }

  _refreshRow(row, key, ep) {
    const replacement = this._renderEndpointRow(key, ep, this._getOverride(key));
    row.replaceWith(replacement);
  }

  _getOverride(key) {
    return globalThis.Platform?.Storage?.get('endpoint.' + key, '') || '';
  }
  _setOverride(key, value) {
    globalThis.Platform?.Storage?.set('endpoint.' + key, value);
  }
  _clearOverride(key) {
    globalThis.Platform?.Storage?.remove('endpoint.' + key);
  }

  async _resetAll(region) {
    const ok = await globalThis.Platform.UI.confirm({
      titleKey: 'settings.resetAll', summaryKey: 'settings.resetAllWarn',
      confirmKey: 'settings.resetAll', danger: true,
      details: [{ label: this.t('confirm.impact'), value: this.t('settings.resetAllImpact') }]
    });
    if (!ok) return;
    try {
      const toRemove = [];
      for (let i = 0; i < (localStorage?.length || 0); i++) {
        const k = localStorage.key(i);
        if (k && k.startsWith(LS_PREFIX)) toRemove.push(k.replace(/^obsidian\./, ''));
      }
      toRemove.forEach((k) => globalThis.Platform?.Storage?.remove(k));
      globalThis.Platform.UI.toast({ messageKey: 'settings.resetAllDone', vars: { n: toRemove.length }, variant: 'success' });
      this.onVisible({ querySelector: () => region });
    } catch (_) {}
  }

  _truncUrl(url) {
    if (!url) return '';
    if (url.length <= 80) return url;
    const m = url.match(/^(https?:\/\/[^/]+)(\/[^?]+)/);
    return m ? `${m[1]}${m[2].slice(0, 60)}…` : url.slice(0, 80) + '…';
  }
}
Modules.register(SettingsModule);
export default SettingsModule;
