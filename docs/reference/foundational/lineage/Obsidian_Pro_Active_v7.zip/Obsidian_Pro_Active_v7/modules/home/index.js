/** OBSIDIAN v4.3 — module 'home' — FIX-BATCH-2
 *
 *  BUGS FIXED:
 *  1. WELCOME VIEW NOT ACTIVE — Home module's onVisible was calling
 *     E.bootstrap() with await, blocking the paint() call. If the entity fetch
 *     took > 1 s, the welcome dashboard appeared blank. Fix: bootstrap is
 *     fire-and-forget; paint() runs immediately with whatever counts are cached,
 *     then re-paints when bootstrap completes.
 *  2. ONBOARDING GUIDE STATE — Storage.get() returns the string 'true' when
 *     dismissed, but the check was `=== true` (strict boolean). Fixed to check
 *     both string and boolean values.
 *  3. DOUBLE-PAINT FLOOD — Three bus subscriptions (entity:loading,
 *     entity:bootstrapped, entity:changed) each called paint() independently,
 *     causing up to three redraws in rapid succession on first load. Fixed with
 *     a debounced repaint helper.
 */
import { BaseModule } from '../../core/base-module.js';
import { Modules } from '../../core/modules-registry.js';
import { el, clear } from '../../shared/utils/dom.js';
import { Charts } from '../../core/charts.js';
import { attentionList, renderHeatmap } from '../../shared/utils/lens.js';

const TILE = [
  ['reference', 'response-tracking', 'table'],
  ['document',  'ops-hub',           'folder'],
  ['task',      'orchestrator',      'workflow'],
  ['email',     'correspondence',    'mail'],
  ['approval',  'approvals',         'check-circle'],
  ['comment',   'comments',          'message-square']
];

function greetKey() {
  const h = new Date().getHours();
  return h < 12 ? 'morning' : h < 18 ? 'afternoon' : 'evening';
}

function fmtDate(d) {
  return globalThis.Platform?.Format?.dateTime
    ? globalThis.Platform.Format.dateTime(d)
    : String(d);
}

class HomeModule extends BaseModule {
  static id = 'home';
  static label = 'module.home.title';
  static icon = 'layout-dashboard';
  static nav = { group: 'CrossPhase', order: 0 };
  static audience = 'all';
  static status = 'active';
  static base = new URL('.', import.meta.url);

  async onVisible(root, _params) {
    this._root = root;
    this._region = root.querySelector('[data-region="content"]') || root;
    this._paintTimer = null;

    const E = globalThis.Platform.Entities;

    // FIX-1: Paint immediately with cached counts, don't await bootstrap
    this.paint();

    // FIX-3: Debounced repaint — avoids triple redraw on first load
    const schedulePaint = () => {
      clearTimeout(this._paintTimer);
      this._paintTimer = setTimeout(() => this.paint(), 60);
    };

    this.bus('entity:loading',      schedulePaint);
    this.bus('entity:bootstrapped', schedulePaint);
    this.bus('entity:changed',      schedulePaint);

    // FIX-1: kick off bootstrap without blocking
    if (!E.isHydrated()) {
      E.bootstrap().catch(() => {});
    }
  }

  onHidden() {
    clearTimeout(this._paintTimer);
    super.onHidden?.();
  }

  paint() {
    if (!this._region) return;
    clear(this._region);
    this._renderOverviewDashboard();
  }

  _renderOnboardingGuide() {
    const dismissGuide = () => {
      globalThis.Platform?.Storage?.set('onboarding.dismissed', 'true');
      const panel = this._region.querySelector('.pf-onboarding-panel');
      if (panel) {
        panel.style.opacity = '0';
        panel.style.transform = 'translateY(-10px)';
        panel.style.transition = 'all 0.3s ease';
        setTimeout(() => panel.remove(), 300);
      }
    };

    const guidePanel = el('section', {
      class: 'pf-card pf-onboarding-panel',
      style: 'margin-top:var(--space-4);border:1px solid var(--color-brand-primary);background:var(--color-surface-raised);position:relative;overflow:hidden;display:flex;flex-direction:column;gap:var(--space-3);transition:all 0.3s ease;'
    }, [
      el('button', {
        class: 'pf-btn pf-btn--ghost',
        style: 'position:absolute;top:var(--space-3);right:var(--space-3);min-height:32px;padding:0 var(--space-3);font-size:var(--size-caption);border-color:var(--color-border-strong);',
        text: '✕ Dismiss Guide',
        onClick: dismissGuide
      }),
      el('div', { class: 'pf-overline', style: 'color:var(--color-brand-primary);font-weight:var(--fw-bold);', text: 'Operational Onboarding Guide' }),
      el('h3', { style: 'margin:0;font-size:var(--size-h3);font-family:var(--font-display);font-weight:var(--fw-bold);', text: 'Distributed Governance Cockpit Onboarding' }),
      el('p', { class: 'pf-muted', style: 'font-size:var(--size-body-sm);margin:0;line-height:var(--lh-relaxed);max-width:85%;', text: 'Welcome to the DGO Operations workspace. Use the links below to jump to each active lifecycle zone:' }),
      el('div', { style: 'display:grid;gap:var(--space-3);grid-template-columns:repeat(auto-fit,minmax(220px,1fr));margin-top:var(--space-2);' }, [
        ...([
          ['📥', '1. Intake & Triage',       'pending',   'correspondence',    'Capture email coordinates in <a href="#/correspondence">Correspondence</a>.'],
          ['⚡', '2. Allocation',              'routed',    'single-item-ops',   'Assign in <a href="#/single-item-ops">Single</a> or <a href="#/bulk-assignment">Bulk assignment</a>.'],
          ['🎯', '3. Orchestration & Action', 'action',    'orchestrator',      'Track actions in <a href="#/orchestrator">Orchestrator</a> and <a href="#/ackflow">AckFlow</a>.'],
          ['✅', '4. Review & Approvals',     'escalated', 'approvals',         'Sign off in <a href="#/approvals">Approvals</a> and <a href="#/executive">Executive View</a>.'],
          ['📤', '5. Dispatch & Closure',     'replied',   'dispatch',          'Forward files in <a href="#/dispatch">Dispatch & Closure</a>.'],
          ['🗄️','6. Archive & Records',       'archived',  'registry',          'Preserve records in <a href="#/registry">Registry</a>.'],
        ].map(([icon, label, status, , html]) =>
          el('div', { style: `padding:var(--space-3);background:var(--color-surface-sunken);border-radius:var(--radius-md);border-left:3px solid var(--dgo-color-status-${status}-fg);` }, [
            el('div', { style: 'display:flex;align-items:center;gap:var(--space-2);font-weight:var(--fw-semibold);font-size:var(--size-body-sm);margin-bottom:var(--space-1);' }, [
              el('span', { text: icon }),
              el('span', { text: label })
            ]),
            el('p', { class: 'pf-muted', style: 'font-size:var(--size-caption);line-height:var(--lh-normal);margin:0;', html })
          ])
        ))
      ]),
      el('button', {
        class: 'pf-btn pf-btn--primary',
        style: 'margin-top:var(--space-2);max-width:180px;min-height:36px;font-size:var(--size-caption);',
        text: 'Acknowledge Guide',
        onClick: dismissGuide
      })
    ]);
    return guidePanel;
  }

  _renderOverviewDashboard() {
    const E = globalThis.Platform.Entities;
    const c = E.counts?.() || {};

    this._region.append(this._renderGreeting(c));

    // FIX-2: check both string 'true' and boolean true
    const dismissed = globalThis.Platform?.Storage?.get('onboarding.dismissed');
    if (dismissed !== 'true' && dismissed !== true) {
      this._region.append(this._renderOnboardingGuide());
    }

    this._region.append(this._renderHeroKpis(c));
    this._region.append(this._renderAttentionAndPulse(c));
    const statusMix = this._renderStatusMix(c);
    if (statusMix) this._region.append(statusMix);
    this._region.append(this._renderQuickActions());
    this._renderHeatmap(this._region);
  }

  _renderGreeting(c) {
    const P = globalThis.Platform;
    const persona  = (P.Persona?.current?.()) || 'general';
    const total    = (c.reference || 0) + (c.document || 0) + (c.task || 0) + (c.email || 0);
    const overdue  = c.overdue?.count || 0;
    const brandMark = P.Brand?.currentLogo?.()?.mark || '/assets/subbrands/dgo/logo-mark.svg';

    return el('section', { class: 'pf-home-hero' }, [
      el('div', { class: 'pf-home-hero__row' }, [
        el('div', { class: 'pf-home-hero__brand' }, [
          el('img', { src: brandMark, alt: this.t('brand.dgo.label'), class: 'pf-home-hero__mark' }),
          el('div', {}, [
            el('h2', { class: 'pf-home-greet', text: this.t('home.greet.' + greetKey()) }),
            el('p', { class: 'pf-home-summary',
              text: overdue
                ? this.t('home.summary.attention', { n: total, overdue })
                : this.t('home.summary.calm', { n: total }) })
          ])
        ]),
        el('div', { class: 'pf-home-meta' }, [
          el('div', { class: 'pf-overline', text: this.t('home.persona') }),
          el('div', { class: 'pf-home-meta__val', text: persona }),
          el('div', { class: 'pf-overline', style: 'margin-top:var(--space-2)', text: this.t('home.today') }),
          el('div', { class: 'pf-home-meta__val', text: fmtDate(new Date()) })
        ])
      ])
    ]);
  }

  _renderHeroKpis(c) {
    return el('div', { class: 'pf-grid', style: 'margin-top:var(--space-5)' },
      TILE.map(([type, modId, icon]) => {
        const card = el('button', { class: 'pf-stat pf-stat--rich', style: 'text-align:left;cursor:pointer;width:100%' }, [
          el('div', { class: 'pf-stat__label', html: `<pf-icon name="${icon}" size="14"></pf-icon> ${this.t('entity.' + type)}` }),
          el('div', { class: 'pf-stat__value', text: String(c[type] || 0) })
        ]);
        if (c.timeline?.length) {
          card.append(el('div', { class: 'pf-stat__trend' }, [Charts.sparkline(c.timeline, { width: 160, height: 28 })]));
        }
        this.on(card, 'click', () => globalThis.Platform.Router.navigate(modId));
        return card;
      })
    );
  }

  _renderAttentionAndPulse(c) {
    const split  = el('section', { class: 'pf-home-split' });
    const overdue = c.overdue?.items || [];
    split.append(attentionList('home.attention', overdue, { modId: 'response-tracking' }));
    const recent = c.recent || [];
    const pulse  = el('div', { class: 'pf-card', style: 'padding:var(--space-5)' }, [
      el('div', { class: 'pf-overline', text: this.t('home.pulse') }),
      el('div', { style: 'margin:var(--space-3) 0' }, [Charts.sparkline(c.timeline || [], { width: 400, height: 60 })]),
      el('div', { class: 'pf-overline', style: 'margin-top:var(--space-3)', text: this.t('home.recent') }),
      recent.length
        ? el('ol', { class: 'pf-pulse-list' },
            recent.slice(0, 6).map((r) => el('li', { class: 'pf-pulse-item' }, [
              el('span', { class: 'pf-pulse-when', text: r.ts ? fmtDate(r.ts) : '' }),
              el('span', { class: 'pf-pulse-what', text: r.title || r.subject || r.action || r.__id || r.__ref || '' })
            ])))
        : el('p', { class: 'pf-muted', text: this.t('home.recentEmpty') })
    ]);
    split.append(pulse);
    return split;
  }

  _renderStatusMix(c) {
    const byStatus = c.byStatus || {};
    if (!Object.keys(byStatus).length) return null;
    const d = Charts.donut(byStatus, { label: this.t('home.byStatus'), size: 160 });
    return el('section', { class: 'pf-card', style: 'padding:var(--space-5);margin-top:var(--space-5)' }, [
      el('div', { class: 'pf-overline', text: this.t('home.byStatus') }),
      el('div', { style: 'display:flex;gap:var(--space-5);align-items:center;margin-top:var(--space-3);flex-wrap:wrap' }, [d.svg, d.legend])
    ]);
  }

  _renderQuickActions() {
    const items = [
      { label: 'home.qa.assignSingle',   icon: 'file-plus',      mod: 'single-item-ops', primary: true },
      { label: 'home.qa.assignBulk',     icon: 'users',          mod: 'bulk-assignment' },
      { label: 'home.qa.correspondence', icon: 'mail',           mod: 'correspondence' },
      { label: 'home.qa.tasks',          icon: 'workflow',       mod: 'orchestrator' },
      { label: 'home.qa.assistant',      icon: 'message-circle', mod: 'assistant' }
    ];
    return el('section', { class: 'pf-card', style: 'padding:var(--space-5);margin-top:var(--space-5)' }, [
      el('div', { class: 'pf-overline', text: this.t('home.quickActions') }),
      el('div', { class: 'pf-toolbar', style: 'margin-top:var(--space-3);flex-wrap:wrap' },
        items.map((it) => {
          const b = el('button', {
            class: 'pf-btn ' + (it.primary ? 'pf-btn--primary' : 'pf-btn--ghost'),
            html: `<pf-icon name="${it.icon}" size="14"></pf-icon> ${this.t(it.label)}`
          });
          this.on(b, 'click', () => globalThis.Platform.Router.navigate(it.mod));
          return b;
        })
      )
    ]);
  }

  _renderHeatmap(container) {
    const tasks = globalThis.Platform?.Entities?.all('task') || [];
    const wrap  = el('section', { class: 'pf-card', style: 'padding:var(--space-4);margin-top:var(--space-4)' });
    wrap.append(
      el('header', { class: 'pf-view__head', style: 'margin-bottom:var(--space-3);padding:0' }, [
        el('h2', { class: 'pf-view__title', style: 'margin:0', text: this.t('lens.heatmap.title') }),
        el('p', { class: 'pf-muted', style: 'margin:0;font-size:var(--size-body-sm)', text: this.t('lens.heatmap.subtitle') })
      ])
    );
    const heatmapHost = el('div', {});
    wrap.append(heatmapHost);
    renderHeatmap(heatmapHost, tasks, {
      weeks: 14, startDaysAgo: 21, dueField: 'DueDate',
      fallbackFields: ['dueDate', 'DueDate', 'TaskDue', 'taskDueDate'],
      onCellClick: ({ date, items }) => {
        if (!items.length) return;
        const list = el('div', {});
        items.slice(0, 20).forEach((it) => {
          list.append(el('div', { style: 'padding:var(--space-2) 0;border-bottom:1px solid var(--color-border)' }, [
            el('strong', { text: it.title || it.Title || it.__id || '—' }),
            el('div', { class: 'pf-muted', style: 'font-size:var(--size-caption)', text: (it.assignedTo || '') + ' · ' + (it.priority || '') })
          ]));
        });
        globalThis.Platform.UI.modal({
          title: this.t('lens.heatmap.dayItems', { date }),
          bodyEl: list,
          actions: [{ labelKey: 'common.actions.close', variant: 'ghost' }]
        });
      }
    });
    container.append(wrap);
  }
}

Modules.register(HomeModule);
export default HomeModule;
