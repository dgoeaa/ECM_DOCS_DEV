/** OBSIDIAN v4.0 — module 'orchestrator' (Operations · LENS · audience:general).
 *  Task-orchestration lens over the shared fabric: filterable task list, row→active Reference,
 *  cross-links to the related document/email/approval, CSV export. It is the deep-link HOME for
 *  tasks (ENTITY_HOME_MODULE.task) — arriving via goToEntity(ref,'orchestrator') focuses that ref. */
import { BaseModule } from '../../core/base-module.js';
import { Modules } from '../../core/modules-registry.js';
import { mountListLens } from '../../shared/utils/lens.js';

class OrchestratorModule extends BaseModule {
  static id = 'orchestrator'; static label = 'module.orchestrator.title'; static icon = 'workflow';
  static nav = { group: 'ACTION', order: 1 }; static audience = 'general'; static status = 'active';
  static base = new URL('.', import.meta.url);

  async onVisible(root, params) {
    const E = globalThis.Platform.Entities;
    if (!E.isHydrated()) await E.bootstrap().catch(() => {});
    mountListLens(this, root, {
      type: 'task',
      columns: [
        { key: 'referenceId', labelKey: 'field.referenceId.label' },
        { key: 'title', labelKey: 'field.subject.label' },
        { key: 'priority', labelKey: 'field.priority.label' },
        { key: 'status', labelKey: 'field.status.label' },
        { key: 'assignedTo', labelKey: 'field.assignedTo.label' }
      ],
      csvName: 'orchestrator.csv',
      linked: true,
      actions: [
        {
          label: 'Acknowledge Receipt',
          icon: 'check-circle',
          run: async (task) => {
            const P = globalThis.Platform;
            const res = await P.Actions.run('acknowledge', {
              preview: { 
                titleKey: 'triage.ackTitle', 
                summaryKey: 'triage.ackConfirm',
                details: [
                  { label: 'Task ID', value: task.id || task.__ref },
                  { label: 'Directive', value: task.title }
                ]
              },
              payload: { ref: task.__ref || task.id }
            });
            if (res && res.ok) {
              P.Entities.transitionStatus(task.__ref, task.status, 'acknowledged', P.Persona.email());
              P.UI.toastSuccess('Action acknowledged and logged.');
            }
          }
        }
      ],
      focusRef: (params && params.path && params.path[0]) || ''   // deep-link: #/orchestrator/<ref>
    });
  }
}
Modules.register(OrchestratorModule);
export default OrchestratorModule;
