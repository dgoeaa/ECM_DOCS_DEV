/**
 * OBSIDIAN v4.2 — Registry Service Endpoint Setup
 * Remediated (INT-01): Added updateTask export mapped to SUBSIDIARY_ACTIONS.
 */
import { BaseService } from '../../core/base-service.js';

export const fetchData = BaseService.endpoint('SUBSIDIARY_ACTIONS', { cache:15000, expectedKeys:['ok','data'] });
export const updateTask = BaseService.endpoint('SUBSIDIARY_ACTIONS', { expectedKeys: ['ok', 'data'] });
