import { BaseModule } from '../../core/base-module.js';
import { Modules } from '../../core/modules-registry.js';
import { el, clear } from '../../shared/utils/dom.js';
import { Lookups } from '../../shared/utils/lookups.js';
import { updateTask } from './service.js';

class RegistryModule extends BaseModule {
  static id = 'registry';
  static label = 'module.registry.title';
  static icon = 'git-branch';
  static nav = { group: 'INTAKE', order: 2 };
  static audience = 'general';
  static status = 'active';
  static base = new URL('.', import.meta.url);

  async onVisible(root) {
    this._root = root;
    this._region = root.querySelector('[data-region="content"]') || root;
    this._selectedRef = null;
    
    const E = globalThis.Platform.Entities;
    if (!E.isHydrated()) await E.bootstrap().catch(() => {});
    await Lookups.load();
    
    this.bus('entity:bootstrapped', () => this.paint());
    this.bus('entity:changed', () => this.paint());
    this.paint();
  }

  paint() {
    if (!this._region) return;
    clear(this._region);
    
    const E = globalThis.Platform.Entities;
    const refs = E.all('reference');

    // Two-column master-detail layout mirroring Unified Hub split
    const grid = el('div', { class: 'pf-list__split' });
    const leftPane = el('div', { class: 'pf-list__main' });
    const rightPane = el('aside', { class: 'pf-card pf-list__detail', style: 'padding:24px;border-top:3px solid var(--dgo-color-action-primary);' });
    
    grid.append(leftPane, rightPane);
    this._region.append(grid);

    const wrap = el('div', { class: 'pf-card pf-table-wrap' });
    leftPane.append(wrap);

    if (refs.length === 0) {
      wrap.append(el('div', { class: 'pf-empty' }, [el('div', { class: 'pf-empty__title', text: this.t('common.state.empty') })]));
      this._renderEmptyDetail(rightPane);
      return;
    }

    const head = el('thead', {}, [
      el('tr', {}, [
        el('th', { text: 'File Reference' }),
        el('th', { text: 'Subject / Directive' }),
        el('th', { text: 'Location DSU' }),
        el('th', { text: 'Status' })
      ])
    ]);

    const body = el('tbody', {}, refs.map(r => {
      const isSelected = this._selectedRef && (this._selectedRef.__ref === r.__ref || this._selectedRef.referenceId === r.referenceId);
      const tr = el('tr', { 
        'data-ref': r.referenceId || r.__ref, 
        style: 'cursor:pointer;', 
        tabindex: '0',
        'aria-selected': isSelected ? 'true' : 'false'
      }, [
        el('td', { text: r.referenceId || r.__ref, style: 'font-weight:600;' }),
        el('td', { text: r.title || 'Untitled Dossier' }),
        el('td', { text: r.__directorate || 'Central Mailroom' }),
        el('td', { html: `<span class="pf-badge pf-badge--${(r.status || 'pending').toLowerCase()}">${r.status || 'Pending'}</span>` })
      ]);

      tr.addEventListener('click', () => {
        this._selectedRef = r;
        this._highlightRow(wrap, tr);
        this._renderMinuteSheet(rightPane, r);
      });

      return tr;
    }));

    wrap.append(el('table', { class: 'pf-table pf-table--selectable' }, [head, body]));
    this._renderEmptyDetail(rightPane);
  }

  _highlightRow(container, tr) {
    container.querySelectorAll('tr').forEach(row => row.setAttribute('aria-selected', 'false'));
    tr.setAttribute('aria-selected', 'true');
  }

  _renderEmptyDetail(pane) {
    clear(pane);
    pane.append(el('div', { class: 'pf-detail__empty' }, [
      el('pf-icon', { name: 'git-branch', size: '24' }),
      el('p', { class: 'pf-muted', text: 'Select an active digital file to inspect official minute entries.' })
    ]));
  }

  _renderMinuteSheet(pane, ref) {
    clear(pane);
    const refId = ref.referenceId || ref.__ref;

    const sheet = document.createElement('pf-minute-sheet');
    sheet.reference = refId;
    sheet.style.marginBottom = 'var(--dgo-s-5)';

    const formWrap = el('div', { class: 'dgo-card dgo-card--sunken', style: 'padding:16px;' }, [
      el('h4', { class: 'pf-overline', text: 'Constitute New Minute', style: 'margin-bottom:12px' }),
      el('textarea', { id: 'reg-min-text', class: 'pf-input', rows: '3', placeholder: 'Enter directives or remarks...' }),
      el('div', { class: 'pf-toolbar', style: 'margin-top:12px' }, [
        el('button', { 
          class: 'pf-btn pf-btn--primary', 
          text: 'Append & Route',
          onClick: () => this._submitMinute(refId)
        })
      ])
    ]);

    pane.append(sheet, formWrap);
  }

  async _submitMinute(refId) {
    const textarea = this._root.querySelector('#reg-min-text');
    const text = textarea ? textarea.value.trim() : '';
    if (!text) return;

    const P = globalThis.Platform;
    const res = await P.Actions.run('route', {
      payload: { 
        ref: refId, 
        triageMeta: { comment: text },
        by: P.Persona.email()
      }
    });

    if (res.ok) {
      if (textarea) textarea.value = '';
      P.Entities.transitionStatus(refId, 'registered', 'triaged', P.Persona.email());
      this.paint(); 
    }
  }
}

Modules.register(RegistryModule);
export default RegistryModule;
