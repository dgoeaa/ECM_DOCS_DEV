/**
 * OBSIDIAN v4.2 — Executive Signature Chamber Module
 * Remediated: High-end executive approvals desk featuring chronological reviewer sequencers.
 */
import { BaseModule } from '../../core/base-module.js';
import { Modules } from '../../core/modules-registry.js';
import { submitDecision } from './service.js';
import { el, clear } from '../../shared/utils/dom.js';
import { emptyState } from '../../shared/utils/render.js';

class ApprovalsModule extends BaseModule {
  static id = 'approvals';
  static label = 'module.approvals.title';
  static icon = 'check-circle';
  static nav = { group: 'REVIEW', order: 1 };
  static audience = 'general';
  static status = 'active';
  static base = new URL('.', import.meta.url);

  async onVisible(root, params) {
    this._root = root;
    this._wrap = root.querySelector('.pf-ap');
    this._listEl = root.querySelector('[data-region="list"]');
    this._detailEl = root.querySelector('[data-region="detail"]');
    this._countEl = root.querySelector('[data-region="count"]');
    const refresh = root.querySelector('[data-act="refresh"]');
    if (refresh) this.on(refresh, 'click', () => this.refresh());

    const E = globalThis.Platform.Entities;
    if (!E.isHydrated()) await E.bootstrap().catch(() => {});
    this.bus('entity:approval:changed', () => this.load());
    this.bus('entity:reference:updated', () => this.load());
    this.bus('context:reference:changed', (e) => { if (e.source !== this.id) this.focusRef(e.ref); });

    this.load();
    const deep = params && params.path && params.path[0];
    if (deep) this.focusRef(deep);
  }

  pending() {
    return globalThis.Platform.Entities.all('approval')
      .filter((a) => !/approved|rejected|closed/i.test(String(a.status || a.Status || 'pending')));
  }

  load() {
    this._items = this.pending();
    this._countEl.textContent = this.t('approvals.pending', { n: this._items.length });
    this.renderList();
    if (this._items.length) this.select(0); else emptyState(this._detailEl, 'approvals.empty');
  }
  async refresh() { await globalThis.Platform.Entities.bootstrap(true); this.load(); }

  renderList() {
    clear(this._listEl);
    this._items.forEach((it, i) => {
      const item = el('button', { 
        class: 'pf-ap__item', 
        role: 'option',
        style: 'width:100%;text-align:left;padding:16px;border-bottom:1px solid var(--dgo-color-border-default);background:transparent;cursor:pointer;'
      }, [
        el('div', { class: 'row', style: 'display:flex;justify-content:space-between;align-items:center;' }, [
          el('span', { class: 'pf-badge pf-badge--routed', text: it.type || it.category || this.t('approvals.typeMemo') }),
          el('span', { class: 'when', text: it.ts ? this.fmt(it.ts) : '', style: 'font-size:11px;color:var(--dgo-color-fg-muted);' })
        ]),
        el('div', { class: 'ttl', text: it.title || it.subject || it.__ref || it.__id || '', style: 'font-weight:600;font-size:14px;color:var(--dgo-color-fg-strong);margin:4px 0;' }),
        el('div', { class: 'from', text: this.t('approvals.from', { who: it.from || it.initiator || it.assignedTo || '' }), style: 'font-size:12px;color:var(--dgo-color-fg-muted);' })
      ]);
      this.on(item, 'click', () => this.select(i));
      this._listEl.appendChild(item);
    });
  }

  select(i) {
    this._sel = i;
    [...this._listEl.children].forEach((c, idx) => {
      const active = idx === i;
      c.setAttribute('aria-selected', active ? 'true' : 'false');
      c.style.background = active ? 'var(--dgo-green-50)' : 'transparent';
      c.style.borderLeft = active ? '3px solid var(--dgo-color-action-primary)' : 'none';
    });
    if (this._wrap) this._wrap.setAttribute('data-mode', 'detail');
    const it = this._items[i];
    if (it && it.__ref) globalThis.Platform.Context.setActive(it.__ref, this.id);
    this.renderDetail(it);
  }
  focusRef(ref) {
    if (!ref || !this._items) return;
    const i = this._items.findIndex((x) => x.__ref === String(ref));
    if (i >= 0 && i !== this._sel) this.select(i);
  }

  renderDetail(it) {
    if (!it) return emptyState(this._detailEl, 'approvals.empty');
    clear(this._detailEl);
    const ref = it.__ref || it.__id || '';
    const related = ref ? globalThis.Platform.Entities.byReference(ref) : null;

    const head = el('div', { class: 'pf-ap__dethead', style: 'border-bottom:1px solid var(--dgo-color-border-default);padding-bottom:16px;margin-bottom:16px;' }, [
      el('div', {}, [
        el('div', { class: 'row', html: `<span class="pf-badge pf-badge--archived">${ref}</span> <span class="pf-badge pf-badge--pending">${this.t('approvals.statusPending')}</span>` }),
        el('h2', { text: it.title || it.subject || ref, style: 'font-size:22px;font-weight:700;margin:8px 0;color:var(--dgo-color-fg-strong);' }),
        el('p', { class: 'from', text: this.t('approvals.submittedBy', { who: it.from || it.initiator || '', date: it.ts ? this.fmt(it.ts) : '' }), style: 'font-size:12px;color:var(--dgo-color-fg-muted);margin:0;' })
      ]),
      el('div', { class: 'pf-ap__acts', style: 'display:flex;gap:8px;margin-top:12px;' }, [
        el('button', { class: 'dgo-btn dgo-btn--primary dgo-btn--sm', text: this.t('approvals.approve'), onClick: () => this.decide('approve', ref) }),
        el('button', { class: 'dgo-btn dgo-btn--danger dgo-btn--sm', text: this.t('approvals.reject'), onClick: () => this.decide('reject', ref) })
      ])
    ]);

    const summary = el('div', { class: 'pf-ap__sec', style: 'background:var(--dgo-color-surface-sunken);border:1px solid var(--dgo-color-border-default);border-radius:8px;padding:16px;margin-bottom:16px;' }, [
      el('h3', { text: this.t('approvals.summary'), style: 'font-size:12px;font-weight:600;text-transform:uppercase;color:var(--dgo-color-fg-muted);margin-bottom:8px;' }),
      el('p', { text: it.summary || it.body || it.description || this.t('common.state.empty'), style: 'margin:0;font-size:14px;line-height:1.5;' })
    ]);

    const links = el('div', { class: 'pf-ap__sec', style: 'border:1px solid var(--dgo-color-border-default);border-radius:8px;padding:16px;margin-bottom:16px;' }, [ el('h3', { text: this.t('approvals.related'), style: 'font-size:12px;font-weight:600;text-transform:uppercase;color:var(--dgo-color-fg-muted);margin-bottom:8px;' }) ]);
    const linkRow = el('div', { class: 'pf-ap__docs', style: 'display:flex;gap:8px;flex-wrap:wrap;' });
    if (related) {
      const map = [['email', 'correspondence'], ['comment', 'comments'], ['task', 'orchestrator'],
                   ['document', 'ops-hub'], ['activity', 'fasttrack'], ['reference', 'response-tracking']];
      for (const [type, mod] of map) {
        const n = type === 'reference' ? 1 : (related[type] || []).length;
        if (!n) continue;
        const b = el('button', { class: 'dgo-btn dgo-btn--secondary dgo-btn--sm',
          html: `${this.iconFor(type)} ${this.t('entity.' + type)} (${n})` });
        this.on(b, 'click', () => globalThis.Platform.goToEntity(ref, mod));
        linkRow.appendChild(b);
      }
    }
    if (!linkRow.children.length) linkRow.appendChild(el('span', { class: 'from', text: this.t('common.state.empty') }));
    links.appendChild(linkRow);

    const minute = el('div', { class: 'pf-ap__sec pf-ap__minute', style: 'background:var(--dgo-color-success-subtle-bg);border:1px solid var(--dgo-color-success-subtle-fg);border-radius:8px;padding:16px;' }, [
      el('h3', { text: this.t('approvals.minute'), style: 'font-size:12px;font-weight:600;text-transform:uppercase;color:var(--dgo-color-success-subtle-fg);margin-bottom:8px;' }),
      el('textarea', { id: 'ap-comment', class: 'dgo-textarea', rows: '3', placeholder: this.t('approvals.minutePlaceholder') }),
      el('div', { class: 'pf-ap__sign', style: 'margin-top:12px;' }, [ el('label', { class: 'dgo-check', html: `<input type="checkbox" id="ap-sign"> ${this.t('approvals.sign')}` }) ])
    ]);
    this._detailEl.append(head, summary, links, minute);
  }

  async decide(kind, ref) {
    const comment = (this._detailEl.querySelector('#ap-comment') || {}).value || '';
    const signed = !!(this._detailEl.querySelector('#ap-sign') || {}).checked;
    if (kind === 'reject' && !comment.trim()) { globalThis.Platform.UI.toast({ messageKey: 'approvals.needReason', variant: 'warning' }); return; }
    const ok = await globalThis.Platform.UI.confirm({
      titleKey: kind === 'approve' ? 'approvals.confirmApproveTitle' : 'approvals.confirmRejectTitle',
      summaryKey: kind === 'approve' ? 'approvals.confirmApproveBody' : 'approvals.confirmRejectBody',
      details: [ { label: this.t('entity.reference'), value: ref }, { label: this.t('approvals.minute'), value: comment || '\u2014' }, { label: this.t('approvals.sign'), value: signed ? '\u2713' : '\u2014' } ],
      confirmKey: kind === 'approve' ? 'approvals.approve' : 'approvals.reject', danger: kind === 'reject' });
    if (!ok) return;
    this.commit(kind, ref, comment, signed);
  }

  async commit(kind, ref, comment, signed) {
    const decision = kind === 'approve' ? 'Approved' : 'Rejected';
    const P = globalThis.Platform;
    const persona = (P.Persona?.current && P.Persona.current()) || 'web-ops';
    const userEmail = (P.Persona?.email && P.Persona.email()) || `${persona}@nitda.gov.ng`;
    const refRow = P.Entities?.byReference?.(ref)?.reference || {};
    const title = refRow.title || refRow.subject || ref;
    const actionName = kind === 'approve' ? 'ACKNOWLEDGE' : 'UPDATE_TASK';
    const existing = (this._items[this._sel] || {});

    const R = P.Reviewers;
    const chain = existing.reviewers || existing.Reviewers || null;
    let reviewersOut = null, chainComplete = true;
    if (R && Array.isArray(chain) && chain.length) {
      const act = R.active(chain);
      if (!act) { P.UI.toast({ messageKey: 'approvals.reviewerComplete', variant: 'info' }); return; }
      const adv = R.advance(chain, act.sequence, kind === 'approve' ? 'approve' : 'reject', { comment });
      if (!adv.ok) { P.UI.toast({ messageKey: 'approvals.reviewerLocked', variant: 'warning' }); return; }
      reviewersOut = adv.reviewers;
      chainComplete = kind === 'approve' ? adv.complete : true;
    }

    const payload = {
      action: actionName, method: 'POST', userEmail,
      AssignmentType: actionName,
      Selected: { ID: ref, RefIDD: String(ref), Title: title },
      RefIDD: String(ref),
      ...(kind === 'approve' ? { decision, comment, signed } : { status: decision, reason: comment }),
      ...(reviewersOut ? { reviewers: reviewersOut } : {}),
      payload: {
        selection: { single: { ID: ref, RefIDD: String(ref), Title: title }, items: [] },
        decision: kind === 'approve' ? { value: decision, comment, signed } : { value: decision, reason: comment },
        ...(reviewersOut ? { reviewers: reviewersOut } : {})
      }
    };
    
    const result = await this.call(submitDecision, payload);
    if (result.ok) {
      const nextStatus = (kind === 'approve' && !chainComplete) ? (existing.status || 'pending-review') : decision;
      globalThis.Platform.Entities.upsert('approval', { ...existing, referenceId: ref, status: nextStatus, ...(reviewersOut ? { reviewers: reviewersOut } : {}) });
      
      // Remediated: corrected the variable reference (refRow instead of refRec)
      if (kind === 'approve' && chainComplete) {
        globalThis.Platform.Entities.transitionStatus(ref, refRow.status || 'pending-review', 'approved', userEmail);
      } else if (kind === 'reject') {
        globalThis.Platform.Entities.transitionStatus(ref, refRow.status || 'pending-review', 'returned', userEmail);
      }

      const doneKey = (kind === 'approve' && !chainComplete) ? 'approvals.reviewerAdvanced' : (kind === 'approve' ? 'approvals.approved' : 'approvals.rejected');
      globalThis.Platform.UI.actionCompleted(doneKey, { module: 'approvals', target: existing.__ref || existing.referenceId || ref });
    }
  }

  iconFor(t) { return { email: '✉️', comment: '💬', task: '⚡', document: '📁', activity: '📈', reference: '📊' }[t] || '📄'; }
  fmt(v) { return globalThis.Platform?.Format?.dateTime ? globalThis.Platform.Format.dateTime(v) : String(v); }
}
Modules.register(ApprovalsModule);
export default ApprovalsModule;