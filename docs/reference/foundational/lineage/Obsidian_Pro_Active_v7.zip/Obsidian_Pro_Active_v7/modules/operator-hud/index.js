import { BaseModule } from '../../core/base-module.js';
import { Modules } from '../../core/modules-registry.js';
import { el, clear } from '../../shared/utils/dom.js';
import { renderSlaMeter } from '../../shared/utils/lens.js';

class OperatorHudModule extends BaseModule {
  static id = 'operator-hud';
  static label = 'module.operator-hud.title';
  static icon = 'globe';
  static nav = { group: 'CrossPhase', order: 0 };
  static audience = 'all';
  static status = 'active';
  static base = new URL('.', import.meta.url);

  async onVisible(root) {
    this._region = root.querySelector('[data-region="content"]');
    const E = globalThis.Platform.Entities;

    if (!E.isHydrated()) await E.bootstrap().catch(() => {});

    this.bus('entity:bootstrapped', () => this.paint());
    this.bus('entity:changed', () => this.paint());
    
    this.paint();
  }

  paint() {
    if (!this._region) return;
    clear(this._region);

    const E = globalThis.Platform.Entities;
    const counts = E.counts();
    const tasks = E.all('task');

    const kpiGrid = el('section', { class: 'hud-kpis' }, [
      this._mkKpi('total', counts.reference || 0, 'var(--dgo-info-600)'),
      this._mkKpi('pending', counts.task || 0, 'var(--dgo-warn-600)'),
      this._mkKpi('overdue', counts.overdue?.count || 0, 'var(--dgo-danger-600)'),
      this._mkKpi('closed', (counts.byStatus?.['closed'] || 0) + (counts.byStatus?.['completed'] || 0), 'var(--dgo-smart-500)')
    ]);

    const matrix = el('section', { class: 'hud-matrix pf-card' }, [
      el('div', { class: 'hud-matrix__hdr' }, [
        el('h2', { text: this.t('module.operator-hud.title') }),
        el('pf-identity-box')
      ]),
      this._renderTable(tasks)
    ]);

    this._region.append(kpiGrid, matrix);
  }

  _mkKpi(key, val, color) {
    return el('div', { class: 'hud-kpi', style: `--kpi-clr: ${color}` }, [
      el('div', { class: 'hud-kpi-lbl', text: this.t(`hud.kpi.${key}`) }),
      el('div', { class: 'hud-kpi-val', text: String(val) })
    ]);
  }

  _renderTable(tasks) {
    if (!tasks.length) return el('div', { class: 'pf-empty', text: this.t('common.state.empty') });

    const table = el('table', { class: 'pf-table' }, [
      el('thead', {}, [
        el('tr', {}, [
          el('th', { text: this.t('hud.matrix.id') }),
          el('th', { text: this.t('hud.matrix.subject') }),
          el('th', { text: this.t('field.assignedTo.label') }),
          el('th', { text: this.t('hud.matrix.health') }),
          el('th', { style: 'text-align:right', text: 'Action' })
        ])
      ]),
      el('tbody', {}, tasks.map(t => el('tr', { class: 'hud-row' }, [
        el('td', { class: 'font-mono', text: t.id || t.__ref, style: 'font-weight:700; font-size:11px' }),
        el('td', { text: t.title || t.subject, style: 'font-weight:600' }),
        el('td', { text: t.assignedTo || 'Unassigned', class: 'pf-muted' }),
        el('td', { html: renderSlaMeter(t) }),
        el('td', { style: 'text-align:right' }, [
          el('button', { 
            class: 'pf-btn pf-btn--primary pf-btn--sm', 
            text: 'Trace', 
            onClick: () => globalThis.Platform.goToEntity(t.__ref, 'response-tracking') 
          })
        ])
      ])))
    ]);

    return el('div', { class: 'pf-table-wrap' }, [table]);
  }
}

Modules.register(OperatorHudModule);
export default OperatorHudModule;
