import { BaseModule } from '../../core/base-module.js';
import { Modules } from '../../core/modules-registry.js';
import { el, clear } from '../../shared/utils/dom.js';

class AckFlowModule extends BaseModule {
  static id = 'ackflow';
  static label = 'module.ackflow.title';
  static icon = 'check-circle';
  static nav = { group: 'ACTION', order: 5 };
  static audience = 'general';
  static status = 'active';
  static base = new URL('.', import.meta.url);

  async onVisible(root) {
    /* AUDIT-FIX P22/SEC-06: store root reference before any this.$() calls */
    this._root = root;
    this._region = root.querySelector('[data-region="content"]') || root;
    this._selectedTask = null;

    const E = globalThis.Platform.Entities;
    if (!E.isHydrated()) await E.bootstrap().catch(() => {});

    this.bus('entity:changed', () => this.paint());
    this.bus('entity:bootstrapped', () => this.paint());

    /* AUDIT-FIX P22/SEC-06: root.querySelector is safe before this.$() is available */
    this.on(root.querySelector('#af-refresh-btn'), 'click', () => this.refresh());
    this.paint();
  }

  async refresh() {
    await globalThis.Platform.Entities.bootstrap(true);
    this.paint();
  }

  paint() {
    const E = globalThis.Platform.Entities;
    const tasks = E.all('task') || [];
    
    const pendingVal = this.$('#af-pending-val');
    const ackedVal = this.$('#af-acked-val');
    const tbody = this.$('#af-task-rows');
    const detailPane = this.$('#af-detail-pane');

    if (!tbody) return;
    clear(tbody);

    let pendingCount = 0;
    let ackedCount = 0;

    if (!tasks.length) {
      tbody.append(
        el('tr', {}, [
          el('td', {
            colspan: '2',
            style: 'text-align:center; padding:var(--space-5); color:var(--color-text-muted);',
            text: 'No compliance tasks available.',
          }),
        ]),
      );
      this.renderDetail(null, detailPane);
      return;
    }

    tasks.forEach((t, i) => {
      const isAcked = /acknowledge/i.test(t.status || '');
      if (isAcked) ackedCount++; else pendingCount++;

      const tr = el('tr', { style: 'cursor:pointer;', 'aria-selected': this._selectedTask === t ? 'true' : 'false' }, [
        el('td', {}, [
          el('div', { style: 'font-weight: 600; color: var(--color-text);', text: t.title || t.subject }),
          el('div', { style: 'font-size: 11px; font-family: var(--font-mono); color: var(--color-text-muted); margin-top: 2px;', text: `ID: ${t.id || t.__ref}` })
        ]),
        el('td', {}, [
          el('span', { class: `pf-badge pf-badge--${isAcked ? 'replied' : 'pending'}`, text: t.status || 'Pending' })
        ])
      ]);

      this.on(tr, 'click', () => {
        this._selectedTask = t;
        [...tbody.children].forEach((row) => row.setAttribute('aria-selected', 'false'));
        tr.setAttribute('aria-selected', 'true');
        this.renderDetail(t, detailPane);
      });

      tbody.appendChild(tr);
    });

    if (pendingVal) pendingVal.textContent = String(pendingCount);
    if (ackedVal) ackedVal.textContent = String(ackedCount);

    if (this._selectedTask) {
      const stillExists = tasks.find(t => (t.id || t.__ref) === (this._selectedTask.id || this._selectedTask.__ref));
      this.renderDetail(stillExists || null, detailPane);
    } else {
      this.renderDetail(tasks[0], detailPane);
    }
  }

  renderDetail(task, pane) {
    clear(pane);
    if (!task) {
      pane.append(el('div', { class: 'pf-detail__empty' }, [
        el('pf-icon', { name: 'check-circle', size: '24' }),
        el('p', { class: 'pf-muted', text: 'Select an active compliance record to display dispatch preview.' })
      ]));
      return;
    }

    const ref = task.__ref || task.id || '';
    const isAcked = /acknowledge/i.test(task.status || '');

    pane.append(
      el('div', { class: 'pf-detail__head', style: 'border-bottom:1px solid var(--color-border); padding-bottom:12px; margin-bottom:16px;' }, [
        el('div', {}, [
          el('span', { class: 'pf-badge pf-badge--archived', text: ref }),
          el('h3', { text: task.title || task.subject, style: 'font-size:18px; font-weight:700; margin:8px 0;' })
        ]),
        el('span', { class: `pf-badge pf-badge--${isAcked ? 'replied' : 'pending'}`, text: task.status })
      ]),
      el('div', { class: 'af-detail__workspace' }, [
        el('div', { class: 'af-detail__email-preview' }, [
          el('span', { class: 'pf-overline', text: 'Email Dispatch Coordinates' }),
          el('div', { style: 'font-size:12px; margin-top:8px;', html: `<strong>From:</strong> DGO Digital Ops &lt;noreply@dgo.gov.ng&gt;<br><strong>Subject:</strong> Action Required: Please Acknowledge ${task.title}` })
        ]),
        el('div', { style: 'display:flex; gap:8px;' }, [
          el('button', {
            class: `pf-btn ${isAcked ? 'pf-btn-disabled' : 'pf-btn--primary'}`,
            style: 'flex:1;',
            text: isAcked ? 'Acknowledgment Logged' : 'Acknowledge Receipt',
            disabled: isAcked ? 'disabled' : null,
            onClick: () => this.submitAck(task)
          }),
          el('button', {
            class: 'pf-btn pf-btn--ghost',
            text: 'Track History',
            onClick: () => globalThis.Platform.goToEntity(ref, 'response-tracking')
          })
        ])
      ])
    );
  }

  async submitAck(task) {
    const P = globalThis.Platform;
    const ref = task.__ref || task.id || '';
    
    const ok = await P.UI.confirm({
      titleKey: 'module.ackflow.title',
      summaryKey: 'Are you sure you want to acknowledge this compliance task?',
      confirmKey: 'common.actions.confirm',
      details: [
        { label: 'Reference ID', value: ref },
        { label: 'Task Title', value: task.title || task.subject }
      ]
    });
    if (!ok) return;

    const res = await P.Entities.transitionStatus(ref, task.status || 'Pending', 'acknowledged', P.Persona.email());
    if (res.ok) {
      P.UI.toastSuccess('Compliance acknowledgment recorded and logged.');
      this.paint();
    }
  }
}

Modules.register(AckFlowModule);
export default AckFlowModule;
