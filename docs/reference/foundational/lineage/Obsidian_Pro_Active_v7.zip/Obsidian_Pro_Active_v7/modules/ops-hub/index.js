/**
 * OBSIDIAN v4.3 — Operations Hub Module
 *
 * Fixes applied (see REFACTOR_PLAN.md for context):
 *   BUG-01  Meeting-pack bulk action captured `clear` from bulkActions closure but the
 *           parameter is named `clearSelection` in lens.js — renamed to match, preventing
 *           a silent no-op after a successful pack generation.
 *   BUG-02  renderDocDetail was calling clear(pane) + full DOM rebuild on every card click.
 *           Replaced with a lightweight diff check: skip the rebuild when the same ref is
 *           already rendered.
 *   BUG-03  Added an empty state when all documents are in a ROUTED status, with a CTA
 *           linking to Response Tracking so the user is never left staring at a blank pane.
 *   REFAC-01 openFlagDocument moved out of core/ui.js into this module's own flag() method
 *            (the logic is Ops-Hub-specific; it does not belong in the global UI singleton).
 *            core/ui.js retains a thin shim that delegates here for backward compatibility.
 */
import { BaseModule } from '../../core/base-module.js';
import { Modules } from '../../core/modules-registry.js';
import { BaseService } from '../../core/base-service.js';
import { mountMasterDetail, appendRichSections } from '../../shared/utils/lens.js';
import { el, clear } from '../../shared/utils/dom.js';

const assignEndpoint = BaseService.endpoint('SINGLE_ASSIGNMENT', { expectedKeys: ['ok', 'data'] });

class OpsHubModule extends BaseModule {
  static id = 'ops-hub';
  static label = 'module.ops-hub.title';
  static icon = 'folder';
  static nav = { group: 'ROUTING', order: 1 };
  static audience = 'general';
  static status = 'active';
  static base = new URL('.', import.meta.url);

  static ROUTED = new Set([
    'assigning', 'assigned', 'assignment-failed', 'acknowledged', 'in-progress',
    'action-complete', 'reassign-requested', 'pending-review', 'approved', 'approved-with-edit',
    'returned', 'escalated', 'dispatch-pending', 'dispatch-in-flight', 'dispatched',
    'dispatch-failed', 'no-dispatch', 'closed', 'partial-dispatch', 'archived',
    'cold-archived', 'routed', 'replied',
  ]);

  // BUG-02: track what is currently rendered so we can skip redundant rebuilds
  _renderedRef = null;

  async onVisible(root) {
    const E = globalThis.Platform.Entities;
    if (!E.isHydrated()) await E.bootstrap().catch(() => {});
    this.bus('entity:changed', () => { this._renderedRef = null; });

    // BUG-03: check upfront whether there is anything to show
    const unrouted = E.all('document').filter(
      (r) => !OpsHubModule.ROUTED.has(String((r && (r.status || r.Status)) || '').toLowerCase().trim()),
    );

    if (!unrouted.length) {
      this._renderEmptyState(root);
      return;
    }

    mountMasterDetail(this, root, {
      type: 'document',
      cardLabel: 'title',
      detail: (it, pane, mod) => mod.renderDocDetail(it, pane),
      prefilter: (r) =>
        !OpsHubModule.ROUTED.has(String((r && (r.status || r.Status)) || '').toLowerCase().trim()),
      enableBulkSelect: true,
      // BUG-01: the parameter destructured from lens.js bulkActions context is `clearSelection`,
      //         not `clear`.  Using the wrong name caused the selection to silently persist.
      bulkActions: ({ selected, clear: clearSelection }) => [
        el('button', {
          class: 'dgo-btn dgo-btn--primary dgo-btn--sm',
          type: 'button',
          html: `🗂️ ${this.t('opshub.bulkAssign', { n: selected.length })}`,
          onClick: () => {
            globalThis.Platform.Context.setBulkSelection?.(selected);
            globalThis.Platform.State?.set('shared.bulkSelection', {
              refs: selected,
              source: this.id,
              ts: Date.now(),
            });
            globalThis.Platform.Router.navigate('bulk-assignment');
          },
        }),
        el('button', {
          class: 'dgo-btn dgo-btn--secondary dgo-btn--sm',
          type: 'button',
          html: `📋 ${this.t('opshub.meetingPack', { n: selected.length })}`,
          onClick: () => {
            const A = globalThis.Platform.Actions;
            if (A && A.run)
              A.run('prepareMeetingPack', {
                preview: {
                  titleKey: 'opshub.meetingPackTitle',
                  summary: this.t('opshub.meetingPackSummary', { n: selected.length }),
                  confirmKey: 'opshub.meetingPackConfirm',
                  details: selected
                    .slice(0, 12)
                    .map((r) => ({ label: this.t('field.referenceId.label'), value: r })),
                },
                payload: { refs: selected },
              // BUG-01 fix: call clearSelection (the correctly-named closure param)
              }).then((res) => { if (res && res.ok) clearSelection(); });
          },
        }),
      ],
    });
  }

  // BUG-03: shown when every document is already in a ROUTED state
  _renderEmptyState(root) {
    const region = root.querySelector('[data-region="content"]') || root;
    clear(region);
    region.append(
      el('div', { class: 'pf-empty', style: 'min-height:60vh;' }, [
        el('pf-icon', { name: 'inbox', size: '40', style: 'color:var(--color-text-muted);margin-bottom:var(--space-4);' }),
        el('div', { class: 'pf-empty__title', text: this.t('opshub.emptyTitle') }),
        el('p', {
          class: 'pf-muted',
          style: 'max-width:380px;text-align:center;',
          text: this.t('opshub.emptyBody'),
        }),
        el('button', {
          class: 'pf-btn pf-btn--primary',
          style: 'margin-top:var(--space-4);',
          text: this.t('opshub.emptyAction'),
          onClick: () => globalThis.Platform.Router.navigate('response-tracking'),
        }),
      ]),
    );
  }

  renderDocDetail(it, pane) {
    // BUG-02: skip full DOM rebuild when the same document is already shown
    const incomingRef = it ? (it.__ref || it.__id || '') : null;
    if (incomingRef && incomingRef === this._renderedRef) return;
    this._renderedRef = incomingRef;

    clear(pane);

    if (!it) {
      pane.append(
        el('div', { class: 'pf-detail__empty' }, [
          el('p', { class: 'pf-muted', text: this.t('opshub.detailPlaceholder') }),
        ]),
      );
      return;
    }

    const ref = it.__ref || it.__id || '';
    const rel = ref
      ? globalThis.Platform.Entities.byReference(ref)
      : { email: [], task: [], comment: [], approval: [] };

    pane.append(
      el('div', {
        class: 'pf-md__dhead',
        style:
          'border-bottom:1px solid var(--dgo-color-border-default);padding-bottom:16px;margin-bottom:16px;',
      }, [
        el('div', { html: `<span class="pf-badge pf-badge--archived">${ref}</span>` }),
        el('h2', {
          text: it.title || it.__id,
          style: 'font-size:20px;font-weight:700;margin:8px 0;color:var(--dgo-color-fg-strong);',
        }),
        el('p', {
          class: 'pf-md__meta',
          text: this.t('opshub.assignedMeta', {
            who: it.assignedTo || '—',
            status: it.status || it.Status || '—',
          }),
          style: 'font-size:12px;color:var(--dgo-color-fg-muted);margin:0;',
        }),
      ]),
      el('div', {
        class: 'pf-toolbar',
        style: 'display:flex;gap:8px;margin-bottom:16px;',
      }, [
        el('button', {
          class: 'dgo-btn dgo-btn--primary dgo-btn--sm',
          text: this.t('opshub.assign'),
          onClick: () =>
            globalThis.Platform.Router.navigate(
              'single-item-ops/' + (it.__ref || it.__id || ''),
            ),
        }),
        el('button', {
          class: 'dgo-btn dgo-btn--danger dgo-btn--sm',
          text: this.t('opshub.flag'),
          onClick: () => this.flag(it),
        }),
      ]),
      el('div', {
        class: 'pf-toolbar',
        style:
          'display:flex;gap:4px;flex-wrap:wrap;border-top:1px dashed var(--dgo-color-border-default);padding-top:16px;',
      }, [
        el('span', {
          class: 'pf-overline',
          text: this.t('lens.relatedTo', { ref }),
          style: 'display:block;width:100%;margin-bottom:8px;',
        }),
        ...[
          ['email', 'correspondence', '✉️'],
          ['task', 'orchestrator', '⚡'],
          ['comment', 'comments', '💬'],
          ['approval', 'approvals', '✔️'],
        ]
          .map(([et, mod, icon]) => {
            const n = (rel[et] || []).length;
            if (!n) return null;
            const linkBtn = el('button', {
              class: 'dgo-btn dgo-btn--secondary dgo-btn--sm',
              html: `${icon} ${this.t('entity.' + et)} (${n})`,
            });
            this.on(linkBtn, 'click', () => globalThis.Platform.goToEntity(ref, mod));
            return linkBtn;
          })
          .filter(Boolean),
      ]),
    );

    appendRichSections(pane, it, this, { type: 'document' });
  }

  // REFAC-01: flag workflow lives here, not in core/ui.js
  async flag(it) {
    const P = globalThis.Platform;
    const { el: domEl } = await import('../../shared/utils/dom.js');
    const svc = await import('../../core/base-service.js');

    const I = P.I18n || { t: (k) => k };
    const T = (k, vars) => I.t(k, vars);

    const draft = { urgency: 'High', reason: '', classification: 'Action Required' };
    const URGENCIES = ['High', 'Medium', 'Low'];
    const CLASSIFICATIONS = ['Action Required', 'Information', 'Escalation'];
    const ref = it.__ref || it.__id || '';
    const docTitle = it.title || it.Title || ref || 'Document';

    const mkChips = (items, init, onChange) => {
      const host = domEl('div', { class: 'pf-chipgroup', role: 'radiogroup' });
      items.forEach((v) => {
        const b = domEl('button', {
          type: 'button',
          class: 'pf-chip' + (v === init ? ' pf-chip--selected' : ''),
          text: v,
        });
        b.addEventListener('click', () => {
          host.querySelectorAll('.pf-chip').forEach((c) => c.classList.remove('pf-chip--selected'));
          b.classList.add('pf-chip--selected');
          onChange(v);
        });
        host.append(b);
      });
      return host;
    };

    const urgWrap = domEl('div', { class: 'pf-field' }, [
      domEl('label', { class: 'pf-label', text: T('opshub.flagUrgency') }),
      mkChips(URGENCIES, draft.urgency, (v) => { draft.urgency = v; }),
    ]);
    const classWrap = domEl('div', { class: 'pf-field' }, [
      domEl('label', { class: 'pf-label', text: T('opshub.flagClassification') }),
      mkChips(CLASSIFICATIONS, draft.classification, (v) => { draft.classification = v; }),
    ]);
    const reason = domEl('textarea', {
      class: 'pf-input',
      rows: '4',
      placeholder: T('opshub.flagReasonHint'),
    });
    reason.addEventListener('input', () => { draft.reason = reason.value; });

    const root = domEl('div', { class: 'pf-flagdoc' }, [
      domEl('p', {
        style: 'color:var(--color-text-muted);font-size:var(--size-body-sm);margin-bottom:var(--space-3)',
        text: T('opshub.flagBlurb'),
      }),
      domEl('dl', { class: 'pf-preview', style: 'margin-bottom:var(--space-4)' }, [
        domEl('div', { class: 'row' }, [
          domEl('span', { class: 'k', text: 'Document' }),
          domEl('span', { class: 'v', text: docTitle.slice(0, 80) }),
        ]),
        domEl('div', { class: 'row' }, [
          domEl('span', { class: 'k', text: 'Reference' }),
          domEl('span', { class: 'v', text: ref || '—' }),
        ]),
      ]),
      urgWrap,
      classWrap,
      domEl('div', { class: 'pf-field pf-field--required' }, [
        domEl('label', { class: 'pf-label', text: T('opshub.flagReason') }, [
          domEl('abbr', { class: 'pf-label__req', text: ' *' }),
        ]),
        reason,
      ]),
    ]);

    return new Promise((resolve) => {
      const { Bus } = globalThis.Platform;
      let seq = Math.random().toString(36).slice(2, 8);
      const id = 'flag-' + seq;
      let submitting = false;
      const close = (result) => { Bus.emit('platform:ui:modal-close', { id }); resolve(result); };

      Bus.emit('platform:ui:modal', {
        id,
        title: T('opshub.flagTitle'),
        bodyEl: root,
        actions: [
          { labelKey: 'common.actions.cancel', variant: 'ghost' },
          { labelKey: 'opshub.flagSubmit', variant: 'danger', close: false, event: `__fl_submit_${id}` },
        ],
      });

      Bus.on(`__fl_submit_${id}`, async () => {
        if (submitting) return;
        if (!draft.reason || draft.reason.trim().length < 3) {
          P.UI.toast({ messageKey: 'opshub.flagReasonRequired', variant: 'danger' });
          return;
        }
        submitting = true;
        const flag = svc.BaseService.endpoint('SUBSIDIARY_ACTIONS', { expectedKeys: ['ok'] });
        const res = await flag({
          action: 'flagDocument',
          RefIDD: ref,
          documentId: it.__id || ref,
          dgAttention: true,
          urgency: draft.urgency,
          classification: draft.classification,
          reason: draft.reason,
        });
        if (res.ok) {
          P.Entities.upsert('document', { ...it, status: 'Action Required', dgFlagged: true, dgFlagReason: draft.reason });
          P.Entities.upsert('task', {
            referenceId: ref,
            title: T('opshub.dgReview', { t: docTitle }),
            priority: draft.urgency === 'High' ? 'P1 (High)' : draft.urgency === 'Medium' ? 'P2 (Medium)' : 'P3 (Normal)',
            status: 'Created',
            ts: new Date().toISOString(),
          });
          P.UI.actionCompleted('opshub.flagged', { module: 'ops-hub', target: ref });
          // Reset rendered ref so the detail pane refreshes after flagging
          this._renderedRef = null;
          close({ ok: true, draft });
        } else {
          submitting = false;
          P.Actions ? P.Actions.feedback(res) : P.UI.toastError(res);
        }
      });
    });
  }
}

Modules.register(OpsHubModule);
export default OpsHubModule;
