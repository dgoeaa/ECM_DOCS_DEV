/** OBSIDIAN v4.3 — nav-controller.js — FIX-BATCH-2
 *
 *  BUGS FIXED:
 *  1. WELCOME VIEW NOT ACTIVE — On first load, the router emits
 *     'platform:nav:changed' with id='home' but Nav.init() had not yet called
 *     publish(), so activeId was null. The nav rendered all items as inactive.
 *     Fix: initialise activeId from RoutesConfig.defaultRoute so the first
 *     publish() marks the landing module active.
 *  2. NAV BADGE COUNTS — badge values from State were not re-read on each rebuild;
 *     stale counts from the previous publish were emitted. Fixed: badges are
 *     resolved lazily from State on every build() call.
 */
import { Bus } from './bus.js';
import { Modules } from './modules-registry.js';
import { Persona } from './persona-controller.js';
import { NAV_GROUPS, UTILITY_ACTIONS } from '../config/nav.config.js';
import { FeatureFlags } from '../config/feature-flags.config.js';
import { RoutesConfig } from '../config/routes.config.js';
import { State } from './state.js';

// FIX-1: Pre-seed with the default route so first publish is correct
let activeId = RoutesConfig.defaultRoute || null;

function resolveItemBadge(item) {
  // Supports static badge value or a state-path string like 'shared.notifications.count'
  if (!item.badge) return null;
  if (typeof item.badge === 'string' && item.badge.includes('.')) {
    const val = State.get(item.badge, null);
    return (val != null && val !== 0) ? String(val) : null;
  }
  return item.badge;
}

function build() {
  const persona = Persona.current();
  const grouped = Modules.navGroups(persona);
  const groups = NAV_GROUPS
    .map((g) => ({
      id: g.id,
      labelKey: g.labelKey,
      items: (grouped[g.id] || []).map((it) => ({
        ...it,
        active: it.id === activeId,
        badge: resolveItemBadge(it)   // FIX-2: re-resolve badge on every build
      }))
    }))
    .filter((g) => g.items.length);

  const utils = UTILITY_ACTIONS.filter((u) => !u.flag || FeatureFlags[u.flag] === true);
  return { groups, utils, activeId };
}

function publish() {
  Bus.emit('platform:nav:rebuilt', build());
}

export const Nav = {
  init() {
    Bus.on('platform:nav:changed', (e) => {
      activeId = e.id;
      publish();
    });
    Bus.on('platform:persona:changed', publish);
    Bus.on('platform:state:changed', (e) => {
      if (e.path && (e.path.startsWith('shared.notifications') || e.path.startsWith('shared.badges'))) {
        publish();
      }
    });
    // FIX-1: Initial publish uses the pre-seeded activeId
    publish();
  },
  model: build,
  active() { return activeId; }
};

export default Nav;
