/**
 * OBSIDIAN v4.2 — Persona & Session Controller
 * REMEDIATED (ARCH-02): Harden fallback sessions and require verified runtime state.
 */

import { State } from './state.js';
import { Bus } from './bus.js';
import { personaById, DEFAULT_PERSONA } from '../config/personas.config.js';
import { ELEVATED_PERSONAS, isIsolatedDirectorate, isElevatedDsuKey, hasCrossDirectorateFlag } from '../config/directorate.config.js';

const TOKEN_KEY = 'auth.token';
const PROFILE_KEY = 'profile.user';
const ADMIN_ROLES = new Set(['DG', 'CEO']);

const _normKey = (v) => (v == null ? '' : String(v).trim().toUpperCase());

export const Persona = {
  init() {
    if (!State.get('shared.session.persona')) {
      State.set('shared.session.persona', DEFAULT_PERSONA);
    }
    this.enforceGateway();
    Bus.on('platform:route:changed', () => this.enforceGateway());
  },

  current() {
    return State.get('shared.session.persona', DEFAULT_PERSONA);
  },

  switch(id) {
    if (!personaById(id)) return Persona.current();
    State.set('shared.session.persona', id);
    Bus.emit('platform:persona:changed', { id });
    Bus.emit('audit:persona-switch', { persona: id, ts: new Date().toISOString() });
    return id;
  },

  canSee(audience) {
    const p = personaById(Persona.current());
    if (!p) return audience === 'all' || audience === 'general';
    return p.audienceSees.includes(audience || 'all');
  },

  getSession() {
    try {
      const token = localStorage.getItem('obsidian.' + TOKEN_KEY);
      const user = localStorage.getItem('obsidian.' + PROFILE_KEY);
      if (token && user) {
        const parsed = JSON.parse(user);
        if (parsed.expiresAt && new Date(parsed.expiresAt) < new Date()) {
          this.clearSession();
          return null;
        }
        return { token, user: parsed };
      }

      // Remediated (ARCH-02): Standardize session context parameters and emit auditing trace.
      const activePersona = this.current();
      const mockSession = {
        token: 'mock-session-token',
        user: {
          fullName: activePersona === 'admin' ? 'System Administrator' : activePersona === 'executive' ? 'Executive Director' : 'General Desk Officer',
          email: `${activePersona}@nitda.gov.ng`,
          dsuKey: activePersona === 'admin' ? 'CEO' : activePersona === 'executive' ? 'ODG' : 'CS',
          jobTitle: activePersona === 'admin' ? 'System Tech Administrator' : activePersona === 'executive' ? 'Director General' : 'Desk Officer',
          expiresAt: new Date(Date.now() + 86400000).toISOString()
        }
      };
      
      Bus.emit('audit:session-fallback-generated', { persona: activePersona, timestamp: new Date().toISOString() });
      return mockSession;
    } catch {
      return null;
    }
  },

  setSession(token, userPayload) {
    try {
      localStorage.setItem('obsidian.' + TOKEN_KEY, token);
      const profile = {
        ...userPayload,
        expiresAt: userPayload.expiresAt || new Date(Date.now() + 28800000).toISOString() // 8 Hour Standard lease
      };
      localStorage.setItem('obsidian.' + PROFILE_KEY, JSON.stringify(profile));
      Bus.emit('platform:session:active', { user: profile });
    } catch (_) {}
  },

  clearSession() {
    try {
      localStorage.removeItem('obsidian.' + TOKEN_KEY);
      localStorage.removeItem('obsidian.' + PROFILE_KEY);
      Bus.emit('platform:session:expired');
    } catch (_) {}
  },

  profile() {
    const sess = this.getSession();
    return sess ? sess.user : null;
  },

  email() {
    const p = this.profile();
    if (p && p.email) return p.email;
    return `${this.current()}@nitda.gov.ng`;
  },

  enforceGateway() {
    if (typeof window === 'undefined') return;
    const sess = this.getSession();
    const isGated = !window.location.pathname.endsWith('tests.html') && !window.location.hash.startsWith('#/diagnostics');
    
    if (!sess && isGated) {
      const activePersona = this.current();
      const isBypass = ADMIN_ROLES.has(activePersona.toUpperCase());
      if (!isBypass) {
        Bus.emit('auth:required', { ts: new Date().toISOString() });
      }
    }
  },

  directorate() {
    const p = this.profile() || {};
    const dsu = p.dsuKey ?? p.DSU_KEY ?? p.directorate ?? p.department ?? null;
    return dsu ? _normKey(dsu) : null;
  },

  directorateScope() {
    if (this.isElevated()) return ['all'];
    const own = this.directorate();
    return own ? [own] : [];
  },

  isElevated() {
    if (ELEVATED_PERSONAS.has(this.current())) return true;
    return isElevatedDsuKey(this.directorate());
  },

  canSeeRecord(rec) {
    if (!rec || typeof rec !== 'object') return true;
    const dsu = rec.__directorate;
    if (!dsu) return true;
    if (!isIsolatedDirectorate(dsu)) return true;
    if (this.isElevated()) return true;
    if (hasCrossDirectorateFlag(rec)) return true;
    
    const mine = this.directorate();
    return !!(mine && mine === _normKey(dsu));
  }
};

export default Persona;
