/**
 * OBSIDIAN v4.2 — Core API Engine & Outbox Agent
 * REMEDIATED (INT-02): Direct write dispatching when online to prevent silent 
 * transactions failure, falling back to Outbox only during active offline disconnects.
 */

import { Endpoints } from '../config/endpoints.config.js';
import { Idempotency } from './idempotency.js';
import { Storage } from './storage.js';
import { Bus } from './bus.js';

const DEFAULT_TIMEOUT_MS = 45000;
const OUTBOX_KEY = 'obsidian.sync_outbox';
const DEADLETTER_KEY = 'obsidian.outbox_deadletter';
const MAX_ATTEMPTS = 8;

const WRITE_FLOWS = new Set([
  'SINGLE_ASSIGNMENT', 'BULK_ASSIGNMENT', 'BULK_ASSIGNMENT_DIRECT',
  'EMAIL_RELATED_TASK', 'DYNAMIC_GLOBAL_ACTIONS', 'SUBSIDIARY_ACTIONS'
]);

const ENV_PROFILES = { dev: {}, test: {}, prod: {} };

function detectEnvironment() {
  if (typeof window === 'undefined') return 'prod';
  try {
    const forced = localStorage.getItem('obsidian.env_profile');
    if (forced) return forced;
    const h = (location.hostname || '').toLowerCase();
    if (h === 'localhost' || h === '127.0.0.1' || h.endsWith('.local')) return 'dev';
    if (h.includes('staging') || h.includes('test') || h.includes('uat')) return 'test';
  } catch (_) {}
  return 'prod';
}

const ACTIVE_ENV = detectEnvironment();

function resolveUrl(endpointKey, defaultUrl) {
  try {
    const override = localStorage.getItem('obsidian.endpoint.' + endpointKey);
    if (override && /^https?:\/\//.test(override)) return override;
  } catch (_) {}
  
  const profile = ENV_PROFILES[ACTIVE_ENV];
  if (profile && profile[endpointKey]) return profile[endpointKey];
  return defaultUrl;
}

function uuid() {
  if (globalThis.crypto && crypto.randomUUID) return crypto.randomUUID();
  return 'cid-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
}

function log(level, msg, ctx) {
  const L = globalThis.Platform && Platform.Log;
  if (L && typeof L[level] === 'function') L[level](msg, ctx);
}

export const Outbox = {
  _processing: null,

  get() {
    return Storage.get(OUTBOX_KEY, []);
  },

  save(queue) {
    Storage.set(OUTBOX_KEY, queue);
  },

  getDead() {
    return Storage.get(DEADLETTER_KEY, []);
  },

  saveDead(queue) {
    Storage.set(DEADLETTER_KEY, queue);
  },

  push(endpointKey, payload) {
    const queue = this.get();
    const txId = `TX-${Date.now()}-${Math.random().toString(36).substring(2, 9).toUpperCase()}`;
    const entry = {
      id: txId,
      endpointKey,
      payload,
      timestamp: new Date().toISOString(),
      attempts: 0,
      nextRetry: Date.now()
    };
    queue.push(entry);
    this.save(queue);
    this.process();
    return { ok: true, outboxId: txId, status: 'QUEUED_LOCAL' };
  },

  process() {
    if (this._processing) return this._processing;
    const p = this._processOnce().catch(() => {}).finally(() => {
      if (this._processing === p) this._processing = null;
    });
    this._processing = p;
    return p;
  },

  async _processOnce() {
    if (typeof navigator !== 'undefined' && !navigator.onLine) return;
    
    let queue = this.get();
    if (queue.length === 0) return;

    const activeQueue = [...queue];
    for (const item of activeQueue) {
      if (item.nextRetry > Date.now()) continue;

      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort('timeout'), 20000);

      try {
        const ep = Endpoints[item.endpointKey];
        const url = resolveUrl(item.endpointKey, ep ? ep.url : '');
        if (!url) {
          clearTimeout(timer);
          continue;
        }

        const response = await fetch(url, {
          method: ep.method || 'POST',
          headers: {
            ...ep.headers,
            'Content-Type': 'application/json',
            'X-Correlation-ID': item.id,
            'X-Idempotency-Key': item.payload.idempotencyKey || item.id
          },
          body: JSON.stringify(item.payload),
          signal: controller.signal
        });

        clearTimeout(timer);

                const text = await response.text();
        const body = text ? JSON.parse(text) : null;

        let logicalOk = true;
        if (body && typeof body === 'object') {
          if ('ok' in body && !body.ok) logicalOk = false;
          if ('success' in body && !body.success) logicalOk = false;
        }

        if (response.ok && logicalOk) {
          queue = this.get().filter(q => q.id !== item.id);
          this.save(queue);
          Bus.emit('platform:outbox:delivered', { endpointKey: item.endpointKey, id: item.id });
        } else {
          const errMsg = (body && body.errors && body.errors[0] && body.errors[0].message) ||
                         (body && body.message) ||
                         ('Server returned status ' + response.status);
          throw new Error(errMsg);
        }
      } catch (err) {
        clearTimeout(timer);
        item.attempts++;
        
        if (item.attempts >= MAX_ATTEMPTS) {
          queue = this.get().filter(q => q.id !== item.id);
          this.save(queue);

          const dead = this.getDead();
          dead.push({ ...item, error: err.message, failedAt: new Date().toISOString() });
          this.saveDead(dead);

          Bus.emit('platform:outbox:deadletter', { endpointKey: item.endpointKey, id: item.id, error: err.message });
          continue;
        }

        const backoff = Math.min(1000 * Math.pow(2, item.attempts), 7200000);
        item.nextRetry = Date.now() + backoff;
        
        const current = this.get();
        const target = current.find(q => q.id === item.id);
        if (target) {
          target.attempts = item.attempts;
          target.nextRetry = item.nextRetry;
          this.save(current);
        }
      }
    }
  }
};

if (typeof window !== 'undefined') {
  window.addEventListener('online', () => Outbox.process());
}

function deriveData(body) {
  if (!body) return null;
  if (body.data !== undefined && body.data !== null) {
    let d = body.data;
    if (typeof d === 'string') {
      const t = d.trim();
      if (t.startsWith('{') || t.startsWith('[')) { try { d = JSON.parse(t); } catch (_) {} }
    }
    return d;
  }
  if (typeof body === 'object') {
    const d = {};
    const keysToOmit = new Set(['ok', 'success', 'status', 'statusCode', 'errors', 'meta', 'correlationId']);
    for (const [k, v] of Object.entries(body)) if (!keysToOmit.has(k)) d[k] = v;
    if (Object.keys(d).length) return d;
  }
  return null;
}

function normalizeResponse(body, headers, durationMs, correlationId, httpStatus) {
  const httpFailed = !!(httpStatus && httpStatus >= 400);
  // Normalize both 'ok' and 'success' keyed responses into a unified shape.
  // Power Automate Stream-B flows (e.g. SUBSIDIARY_ACTIONS) emit { success, data }
  // while all other flows emit { ok, data }. Coerce 'success' to 'ok' here so
  // all downstream consumers get a consistent contract.
  if (body && typeof body === 'object') {
    const hasOk = 'ok' in body;
    const hasSuccess = 'success' in body;
    if (hasOk || hasSuccess) {
      const logicalOk = hasOk ? !!body.ok : !!body.success;
      const realOk = logicalOk && !httpFailed;
      const status = httpStatus || (body.status && Number(body.status.http)) || (logicalOk ? 200 : 500);
      // Always expose as 'ok' regardless of which key the flow used
      const normalizedBody = hasSuccess && !hasOk ? { ...body, ok: logicalOk } : body;
      return {
        ok: realOk, kind: realOk ? 'ok' : 'server',
        errorKind: realOk ? undefined : (body.errors && body.errors[0]?.kind) || 'INTERNAL_ERROR',
        status, data: deriveData(body), errors: body.errors || [],
        body: normalizedBody, headers, durationMs, correlationId
      };
    }
  }
  return {
    ok: !httpFailed, kind: httpFailed ? 'server' : 'ok', status: httpStatus || 200,
    data: deriveData(body), errors: [], body, headers, durationMs, correlationId
  };
}

export async function callAPI(endpointKey, payload = {}, opts = {}) {
  const isWrite = WRITE_FLOWS.has(endpointKey);
  const isOnline = typeof navigator !== 'undefined' && navigator.onLine;

  if (isWrite && !opts.forceDirect) {
    let idempotencyKey = payload.idempotencyKey || opts.idempotencyKey || null;
    if (!idempotencyKey) {
      idempotencyKey = Idempotency.normalizeInput({ endpointKey, payload, opts }).idempotencyKey;
    }
    const finalPayload = { ...payload, idempotencyKey };

    // Remediated (INT-02): Send directly when online so errors can be handled gracefully
    if (isOnline) {
      const directResponse = await callAPI(endpointKey, finalPayload, { ...opts, forceDirect: true });
      if (directResponse.ok) return directResponse;
      
      // Queue locally only if we hit a transient network failure
      if (directResponse.kind === 'network' || directResponse.status === 503 || directResponse.status === 504 || directResponse.status === 0) {
        const outboxRef = Outbox.push(endpointKey, finalPayload);
        return {
          ok: true,
          outboxId: outboxRef.outboxId,
          status: 'QUEUED_LOCAL',
          warning: 'Action queued locally due to connection error.'
        };
      }
      return directResponse;
    } else {
      return Outbox.push(endpointKey, finalPayload);
    }
  }

  const correlationId = opts.correlationId || uuid();
  const t0 = (globalThis.performance && performance.now()) || Date.now();
  const elapsed = () => Math.round(((globalThis.performance && performance.now()) || Date.now()) - t0);

  const ep = Endpoints[endpointKey];
  if (!ep) {
    return { ok: false, kind: 'config', status: 0, errors: [{ code: 'UNKNOWN_ENDPOINT', message: 'Unknown endpoint' }] };
  }

  const url = resolveUrl(endpointKey, ep.url);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort('timeout'), opts.timeoutMs || ep.timeoutMs || DEFAULT_TIMEOUT_MS);

  try {
    const response = await fetch(url, {
      method: ep.method || 'POST',
      headers: { ...ep.headers, 'X-Correlation-ID': correlationId },
      body: JSON.stringify(payload),
      signal: controller.signal
    });

    clearTimeout(timer);
    const text = await response.text();
    const body = text ? JSON.parse(text) : null;
    const headers = {};
    response.headers.forEach((v, k) => { headers[k] = v; });

    return normalizeResponse(body, headers, elapsed(), correlationId, response.status);
  } catch (err) {
    clearTimeout(timer);
    return {
      ok: false,
      kind: 'network',
      status: 0,
      errors: [{ code: 'FETCH_ERROR', message: err.message }],
      durationMs: elapsed(),
      correlationId
    };
  }
}

export const API = { callAPI, Outbox, getEnvironment: () => ACTIVE_ENV };
export default API;
