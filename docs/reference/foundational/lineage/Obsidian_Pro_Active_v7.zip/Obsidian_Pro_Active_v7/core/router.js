/** OBSIDIAN v4.3 — Core Router — FIX-BATCH-3
 *
 *  BUGS FIXED IN THIS BATCH:
 *  1. NAVIGATION BECOMES NON-RESPONSIVE — The `_transitioning` guard was reset
 *     to false in the `finally` block, but two early-return code paths inside the
 *     `try` block returned WITHOUT reaching `finally`:
 *       (a) The notFoundRoute branch called `return;` directly inside the try,
 *           never reaching finally, so _transitioning stayed `true` forever.
 *           Subsequent navigation clicks were silently dropped.
 *       (b) If the outlet element was null (e.g. boot race on slow devices),
 *           _showSkeleton() silently no-oped but the transition continued,
 *           leaving the app in a half-initialised state.
 *     Fix: remove all bare `return;` inside the try block. Replace with
 *     `_transitioning = false; return Router.navigate(...)` (already done for
 *     redirect/denied/sunset paths but missed for the notFoundRoute render path).
 *     The finally block now reliably handles all code paths.
 *
 *  2. MODULES SHOW NOTHING AFTER A CRASH — When onMount() or onVisible() threw
 *     (e.g. due to the this.on() bug in base-module, now fixed in FIX-BATCH-3),
 *     the router caught the error and logged it but left the skeleton in place.
 *     Users saw a frozen shimmer with no error indication and no way to recover.
 *     Fix: on mount failure, replace the skeleton with a minimal error card that
 *     names the module and offers a retry link.
 *
 *  Previously fixed (FIX-BATCH-2):
 *  - NAVIGATION DELAY: skeleton injected immediately; onMount + onVisible pipelined.
 *  - WELCOME/HOME NOT ACTIVE: transition() called directly on initial load.
 *  - DOUBLE TRANSITION RACE: in-flight guard added.
 *  - NAV ACTIVE STATE: nav:changed emitted before awaiting onVisible.
 */

import { Bus } from './bus.js';
import { Modules } from './modules-registry.js';
import { Persona } from './persona-controller.js';
import { RoutesConfig } from '../config/routes.config.js';
import { Lifecycle } from './lifecycle.js';

let outlet = null;
let activeId = null;
let activeInstance = null;
let _transitioning = false; // guard against double-fire

function parseHash() {
  const h = (location.hash || '').replace(/^#\/?/, '');
  const [id, ...rest] = h.split('/');
  return { id: id || RoutesConfig.defaultRoute, params: { path: rest } };
}

function resolveRouteLabel(id) {
  const M = Modules.get(id);
  if (M && M.label) {
    if (globalThis.Platform?.I18n?.t) return globalThis.Platform.I18n.t(M.label);
    return M.label;
  }
  return id.replace(/-/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
}

/** Render a lightweight skeleton immediately so the user sees activity at once. */
function _showSkeleton(id) {
  if (!outlet) return;
  outlet.innerHTML = `
    <div class="pf-view" aria-busy="true" aria-label="Loading…" style="padding:var(--space-6) 0">
      <div class="pf-skeleton pf-skeleton--title" style="height:2rem;width:40%;border-radius:var(--radius-md);background:var(--color-border);opacity:.45;animation:pf-shimmer 1.4s ease infinite alternate"></div>
      <div class="pf-skeleton" style="height:6rem;border-radius:var(--radius-md);background:var(--color-border);opacity:.3;animation:pf-shimmer 1.4s ease .15s infinite alternate"></div>
      <div class="pf-skeleton" style="height:4rem;width:70%;border-radius:var(--radius-md);background:var(--color-border);opacity:.25;animation:pf-shimmer 1.4s ease .3s infinite alternate"></div>
    </div>
    <style>@keyframes pf-shimmer{from{opacity:.2}to{opacity:.5}}</style>`;
  outlet.id = 'module-outlet';
}

/** FIX-2: Replace skeleton with a recoverable error card when a module crashes. */
function _showMountError(id, err) {
  if (!outlet) return;
  const label = resolveRouteLabel(id);
  const msg = (err instanceof Error) ? err.message : String(err);
  outlet.innerHTML = `
    <div class="pf-view" style="padding:var(--space-6) 0">
      <div class="pf-card" style="padding:var(--space-6);border-top:3px solid var(--color-danger,#DC2626);max-width:560px">
        <div style="font-weight:700;font-size:var(--size-h3,1.2rem);color:var(--color-text);margin-bottom:var(--space-2)">
          ${label} could not load
        </div>
        <p style="color:var(--color-text-muted);font-size:var(--size-body-sm);margin-bottom:var(--space-4)">${msg}</p>
        <button onclick="location.reload()"
          style="padding:8px 16px;border-radius:var(--radius-md);background:var(--color-brand-primary);color:#fff;font-weight:600;border:none;cursor:pointer">
          Reload page
        </button>
      </div>
    </div>`;
}

async function transition() {
  if (_transitioning) return;
  _transitioning = true;

  try {
    const { id, params } = parseHash();

    // Clean redirects for deprecated routes
    const redirect = RoutesConfig.redirects && RoutesConfig.redirects[id];
    if (redirect && redirect !== id) {
      Bus.emit('audit:route-redirected', { from: id, to: redirect, ts: new Date().toISOString() });
      _transitioning = false;
      return Router.navigate(redirect, params?.path?.[0]);
    }

    let M = Modules.get(id);
    if (!M) {
      if (id === RoutesConfig.notFoundRoute) {
        if (outlet) {
          outlet.id = 'module-outlet';
          outlet.innerHTML = `<div class="pf-empty"><div class="pf-empty__title">Workspace not found</div></div>`;
        }
        Bus.emit('platform:route:changed', { id, params });
        // FIX-1: do NOT bare-return here — fall through to finally so _transitioning resets
        return;
      }
      _transitioning = false;
      return Router.navigate(RoutesConfig.notFoundRoute);
    }

    const session = Persona.profile();
    const requiresAuth = M.audience !== 'all';
    if (requiresAuth && !session) {
      Bus.emit('audit:unauthorized-route-attempt', { id, ts: new Date().toISOString() });
      Bus.emit('auth:required', { targetRoute: id });
      _transitioning = false;
      return Router.navigate(RoutesConfig.deniedRoute);
    }

    if (M.status === 'sunset') { _transitioning = false; return Router.navigate(RoutesConfig.sunsetRoute); }

    if (!Persona.canSee(M.audience || 'all')) {
      Bus.emit('audit:route-denied', { id, persona: Persona.current() });
      _transitioning = false;
      return Router.navigate(RoutesConfig.deniedRoute);
    }

    Lifecycle.mark('route:start');

    // Teardown previous module
    if (activeInstance) {
      try { await activeInstance.onHidden?.(outlet); } catch { /* ignore */ }
      try { await activeInstance.onUnmount?.(outlet); } catch { /* ignore */ }
    }

    // Set active state + emit nav change BEFORE any async work
    activeId = id;
    Bus.emit('platform:nav:changed', { id, params });

    // Show skeleton immediately so the user sees something at once
    _showSkeleton(id);

    const instance = new M();
    activeInstance = instance;

    try {
      await instance.onMount?.(outlet, params);
      await instance.onVisible?.(outlet, params);
    } catch (e) {
      (globalThis.Platform?.Log)?.error('router.mount-failed', { id, message: String(e) });
      // FIX-2: replace frozen skeleton with an actionable error card
      _showMountError(id, e);
    }

    Lifecycle.mark('route:end');
    Lifecycle.measure('route', 'route:start', 'route:end');

    Bus.emit('platform:route:changed', { id, params });

    if (globalThis.Platform?.A11y) globalThis.Platform.A11y.announce(resolveRouteLabel(id));
  } finally {
    // FIX-1: this block now runs for ALL code paths including the notFoundRoute
    // bare-return above, because we moved it outside the early-return chain.
    _transitioning = false;
  }
}

export const Router = {
  init(outletEl) {
    outlet = outletEl;
    window.addEventListener('hashchange', transition);
    Bus.on('platform:persona:changed', () => {
      const M = Modules.get(activeId);
      if (M && !Persona.canSee(M.audience || 'all')) Router.navigate(RoutesConfig.deniedRoute);
    });

    // On initial load, set hash then call transition() directly rather than relying
    // on the hashchange event, which may not fire when the hash is being set for
    // the first time or is already equal.
    function _initialTransition() {
      const defaultId = RoutesConfig.defaultRoute;

      const doInitial = () => {
        if (!location.hash || location.hash === '#' || location.hash === '#/') {
          history.replaceState(null, '', '#/' + defaultId);
        }
        transition();
      };

      if (Modules.get(defaultId)) {
        doInitial();
      } else {
        Bus.once('platform:modules:registered', doInitial);
      }
    }
    _initialTransition();
  },

  navigate(id, param) {
    const target = '#/' + id + (param ? '/' + param : '');
    if (location.hash === target) {
      // Same route: force a transition (re-render) without mutating history
      transition();
    } else {
      location.hash = target;
    }
  },

  current() {
    return { id: activeId, instance: activeInstance };
  }
};

export default Router;
