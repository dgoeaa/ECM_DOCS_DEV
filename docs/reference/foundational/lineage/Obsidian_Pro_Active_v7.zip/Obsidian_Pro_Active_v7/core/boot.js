import { Platform } from './platform.js';
import { AppConfig } from '../config/app.config.js';

const withTimeout = (promise, ms, fallbackValue = null, label = 'operation') => {
  let timedOut = false;
  const timeout = new Promise((resolve) => setTimeout(() => {
    timedOut = true;
    resolve(fallbackValue);
  }, ms));
  return Promise.race([
    promise.then(v => v),
    timeout
  ]).then(result => {
    if (timedOut) {
      (globalThis.Platform?.Log || console).warn('boot.timeout', { label, ms });
    }
    return result;
  });
};

function _removeLoader() {
  document.querySelectorAll('#loader, [data-pf-overlay="loader"]').forEach((el) => {
    el.style.transition = 'opacity .2s ease';
    el.style.opacity = '0';
    setTimeout(() => el.remove(), 220);
  });
}

export async function boot({ outlet } = {}) {
  Platform.Lifecycle.mark('boot:start');
  let bootFailed = false;

  try {
    Platform.Storage.install();
    Platform.Errors.install();
    Platform.State.hydrate();

    await withTimeout(
      Platform.I18n.load(Platform.State.get('shared.locale.code', AppConfig.defaultLocale)),
      5000, null, 'i18n.load'
    );
    Platform.Format.setLocale(Platform.I18n.locale?.() || AppConfig.defaultLocale);

    Platform.Theme.init();
    Platform.Brand.init();
    Platform.Persona.init();

    Platform.Bus.on('platform:storage:pressure', (metrics) => {
      const level = metrics.level || 'warning';
      const percent = metrics.percent ?? 0;
      Platform.Bus.emit('platform:warning:push', {
        key: 'storage-pressure',
        variant: level === 'critical' ? 'critical' : 'warning',
        dismissable: level !== 'critical',
        text: `Local storage threshold pressured. Usage at ${percent}% [${level.toUpperCase()}]`
      });
    });

    const main = outlet || document.getElementById('module-outlet') || document.querySelector('.pf-shell__main');
    Platform.Nav.init();
    Platform.Router.init(main);
    Platform.Bus.emit('platform:modules:registered');

    if (typeof window !== 'undefined') {
      const setOnline = () => Platform.State.set('shared.connectivity.online', navigator.onLine);
      window.addEventListener('online', setOnline);
      window.addEventListener('offline', setOnline);
      setOnline();
    }

  } catch (e) {
    bootFailed = true;
    Platform.Log.error('boot.failed', { message: String(e?.message || e) });
    if (typeof document !== 'undefined') {
      const errEl = document.createElement('div');
      errEl.setAttribute('role', 'alert');
      errEl.setAttribute('aria-live', 'assertive');
      errEl.style.cssText = [
        'position:fixed', 'inset:0', 'display:grid', 'place-items:center',
        'background:var(--color-surface,#ffffff)', 'z-index:20000',
        'font-family:var(--font-sans,system-ui,sans-serif)', 'padding:2rem'
      ].join(';');
      const safeMsg = String(e?.message || e).replace(/</g, '&lt;').replace(/>/g, '&gt;');
      errEl.innerHTML = [
        '<div style="text-align:center;max-width:480px">',
        '<h1 style="font-size:1.25rem;font-weight:700;color:var(--color-danger,#c00);margin:0 0 .75rem">Platform failed to start</h1>',
        '<p style="font-size:.875rem;color:var(--color-text-muted,#555);margin:0 0 1.5rem">', safeMsg, '</p>',
        '<button onclick="location.reload()" style="padding:.5rem 1.25rem;border-radius:.5rem;font-weight:600;font-size:.875rem;background:var(--color-brand-primary,#05583b);color:#fff;border:none;cursor:pointer">Reload Platform</button>',
        '</div>'
      ].join('');
      document.body.appendChild(errEl);
    }
  } finally {
    Platform.Lifecycle.mark('boot:end');
    Platform.Lifecycle.measure('boot', 'boot:start', 'boot:end');

    if (typeof document !== 'undefined') {
      if (!bootFailed) {
        // FIX-1: Remove loader only after first module has rendered, not before.
        // Wait for 'platform:route:changed' with a max 1500 ms safety net.
        const loaderOff = Platform.Bus.once('platform:route:changed', () => {
          clearTimeout(safetyTimer);
          _removeLoader();
        });
        const safetyTimer = setTimeout(() => {
          if (loaderOff) try { loaderOff(); } catch { /* ignore */ }
          _removeLoader();
        }, 1500);

        Platform.Bus.emit('platform:ready');
      } else {
        // Boot failed: just remove the loader (error overlay is already shown)
        _removeLoader();
        Platform.Log.error('boot.failed-final-cleanup');
      }
    }
  }

  // Non-blocking background data warm-up — does NOT gate the UI
  Platform.Entities.bootstrap().catch((e) =>
    Platform.Log.warn('entities.bootstrap-failed', { message: String(e?.message || e) })
  );
  Platform.Lookups?.load?.().catch((e) =>
    Platform.Log.warn('lookups.warm-failed', { message: String(e?.message || e) })
  );

  if (typeof window !== 'undefined') {
    const isLocal = ['localhost', '127.0.0.1'].includes(location.hostname) ||
                    location.hostname.startsWith('192.168.') ||
                    location.hostname.startsWith('10.');

    if (isLocal) {
      if ('serviceWorker' in navigator) {
        navigator.serviceWorker.getRegistrations().then((registrations) => {
          for (const registration of registrations) registration.unregister();
        });
      }
      import('../shared/components/pf-dev-toolbox.js')
        .then(() => {
          const toolbox = document.createElement('pf-dev-toolbox');
          document.body.appendChild(toolbox);
        })
        .catch((err) => Platform.Log.warn('boot.dev-toolbox-failed', { message: String(err) }));
    } else if (Platform.Flags.serviceWorker && 'serviceWorker' in navigator) {
      const swUrl = new URL('../service-worker.js', import.meta.url);
      navigator.serviceWorker.register(swUrl).catch((e) =>
        Platform.Log.warn('sw.register-failed', { message: String(e) })
      );
    }
  }

  return Platform;
}
