/** OBSIDIAN v4.3 — base-module.js — FIX-BATCH-3
 *
 *  BUGS FIXED IN THIS BATCH:
 *  1. UNRESPONSIVE MODULES / BLANK SCREENS — 12 modules call `this.on(el, event, fn)`
 *     to attach DOM event listeners (buttons, filter bars, panels, etc.). This method
 *     existed only on PfBaseElement (Web Components) but was never added to BaseModule.
 *     Result: every call threw "TypeError: this.on is not a function", which (a) prevented
 *     event listeners from being registered so nothing responded to clicks, and (b) in
 *     modules that called it in onVisible() before any rendering, caused the entire
 *     onVisible() to throw, leaving the outlet showing only the skeleton indefinitely.
 *     Fix: add on() to BaseModule, mirroring PfBaseElement — registers the listener and
 *     pushes a cleanup disposer so listeners are removed on module teardown.
 *
 *  2. ACKFLOW BLANK SCREEN — AckFlowModule calls `this.$('#af-pending-val')` and other
 *     DOM selectors inside paint(). This method also exists only on PfBaseElement. Without
 *     it every paint() call threw immediately, leaving the module blank after mount.
 *     Fix: add $() and $$() to BaseModule, scoped to the current outlet root.
 *     NOTE: $() / $$() on BaseModule query the live document (not a shadow root).
 *     Modules must call onVisible() before paint() to ensure this._root is set.
 *
 *  3. APPROVALS / CORRESPONDENCE DATE CRASH — Both modules call `this.fmt(ts)` to
 *     format timestamps for display in list rows and detail headers. fmt() was not
 *     defined on BaseModule, causing a TypeError on every row render which aborted
 *     renderList() / renderTable() mid-way, producing a partially-rendered or blank view.
 *     Fix: add fmt() as a thin wrapper over Platform.Format.dateTime with a safe fallback.
 *
 *  Previously fixed (FIX-BATCH-2):
 *  - NAVIGATION DELAY: parallelized CSS + HTML fetch; cached view HTML per class.
 *  - STATE MANAGEMENT: reset _disposers before draining so re-entrant bus() works.
 *  - MODULE CALL FAILURES: added opts.logLevel for warn-only logging.
 */
import { State } from './state.js';
import { Bus } from './bus.js';

// Module-class-level HTML cache: survives across instance creations within a session
const _viewCache = new Map(); // ModuleClass.id -> Promise<string>

export class BaseModule {
  static id = '';
  static label = '';
  static icon = '';
  static nav = null;
  static audience = 'all';
  static status = 'active';
  static base = null; // subclass sets: new URL('.', import.meta.url)

  constructor() {
    this._disposers = [];
    this._stylesInjected = false;
    this.id = this.constructor.id;
    this._root = null; // set by onMount; used by $() / $$()
  }

  /* ---- default lifecycle: fetch view.html + inject styles.css ---- */
  async onMount(root, _params) {
    const base = this.constructor.base;
    if (!base || !root) return;

    // Store root so $() / $$() work as soon as onMount completes
    this._root = root;

    // Parallelize CSS injection and HTML fetch
    const cssPromise = (() => {
      if (this._stylesInjected) return Promise.resolve();
      this._stylesInjected = true;
      const href = new URL('./styles.css', base).href;
      if (!document.querySelector(`link[data-module="${this.id}"]`)) {
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = href;
        link.dataset.module = this.id;
        document.head.appendChild(link);
      }
      return Promise.resolve(); // non-blocking — browser handles it
    })();

    // Cache view HTML per module class so repeat visits are synchronous
    const htmlKey = this.constructor.id;
    if (!_viewCache.has(htmlKey)) {
      _viewCache.set(htmlKey,
        fetch(new URL('./view.html', base))
          .then((r) => r.text())
          .catch((e) => {
            _viewCache.delete(htmlKey); // don't cache failures
            (globalThis.Platform?.Log)?.error('module.view-fetch-failed', { id: this.id, message: String(e) });
            return '';
          })
      );
    }

    const [, html] = await Promise.all([cssPromise, _viewCache.get(htmlKey)]);
    if (html) {
      root.innerHTML = html;
      root.querySelectorAll('[data-i18n]').forEach((n) => {
        n.textContent = this.t(n.getAttribute('data-i18n'));
      });
    }
  }

  onVisible(_root, _params) {}  // override: call this.call() for data
  onHidden(_root) { this._cleanup(); }
  onUnmount(_root) {}
  onParamsChange(_params) {}

  /* ---- FIX-1: DOM event listener helper (auto-cleaned on teardown) ---- */
  /**
   * Attach a DOM event listener and register it for automatic removal when the
   * module is hidden/unmounted. Mirrors PfBaseElement.on() so modules that use
   * this.on() work correctly.
   *
   * @param {EventTarget|null} el    - Target element (null-safe: no-op if null)
   * @param {string}           type  - Event type, e.g. 'click'
   * @param {Function}         fn    - Handler function
   * @param {object}           [opts] - addEventListener options
   * @returns {Function} Disposer that removes the listener
   */
  on(el, type, fn, opts) {
    if (!el) return () => {};
    el.addEventListener(type, fn, opts);
    const off = () => el.removeEventListener(type, fn, opts);
    this._disposers.push(off);
    return off;
  }

  /* ---- FIX-2: Scoped DOM query helpers ---- */
  /**
   * querySelector scoped to this module's outlet root.
   * Safe to call after onMount() has run. Returns null if root not set.
   */
  $(sel) {
    return this._root ? this._root.querySelector(sel) : null;
  }

  /**
   * querySelectorAll scoped to this module's outlet root.
   * Always returns an Array (never null/NodeList).
   */
  $$(sel) {
    if (!this._root) return [];
    return Array.from(this._root.querySelectorAll(sel));
  }

  /* ---- FIX-3: Date/time format shortcut ---- */
  /**
   * Format a date/time value using Platform.Format.dateTime.
   * Falls back to String(v) so renders never crash on missing Platform.
   */
  fmt(v) {
    if (!v) return '';
    return (globalThis.Platform?.Format?.dateTime)
      ? globalThis.Platform.Format.dateTime(v)
      : String(v);
  }

  /* ---- service invocation ---- */
  async call(serviceFn, args, opts = {}) {
    const result = await serviceFn(args || {}, opts.query || {});
    if (!result.ok) {
      const logLevel = opts.logLevel || 'error';
      (globalThis.Platform?.Log)?.[logLevel]('module.call-failed', {
        module: this.id, endpoint: serviceFn.endpointKey,
        kind: result.kind, correlationId: result.correlationId
      });
      if (!opts.silent && globalThis.Platform?.UI) globalThis.Platform.UI.toastError(result);
    } else {
      Bus.emit(`module:${this.id}:data-loaded`, { endpoint: serviceFn.endpointKey });
    }
    return result;
  }

  /* ---- scoped state: modules.<id>.* ---- */
  get state() {
    const ns = (p) => `modules.${this.id}.${p}`;
    return {
      get: (p, d) => State.get(ns(p), d),
      set: (p, v) => State.set(ns(p), v),
      subscribe: (p, fn) => {
        const off = State.subscribe(ns(p), fn);
        this._disposers.push(off);
        return off;
      }
    };
  }

  /* ---- shared cross-module state: shared.<domain>.* ---- */
  get shared() {
    return {
      get: (p, d) => State.get(`shared.${p}`, d),
      set: (p, v) => State.set(`shared.${p}`, v),
      subscribe: (p, fn) => {
        const off = State.subscribe(`shared.${p}`, fn);
        this._disposers.push(off);
        return off;
      }
    };
  }

  /* ---- scoped Bus subscription (auto-cleaned) ---- */
  bus(event, fn) {
    const off = Bus.on(event, fn);
    this._disposers.push(off);
    return off;
  }

  /* ---- i18n shortcut ---- */
  t(key, vars) {
    return (globalThis.Platform?.I18n?.t) ? globalThis.Platform.I18n.t(key, vars) : key;
  }

  /* ---- cleanup ---- */
  _cleanup() {
    const d = this._disposers;
    this._disposers = []; // reset BEFORE calling disposers so re-entrant bus() calls work
    for (const fn of d) { try { fn(); } catch { /* ignore */ } }
  }
}

export default BaseModule;
