/** Stage M-R10.5 — UI and frontend/backend operation performance profile. */
export const PerformanceConfig = Object.freeze({
  api: Object.freeze({
    readCacheTtlMs: 120000,
    inflightDedupe: true,
    maxOutboxConcurrency: 3,
    maxReadCacheEntries: 48,
    maxPayloadLogBytes: 750000,
    requestBudgetWarnMs: 3500
  }),
  ui: Object.freeze({
    filterDebounceMs: 120,
    maxPickerRows: 300,
    idleHydrationDelayMs: 1,
    longTaskWarnMs: 80,
    enableContentVisibility: true
  }),
  entity: Object.freeze({
    enableVisibleSnapshotCache: true,
    enableCountsCache: true
  })
});
export default PerformanceConfig;
