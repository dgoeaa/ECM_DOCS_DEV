export const UX_BROWSER_CERTIFICATION=Object.freeze({
  "viewports": [
    320,
    375,
    430,
    600,
    768,
    1024,
    1280,
    1440,
    1920
  ],
  "priorityRoutes": [
    "#/home",
    "#/ops-hub",
    "#/bulk-assignment",
    "#/executive",
    "#/user-admin",
    "#/settings",
    "#/diagnostics"
  ],
  "allModuleRoutes": [
    "#/home",
    "#/executive",
    "#/stats",
    "#/reports",
    "#/operator-hud",
    "#/ops-hub",
    "#/correspondence",
    "#/registry",
    "#/response-tracking",
    "#/approvals",
    "#/dispatch",
    "#/comments",
    "#/fasttrack",
    "#/lookup",
    "#/assistant",
    "#/single-item-ops",
    "#/bulk-assignment",
    "#/orchestrator",
    "#/ackflow",
    "#/settings",
    "#/diagnostics",
    "#/user-admin"
  ],
  "roles": [
    "general",
    "executive",
    "admin"
  ],
  "states": [
    "loaded",
    "empty",
    "offline",
    "error",
    "modal",
    "toast",
    "sidebar-open",
    "sidebar-collapsed"
  ],
  "acceptance": [
    "visible-header-controls",
    "active-module-in-header",
    "home-command-centre",
    "feedback-visible",
    "pane-contained-content",
    "module-layout-contract",
    "role-context-visible"
  ]
});
export default UX_BROWSER_CERTIFICATION;
