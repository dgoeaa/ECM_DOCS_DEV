export const UX_BREAKPOINTS=Object.freeze({
  "320": 320,
  "375": 375,
  "430": 430,
  "600": 600,
  "768": 768,
  "1024": 1024,
  "1280": 1280,
  "1440": 1440,
  "1920": 1920
});
export default UX_BREAKPOINTS;
