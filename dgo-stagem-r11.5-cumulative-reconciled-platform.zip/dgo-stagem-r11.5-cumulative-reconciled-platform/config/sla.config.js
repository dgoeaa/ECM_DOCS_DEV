/** DGO configurable business-calendar rules for SLA projection. */
export const SlaConfig = Object.freeze({
  timezone: 'Africa/Lagos',
  workingDays: [1, 2, 3, 4, 5],
  workStartHour: 8,
  workEndHour: 16,
  dueSoonHours: 48,
  holidays: [
    '2026-01-01',
    '2026-05-01',
    '2026-06-12',
    '2026-10-01',
    '2026-12-25',
    '2026-12-26'
  ]
});
export default SlaConfig;
