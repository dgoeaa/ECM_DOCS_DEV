/** OBSIDIAN v4.0 — app.config.js · global, build-free app constants. */
export const AppConfig = {
  id: 'obsidian',
  storagePrefix: 'obsidian',
  defaultLocale: 'en',
  availableLocales: ['en', 'fr', 'ha'], // DGO/NITDA compliance: current shipped runtime locales
  defaultTheme: 'government',            // 'light' | 'dark' | 'system'
  themes: ['system', 'government', 'light', 'dark', 'hc', 'high-contrast'],
  defaultDensity: 'comfortable',         // brand default
  densities: ['comfortable', 'compact'],
  defaultBrand: 'dgo',               // DGO-forward: sub-brand active by default
  apiTimeoutMs: 45000,
  titleKey: 'app.title',
  correlationHeader: 'X-Correlation-Id'
};
export default AppConfig;
