export const CUMULATIVE_RELEASE=Object.freeze({
  "id": "R11.5",
  "retains": [
    "R10.4 RBAC/User Administration",
    "R10.5 Performance Optimization",
    "R11.0 UX Consolidation",
    "R11.1 Browser Certification Harness",
    "R11.2 Module Integration Governance",
    "R11.3 Profile Reference Hydration Fix",
    "R11.4 Initial SystemAdmin Bootstrap"
  ],
  "sourceBaseline": "dgo-stagem-r11.4-initial-systemadmin-bootstrap.zip",
  "endpointSha256": "7fc64a2cd79afac5f600bcafc1ee524ccf86fe2d10af8348450727abd2e4f223"
});
export default CUMULATIVE_RELEASE;
