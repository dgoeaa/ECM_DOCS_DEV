export const BOOTSTRAP_ADMIN = Object.freeze({
  enabled: true,
  mode: 'firstAuthenticatedEmail',
  role: 'systemAdmin',
  persona: 'admin',
  storageEmailKey: 'obsidian.bootstrap.systemAdmin.email',
  storageClaimedKey: 'obsidian.bootstrap.systemAdmin.claimed',
  auditEvent: 'audit:bootstrap-system-admin'
});
export default BOOTSTRAP_ADMIN;
