/** OBSIDIAN v4.0 — nav.config.js · group order + utility actions (single source of truth).
 *  Module nav ENTRIES come from each BaseModule's static `nav`; this file fixes group
 *  order and the header utility actions. Items are audience-filtered by nav-controller. */

// J-1 / U2 — Revised naming scheme mapped directly to the 6-Phase Unified Correspondence Lifecycle
// ensuring precise operational proportion, terminology, and sequential flow.
export const NAV_GROUPS = [
  { id: 'INTAKE',     labelKey: 'nav.group.intake' },     // Capture, Acknowledge & Triage
  { id: 'ROUTING',    labelKey: 'nav.group.routing' },    // File Movement & Registry
  { id: 'ACTION',     labelKey: 'nav.group.action' },     // Task Assignment & Orchestration
  { id: 'REVIEW',     labelKey: 'nav.group.review' },     // Exec Review & Signature Sign-Offs
  { id: 'DISPATCH',   labelKey: 'nav.group.dispatch' },   // Outbound Dispatch & Closure
  { id: 'ARCHIVE',    labelKey: 'nav.group.archive' },    // Preservation & Immutable History
  { id: 'CrossPhase', labelKey: 'nav.group.crossPhase' }, // Intelligence, Assistant & Lookup
  { id: 'System',     labelKey: 'nav.group.system' }      // Diagnostics & Overrides
];

export const UTILITY_ACTIONS = [
  { id: 'palette',       labelKey: 'nav.util.palette',       icon: 'command',  event: 'platform:palette:open',     flag: 'palette' },
  { id: 'notifications', labelKey: 'nav.util.notifications', icon: 'bell',     event: 'platform:notifications:open', flag: 'notifications' },
  { id: 'theme',         labelKey: 'nav.util.theme',         icon: 'contrast', event: 'platform:theme:cycle' },
  { id: 'persona',       labelKey: 'nav.util.persona',       icon: 'users',    component: 'pf-persona-switcher' }
];

export default { NAV_GROUPS, UTILITY_ACTIONS };
