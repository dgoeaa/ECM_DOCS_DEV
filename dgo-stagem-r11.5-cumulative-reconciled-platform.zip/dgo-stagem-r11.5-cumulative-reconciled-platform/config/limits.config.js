/** Stage M-R10.3 — UI workflow limits. */
export const MAX_BULK_ASSIGN = 50;
export default { MAX_BULK_ASSIGN };
