/**
 * DGO Stage M-R8.1 — Feature/module ownership map.
 *
 * Purpose:
 * - Prevent duplicate write ownership across operational modules.
 * - Keep overlapping modules as intentional lenses, dashboards, or orchestration surfaces.
 * - Provide a static authority for redundancy checks before browser certification.
 *
 * This file does not change endpoint URLs, signatures, or network routing.
 */

export const FEATURE_CLUSTERS = Object.freeze({
  assignment: Object.freeze({
    owner: 'bulk-assignment',
    writeOwners: Object.freeze(['bulk-assignment', 'single-item-ops']),
    lenses: Object.freeze(['ops-hub', 'orchestrator', 'operator-hud', 'home']),
    canonicalActions: Object.freeze(['singleassignment', 'bulkassignment']),
    note: 'Bulk and single assignment are intentionally separate write modules; other modules should link or lens these records.'
  }),
  reporting: Object.freeze({
    owner: 'reports',
    writeOwners: Object.freeze(['reports']),
    lenses: Object.freeze(['stats', 'executive', 'operator-hud', 'home']),
    canonicalActions: Object.freeze(['dispatchEmail', 'prepareMeetingPack']),
    note: 'Reports owns generated/exported reporting actions; dashboards remain read-only lenses.'
  }),
  lookupSearch: Object.freeze({
    owner: 'lookup',
    writeOwners: Object.freeze([]),
    lenses: Object.freeze(['correspondence', 'registry', 'assistant']),
    canonicalActions: Object.freeze([]),
    note: 'Lookup is read-only reference/search authority; assistant and operational modules consume it.'
  }),
  commentsActivity: Object.freeze({
    owner: 'comments',
    writeOwners: Object.freeze(['comments']),
    lenses: Object.freeze(['correspondence', 'single-item-ops', 'registry', 'response-tracking']),
    canonicalActions: Object.freeze(['addComment']),
    note: 'Comments owns comment write UX; other modules embed or open comment context.'
  }),
  routingWorkflow: Object.freeze({
    owner: 'orchestrator',
    writeOwners: Object.freeze(['orchestrator', 'registry']),
    lenses: Object.freeze(['ops-hub', 'correspondence', 'ackflow']),
    canonicalActions: Object.freeze(['route', 'transition', 'acknowledge']),
    note: 'Orchestrator owns cross-workflow visibility; registry owns minute/registry updates.'
  }),
  diagnosticsSettings: Object.freeze({
    owner: 'settings',
    writeOwners: Object.freeze(['settings']),
    lenses: Object.freeze(['diagnostics']),
    canonicalActions: Object.freeze([]),
    note: 'Settings owns operator-controlled local configuration; diagnostics is inspect/read/export only.'
  }),
  dispatchResponse: Object.freeze({
    owner: 'dispatch',
    writeOwners: Object.freeze(['dispatch']),
    lenses: Object.freeze(['response-tracking', 'reports']),
    canonicalActions: Object.freeze(['dispatch', 'dispatchEmail']),
    note: 'Dispatch owns outbound movement; response-tracking and reports present read/status surfaces.'
  })
});

export const MODULE_ROLE = Object.freeze({
  home: 'dashboard-lens',
  correspondence: 'intake-workbench',
  'ops-hub': 'operational-lens',
  ackflow: 'acknowledgement-workbench',
  approvals: 'approval-workbench',
  registry: 'registry-write-workbench',
  dispatch: 'dispatch-write-workbench',
  fasttrack: 'sla-lens',
  'response-tracking': 'response-lens',
  'operator-hud': 'operator-lens',
  orchestrator: 'workflow-orchestrator',
  'single-item-ops': 'single-assignment-write-workbench',
  'bulk-assignment': 'bulk-assignment-write-workbench',
  reports: 'reporting-write-workbench',
  stats: 'statistics-lens',
  executive: 'executive-lens',
  assistant: 'ai-assistance-lens',
  lookup: 'reference-lens',
  comments: 'comment-write-workbench',
  settings: 'admin-configuration-workbench',
  diagnostics: 'diagnostic-lens'
});

export const WRITE_WORKFLOW_OWNER = Object.freeze({
  singleAssignment: 'single-item-ops',
  bulkAssignment: 'bulk-assignment',
  correspondenceCreate: 'correspondence',
  aiClassifyEmail: 'correspondence',
  approvalDecision: 'approvals',
  registryUpdate: 'registry',
  commentAdd: 'comments',
  reportSend: 'reports',
  dispatchOutbound: 'dispatch',
  endpointOverride: 'settings'
});

export function featureClusterForModule(moduleId) {
  const id = String(moduleId || '').trim();
  return Object.entries(FEATURE_CLUSTERS)
    .filter(([, cluster]) => cluster.owner === id || cluster.writeOwners.includes(id) || cluster.lenses.includes(id))
    .map(([key, cluster]) => ({ key, ...cluster }));
}

export function moduleRole(moduleId) {
  return MODULE_ROLE[String(moduleId || '').trim()] || 'unclassified';
}

export function assertNoDuplicateWriteOwners() {
  const seen = new Map();
  const duplicates = [];
  for (const [workflow, owner] of Object.entries(WRITE_WORKFLOW_OWNER)) {
    if (!owner) duplicates.push({ workflow, owner, reason: 'missing-owner' });
    if (seen.has(workflow)) duplicates.push({ workflow, owner, firstOwner: seen.get(workflow), reason: 'duplicate-workflow-key' });
    seen.set(workflow, owner);
  }
  return { ok: duplicates.length === 0, duplicates };
}

export default { FEATURE_CLUSTERS, MODULE_ROLE, WRITE_WORKFLOW_OWNER, featureClusterForModule, moduleRole, assertNoDuplicateWriteOwners };
