/** Stage M-R10.4 — Role-based access control configuration for UI capability gating. */
export const PERMISSIONS = Object.freeze({
  EXECUTIVE_VIEW: 'executive:view',
  EXECUTIVE_EXPORT: 'executive:export',
  EXECUTIVE_DECISION_BRIEF: 'executive:decision-brief',
  USER_VIEW: 'user:view',
  USER_CREATE: 'user:create',
  USER_UPDATE: 'user:update',
  USER_DISABLE: 'user:disable',
  ROLE_ASSIGN: 'role:assign',
  ROLE_VIEW: 'role:view',
  SETTINGS_VIEW: 'settings:view',
  SETTINGS_MANAGE: 'settings:manage',
  AUDIT_VIEW: 'audit:view',
  DISPATCH_APPROVE: 'dispatch:approve',
  BULK_ASSIGN: 'bulk:assign',
  ROUTE_MANAGE: 'route:manage'
});

export const ROLES = Object.freeze({
  systemAdmin: Object.freeze({
    id: 'systemAdmin', label: 'System Administrator', persona: 'admin',
    permissions: Object.freeze(Object.values(PERMISSIONS))
  }),
  userAdmin: Object.freeze({
    id: 'userAdmin', label: 'User Administrator', persona: 'admin',
    permissions: Object.freeze([PERMISSIONS.USER_VIEW, PERMISSIONS.USER_CREATE, PERMISSIONS.USER_UPDATE, PERMISSIONS.USER_DISABLE, PERMISSIONS.ROLE_ASSIGN, PERMISSIONS.ROLE_VIEW, PERMISSIONS.AUDIT_VIEW])
  }),
  executive: Object.freeze({
    id: 'executive', label: 'Executive', persona: 'executive',
    permissions: Object.freeze([PERMISSIONS.EXECUTIVE_VIEW, PERMISSIONS.EXECUTIVE_EXPORT, PERMISSIONS.EXECUTIVE_DECISION_BRIEF, PERMISSIONS.AUDIT_VIEW])
  }),
  director: Object.freeze({
    id: 'director', label: 'Director / Directorate Lead', persona: 'general',
    permissions: Object.freeze([PERMISSIONS.EXECUTIVE_VIEW, PERMISSIONS.ROUTE_MANAGE, PERMISSIONS.DISPATCH_APPROVE, PERMISSIONS.BULK_ASSIGN])
  }),
  operator: Object.freeze({
    id: 'operator', label: 'Operator', persona: 'general',
    permissions: Object.freeze([PERMISSIONS.ROUTE_MANAGE, PERMISSIONS.BULK_ASSIGN])
  }),
  viewer: Object.freeze({
    id: 'viewer', label: 'Read-only Viewer', persona: 'general',
    permissions: Object.freeze([])
  })
});

export const DEFAULT_ROLE = 'operator';
export const ROLE_ORDER = Object.freeze(['systemAdmin','userAdmin','executive','director','operator','viewer']);
export const roleById = (id) => ROLES[id] || null;
export const roleAllows = (roleId, permission) => {
  const role = roleById(roleId);
  return !!(role && role.permissions.includes(permission));
};
export default { PERMISSIONS, ROLES, DEFAULT_ROLE, ROLE_ORDER, roleById, roleAllows };
