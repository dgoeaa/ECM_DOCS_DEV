﻿import { buildTraceViewModel } from '../../shared/domain/reference-trace.js';
/**
 * OBSIDIAN v4.2 â€” Executive Signature Chamber Module
 * Remediated: High-end executive approvals desk featuring chronological reviewer sequencers.
 */
import { BaseModule } from '../../core/base-module.js';
import { Modules } from '../../core/modules-registry.js';
import { submitDecision } from './service.js';
import { el, clear } from '../../shared/utils/dom.js';
import { approveReference, returnReference } from '../../shared/domain/workflow.js';
import { withBusy } from '../../shared/utils/dom.js';
import { emptyState } from '../../shared/utils/render.js';

class ApprovalsModule extends BaseModule {
  static id = 'approvals';
  static label = 'module.approvals.title';
  static icon = 'check-circle';
  static nav = { group: 'REVIEW', order: 1 };
  static audience = 'general';
  static status = 'active';
  static base = new URL('.', import.meta.url);

  async onVisible(root, params) {
    this._root = root;
    this._wrap = root.querySelector('.pf-ap');
    this._listEl = root.querySelector('[data-region="list"]');
    this._detailEl = root.querySelector('[data-region="detail"]');
    this._countEl = root.querySelector('[data-region="count"]');
    const refresh = root.querySelector('[data-act="refresh"]');
    if (refresh) this.on(refresh, 'click', () => this.refresh());

    const E = globalThis.Platform.Entities;
    if (!await this.ensureFabric(root)) return;
    this.bus('entity:approval:changed', () => this.load());
    this.bus('entity:reference:updated', () => this.load());
    this.bus('context:reference:changed', (e) => { if (e.source !== this.id) this.focusRef(e.ref); });

    this.load();
    const deep = params && params.path && params.path[0];
    if (deep) this.focusRef(deep);
  }

  pending() {
    return globalThis.Platform.Entities.all('approval')
      .filter((a) => !/approved|rejected|closed/i.test(String(a.status || a.Status || 'pending')));
  }

  load() {
    this._items = this.pending();
    this._countEl.textContent = this.t('approvals.pending', { n: this._items.length });
    this.renderList();
    if (this._wrap) this._wrap.setAttribute('data-mode', 'list');
    if (this._items.length) this.select(0); else emptyState(this._detailEl, 'approvals.empty');
  }
  async refresh() { await globalThis.Platform.Entities.bootstrap(true); this.load(); }

  renderList() {
    clear(this._listEl);
    this._items.forEach((it, i) => {
      const item = el('button', { 
        class: 'pf-ap__item', 
        role: 'option'
      }, [
        el('div', { class: 'row' }, [
          el('span', { class: 'pf-badge pf-badge--routed', text: it.type || it.category || this.t('approvals.typeMemo') }),
          el('span', { class: 'when', text: it.ts ? this.fmt(it.ts) : '' })
        ]),
        el('div', { class: 'ttl', text: it.title || it.subject || it.__ref || it.__id || '' }),
        el('div', { class: 'from', text: this.t('approvals.from', { who: it.from || it.initiator || it.assignedTo || '' }) })
      ]);
      this.on(item, 'click', () => this.select(i));
      this._listEl.appendChild(item);
    });
  }

  select(i) {
    this._sel = i;
    [...this._listEl.children].forEach((c, idx) => {
      const active = idx === i;
      c.setAttribute('aria-selected', active ? 'true' : 'false');
      c.style.background = active ? 'var(--dgo-green-50)' : 'transparent';
      c.style.borderLeft = active ? '3px solid var(--dgo-color-action-primary)' : 'none';
    });
    if (this._wrap) this._wrap.setAttribute('data-mode', 'detail');
    const it = this._items[i];
    if (it && it.__ref) globalThis.Platform.Context.setActive(it.__ref, this.id);
    this.renderDetail(it);
  }
  focusRef(ref) {
    if (!ref || !this._items) return;
    const i = this._items.findIndex((x) => x.__ref === String(ref));
    if (i >= 0 && i !== this._sel) this.select(i);
  }

  showList() {
    if (this._wrap) this._wrap.setAttribute('data-mode', 'list');
    const selected = this._listEl && this._listEl.querySelector('[aria-selected="true"]');
    if (selected && typeof selected.focus === 'function') selected.focus();
  }

  renderDetail(it) {
    if (!it) return emptyState(this._detailEl, 'approvals.empty');
    clear(this._detailEl);
    const ref = it.__ref || it.__id || '';
    const trace = ref ? buildTraceViewModel(ref) : { relatedLinks: [] };

    const back = el('button', { class: 'pf-ap__back pf-btn pf-btn--ghost', type: 'button', text: 'â† Back to approvals', onClick: () => this.showList() });

    const approveBtn = el('button', { class: 'dgo-btn dgo-btn--primary dgo-btn--sm', text: this.t('approvals.approve') });
    const rejectBtn = el('button', { class: 'dgo-btn dgo-btn--danger dgo-btn--sm', text: this.t('approvals.reject') });
    this.on(approveBtn, 'click', () => withBusy(approveBtn, () => this.decide('approve', ref), { busyLabel: this.t('common.actions.processing') }));
    this.on(rejectBtn, 'click', () => withBusy(rejectBtn, () => this.decide('reject', ref), { busyLabel: this.t('common.actions.processing') }));
    const head = el('div', { class: 'pf-ap__dethead' }, [
      el('div', { class: 'pf-ap__detcopy' }, [
        back,
        el('div', { class: 'row' }, [
          el('span', { class: 'pf-badge pf-badge--archived', text: ref }),
          el('span', { class: 'pf-badge pf-badge--pending', text: this.t('approvals.statusPending') })
        ]),
        el('h2', { text: it.title || it.subject || ref }),
        el('p', { class: 'from', text: this.t('approvals.submittedBy', { who: it.from || it.initiator || '', date: it.ts ? this.fmt(it.ts) : '' }) })
      ]),
      el('div', { class: 'pf-ap__acts' }, [ approveBtn, rejectBtn ])
    ]);

    const summary = el('div', { class: 'pf-ap__sec' }, [
      el('h3', { text: this.t('approvals.summary') }),
      el('p', { text: it.summary || it.body || it.description || this.t('common.state.empty') })
    ]);

    const links = el('div', { class: 'pf-ap__sec' }, [ el('h3', { text: this.t('approvals.related') }) ]);
    const linkRow = el('div', { class: 'pf-ap__docs' });
    for (const { type, moduleId, count } of trace.relatedLinks || []) {
      const b = el('button', { class: 'dgo-btn dgo-btn--secondary dgo-btn--sm',
        text: `${this.iconFor(type)} ${this.t('entity.' + type)} (${count})` });
      this.on(b, 'click', () => globalThis.Platform.goToEntity(ref, moduleId));
      linkRow.appendChild(b);
    }
    if (!linkRow.children.length) linkRow.appendChild(el('span', { class: 'from', text: this.t('common.state.empty') }));
    links.appendChild(linkRow);

    const minute = el('div', { class: 'pf-ap__sec pf-ap__minute' }, [
      el('h3', { text: this.t('approvals.minute') }),
      el('textarea', { id: 'ap-comment', class: 'dgo-textarea', rows: '3', placeholder: this.t('approvals.minutePlaceholder') }),
      el('div', { class: 'pf-ap__sign' }, [el('label', { class: 'dgo-check' }, [
        el('input', { type: 'checkbox', id: 'ap-sign' }),
        document.createTextNode(' ' + this.t('approvals.sign'))
      ])])
    ]);
    this._detailEl.append(head, summary, links, minute);
  }

  async decide(kind, ref) {
    const comment = (this._detailEl.querySelector('#ap-comment') || {}).value || '';
    const signed = !!(this._detailEl.querySelector('#ap-sign') || {}).checked;
    if (kind === 'reject' && !comment.trim()) { globalThis.Platform.UI.toast({ messageKey: 'approvals.needReason', variant: 'warning' }); return; }
    const ok = await globalThis.Platform.UI.confirm({
      titleKey: kind === 'approve' ? 'approvals.confirmApproveTitle' : 'approvals.confirmRejectTitle',
      summaryKey: kind === 'approve' ? 'approvals.confirmApproveBody' : 'approvals.confirmRejectBody',
      details: [ { label: this.t('entity.reference'), value: ref }, { label: this.t('approvals.minute'), value: comment || 'â€”' }, { label: this.t('approvals.sign'), value: signed ? 'âœ“' : 'â€”' } ],
      confirmKey: kind === 'approve' ? 'approvals.approve' : 'approvals.reject', danger: kind === 'reject' });
    if (!ok) return;
    this.commit(kind, ref, comment, signed);
  }

  async commit(kind, ref, comment, signed) {
    const decision = kind === 'approve' ? 'Approved' : 'Rejected';
    const P = globalThis.Platform;
    const persona = (P.Persona?.current && P.Persona.current()) || 'web-ops';
    const userEmail = (P.Persona?.email && P.Persona.email()) || `${persona}@nitda.gov.ng`;
    const refRow = P.Entities?.byReference?.(ref)?.reference || {};
    const title = refRow.title || refRow.subject || ref;
    const actionName = kind === 'approve' ? 'ACKNOWLEDGE' : 'UPDATE_TASK';
    const existing = (this._items[this._sel] || {});

    const R = P.Reviewers;
    const chain = existing.reviewers || existing.Reviewers || null;
    let reviewersOut = null, chainComplete = true;
    if (R && Array.isArray(chain) && chain.length) {
      const act = R.active(chain);
      if (!act) { P.UI.toast({ messageKey: 'approvals.reviewerComplete', variant: 'info' }); return; }
      const adv = R.advance(chain, act.sequence, kind === 'approve' ? 'approve' : 'reject', { comment });
      if (!adv.ok) { P.UI.toast({ messageKey: 'approvals.reviewerLocked', variant: 'warning' }); return; }
      reviewersOut = adv.reviewers;
      chainComplete = kind === 'approve' ? adv.complete : true;
    }

    const payload = {
      action: actionName, method: 'POST', userEmail,
      AssignmentType: actionName,
      Selected: { ID: ref, RefIDD: String(ref), Title: title },
      RefIDD: String(ref),
      ...(kind === 'approve' ? { decision, comment, signed } : { status: decision, reason: comment }),
      ...(reviewersOut ? { reviewers: reviewersOut } : {}),
      payload: {
        selection: { single: { ID: ref, RefIDD: String(ref), Title: title }, items: [] },
        decision: kind === 'approve' ? { value: decision, comment, signed } : { value: decision, reason: comment },
        ...(reviewersOut ? { reviewers: reviewersOut } : {})
      }
    };
        const result = await this.call(submitDecision, payload);
    if (result.ok) {
      const nextStatus = (kind === 'approve' && !chainComplete) ? (existing.status || 'pending-review') : decision;
      globalThis.Platform.Entities.upsert('approval', { ...existing, referenceId: ref, status: nextStatus, ...(reviewersOut ? { reviewers: reviewersOut } : {}) });
      
      // Perform optimistic state transition on parent reference. transitionStatus is a local,
      // synchronous gate (illegal transition / state conflict / authority) independent of the
      // backend call above, so it can fail even though submitDecision just succeeded â€” that
      // used to fail silently, leaving the on-screen reference status stale with no indication.
      let localSyncOk = true;
      if (kind === 'approve' && chainComplete) {
        localSyncOk = approveReference(ref, userEmail, { from: refRow.status || 'pending-review' }).ok;
      } else if (kind === 'reject') {
        localSyncOk = returnReference(ref, userEmail, { from: refRow.status || 'pending-review' }).ok;
      }
      if (!localSyncOk) {
        globalThis.Platform.UI.toast({ message: 'Decision recorded, but the reference status could not be updated locally â€” refreshing.', variant: 'warning' });
        this.refresh();
      }

      const doneKey = (kind === 'approve' && !chainComplete) ? 'approvals.reviewerAdvanced' : (kind === 'approve' ? 'approvals.approved' : 'approvals.rejected');
      globalThis.Platform.UI.actionCompleted(doneKey, { module: 'approvals', target: existing.__ref || existing.referenceId || ref });
    }
  }

  iconFor(t) { return { email: 'âœ‰ï¸', comment: 'ðŸ’¬', task: 'âš¡', document: 'ðŸ“', activity: 'ðŸ“ˆ', reference: 'ðŸ“Š' }[t] || 'ðŸ“„'; }
  fmt(v) { return globalThis.Platform?.Format?.dateTime ? globalThis.Platform.Format.dateTime(v) : String(v); }
}
Modules.register(ApprovalsModule);
export default ApprovalsModule;

