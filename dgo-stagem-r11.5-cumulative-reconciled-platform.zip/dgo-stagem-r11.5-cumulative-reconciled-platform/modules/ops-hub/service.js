/** Compatibility service surface: retained for legacy imports and diagnostics; the active Ops Hub lens reads the hydrated entity fabric. */
/** Service for 'ops-hub' — @see Endpoints#GET_DOCS */
import { BaseService } from '../../core/base-service.js';
export const fetchData = BaseService.endpoint('GET_DOCS', { cache:15000, expectedKeys:['ok','data'] });
export const serviceDescriptor = Object.freeze({ moduleId: 'ops-hub', role: 'operational-lens', serviceMode: 'read', endpoints: Object.freeze(['GET_DOCS']) });
