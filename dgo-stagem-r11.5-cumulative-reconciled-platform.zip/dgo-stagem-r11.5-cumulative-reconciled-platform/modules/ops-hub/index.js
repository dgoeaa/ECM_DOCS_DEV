/**
 * OBSIDIAN v4.2 — Operations Hub Module
 * Remediated: Active card routing layout with responsive, functional detail previews.
 */
import { BaseModule } from '../../core/base-module.js';
import { Modules } from '../../core/modules-registry.js';
import { mountMasterDetail, appendRichSections } from '../../shared/utils/lens.js';
import { el, clear } from '../../shared/utils/dom.js';
import { buildTraceViewModel } from '../../shared/domain/reference-trace.js';


class OpsHubModule extends BaseModule {
  static id = 'ops-hub';
  static label = 'module.ops-hub.title';
  static icon = 'folder';
  static nav = { group: 'ROUTING', order: 2 };
  static audience = 'general';
  static status = 'active';
  static base = new URL('.', import.meta.url);
  
  static ROUTED = new Set(['assigning', 'assigned', 'assignment-failed', 'acknowledged', 'in-progress',
    'action-complete', 'reassign-requested', 'pending-review', 'approved', 'approved-with-edit', 'returned',
    'escalated', 'dispatch-pending', 'dispatch-in-flight', 'dispatched', 'dispatch-failed', 'no-dispatch',
    'closed', 'partial-dispatch', 'archived', 'cold-archived', 'routed', 'replied']);

  async onVisible(root) {
    const E = globalThis.Platform.Entities; if (!await this.ensureFabric(root)) return;
    
    // Explicit list-detail mounting
    mountMasterDetail(this, root, {
      type: 'document', cardLabel: 'title',
      detail: (it, pane, mod) => mod.renderDocDetail(it, pane),
      prefilter: (r) => !OpsHubModule.ROUTED.has(String((r && (r.status || r.Status)) || '').toLowerCase().trim()),
      enableBulkSelect: true,
      bulkActions: ({ selected, clear }) => [
        el('button', {
          class: 'dgo-btn dgo-btn--primary dgo-btn--sm', type: 'button',
          text: `🗂️ ${this.t('opshub.bulkAssign', { n: selected.length })}`,
          onClick: () => {
            globalThis.Platform.Context.setBulkSelection?.(selected);
            globalThis.Platform.State?.set('shared.bulkSelection', { refs: selected, source: this.id, ts: Date.now() });
            globalThis.Platform.Router.navigate('bulk-assignment');
          }
        }),
        el('button', {
          class: 'dgo-btn dgo-btn--secondary dgo-btn--sm', type: 'button',
          text: `📋 ${this.t('opshub.meetingPack', { n: selected.length })}`,
          onClick: () => {
            const A = globalThis.Platform.Actions;
            if (A && A.run) A.run('prepareMeetingPack', {
              preview: {
                titleKey: 'opshub.meetingPackTitle',
                summary: this.t('opshub.meetingPackSummary', { n: selected.length }),
                confirmKey: 'opshub.meetingPackConfirm',
                details: selected.slice(0, 12).map((r) => ({ label: this.t('field.referenceId.label'), value: r }))
              },
              payload: { refs: selected }
            }).then((res) => { if (res && res.ok) clear(); });
          }
        })
      ]
    });
  }

  renderDocDetail(it, pane) {
    clear(pane);
    if (!it) {
      const empty = el('div', { class: 'pf-detail__empty' }, [
        el('p', { class: 'pf-muted', text: 'Select a document card from the gallery to display routing coordinates.' })
      ]);
      pane.appendChild(empty);
      return;
    }
    const ref = it.__ref || it.__id || '';
    const trace = ref ? buildTraceViewModel(ref) : { relatedLinks: [] };
    
    pane.append(
      el('div', { class: 'pf-md__dhead' }, [
        el('div', {}, [el('span', { class: 'pf-badge pf-badge--archived', text: ref })]),
        el('h2', { text: it.title || it.__id }),
        el('p', { class: 'pf-md__meta', text: this.t('opshub.assignedMeta', { who: it.assignedTo || '—', status: it.status || it.Status || '—' }) })
      ]),
      el('div', { class: 'pf-toolbar' }, [
        el('button', { class: 'dgo-btn dgo-btn--primary dgo-btn--sm', text: this.t('opshub.assign'),
          onClick: () => globalThis.Platform.Router.navigate('single-item-ops/' + (it.__ref || it.__id || '')) }),
        el('button', { class: 'dgo-btn dgo-btn--danger dgo-btn--sm', text: this.t('opshub.flag'), onClick: () => this.flag(it) })
      ]),
      el('div', { class: 'pf-toolbar' }, [
        el('span', { class: 'pf-overline', text: this.t('lens.relatedTo', { ref }) }),
        ...trace.relatedLinks
          .filter(({ type }) => type !== 'reference' && type !== 'document')
          .map(({ type, moduleId, icon, count }) => {
            const linkBtn = el('button', { class: 'dgo-btn dgo-btn--secondary dgo-btn--sm', text: `${icon} ${this.t('entity.' + type)} (${count})` });
            this.on(linkBtn, 'click', () => globalThis.Platform.goToEntity(ref, moduleId));
            return linkBtn;
          })
      ])
    );
    appendRichSections(pane, it, this, { type: 'document' });
  }

  async flag(it) {
    const result = await globalThis.Platform.UI.openFlagDocument(it);
  }
}
Modules.register(OpsHubModule);
export default OpsHubModule;
