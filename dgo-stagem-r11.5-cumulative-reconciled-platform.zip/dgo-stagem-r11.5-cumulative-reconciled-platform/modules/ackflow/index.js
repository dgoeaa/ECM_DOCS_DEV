import { BaseModule } from '../../core/base-module.js';
import { Modules } from '../../core/modules-registry.js';
import { el, clear } from '../../shared/utils/dom.js';
import { buildSlaMetric } from '../../shared/domain/sla-projection.js';
import { acknowledgeTask, isAcknowledged } from '../../shared/domain/acknowledgement.js';
import { buildCompactTrace } from '../../shared/domain/reference-trace.js';

class AckFlowModule extends BaseModule {
  static id = 'ackflow';
  static label = 'module.ackflow.title';
  static icon = 'check-circle';
  static nav = { group: 'ACTION', order: 4 };
  static audience = 'general';
  static status = 'active';
  static base = new URL('.', import.meta.url);

  async onVisible(root) {
    /* AUDIT-FIX P22/SEC-06: store root reference before any this.$() calls */
    this._root = root;
    this._region = root.querySelector('[data-region="content"]') || root;
    this._selectedTask = null;

    const E = globalThis.Platform.Entities;
    if (!await this.ensureFabric(root)) return;

    this.bus('entity:changed', () => this.paint());
    this.bus('entity:bootstrapped', () => this.paint());

    /* AUDIT-FIX P22/SEC-06: root.querySelector is safe before this.$() is available */
    this.on(root.querySelector('#af-refresh-btn'), 'click', () => this.refresh());
    this.paint();
  }

  async refresh() {
    await globalThis.Platform.Entities.bootstrap(true);
    this.paint();
  }

  paint() {
    const E = globalThis.Platform.Entities;
    const tasks = E.all('task') || [];
    
    const pendingVal = this.$('#af-pending-val');
    const ackedVal = this.$('#af-acked-val');
    const tbody = this.$('#af-task-rows');
    const detailPane = this.$('#af-detail-pane');
    this._paintSlaMetric(tasks);

    if (!tbody) return;
    clear(tbody);

    let pendingCount = 0;
    let ackedCount = 0;

    if (!tasks.length) {
      tbody.append(
        el('tr', {}, [
          el('td', {
            colspan: '2',
            text: this.t('ackflow.noTasks') }),
        ]),
      );
      this.renderDetail(null, detailPane);
      return;
    }

    tasks.forEach((t, i) => {
      const isAcked = isAcknowledged(t);
      if (isAcked) ackedCount++; else pendingCount++;

      const tr = el('tr', { 'aria-selected': this._selectedTask === t ? 'true' : 'false', tabindex: '0', role: 'option' }, [
        el('td', {}, [
          el('div', { text: t.title || t.subject }),
          el('div', { text: `ID: ${t.id || t.__ref}` })
        ]),
        el('td', {}, [
          el('span', { class: `pf-badge pf-badge--${isAcked ? 'replied' : 'pending'}`, text: t.status || 'Pending' })
        ])
      ]);

      const select = () => {
        this._selectedTask = t;
        [...tbody.children].forEach((row) => row.setAttribute('aria-selected', 'false'));
        tr.setAttribute('aria-selected', 'true');
        this.renderDetail(t, detailPane);
      };
      this.on(tr, 'click', select);
      this.on(tr, 'keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); select(); } });

      tbody.appendChild(tr);
    });

    if (pendingVal) pendingVal.textContent = String(pendingCount);
    if (ackedVal) ackedVal.textContent = String(ackedCount);

    if (this._selectedTask) {
      const stillExists = tasks.find(t => (t.id || t.__ref) === (this._selectedTask.id || this._selectedTask.__ref));
      this._selectedTask = stillExists || null;
      this.renderDetail(this._selectedTask, detailPane);
    } else {
      this._selectedTask = tasks[0] || null;
      const firstRow = tbody.querySelector('tr');
      if (firstRow) firstRow.setAttribute('aria-selected', 'true');
      this.renderDetail(this._selectedTask, detailPane);
    }
  }


  _computeSlaCompliance(tasks = []) {
    return buildSlaMetric(tasks).value;
  }


  _paintSlaMetric(tasks = []) {
    const el = this.$('#af-sla-val');
    if (!el) return;
    const sla = this._computeSlaCompliance(tasks);
    el.textContent = sla == null ? 'N/A' : `${sla}%`;
    const tone = buildSlaMetric(tasks).tone;
    el.style.color = sla == null ? 'var(--color-text-muted)' : tone === 'success' ? 'var(--color-success)' : tone === 'warning' ? 'var(--color-warning)' : 'var(--color-danger)';
    el.setAttribute('aria-label', sla == null ? this.t('ackflow.slaUnavailable') : this.t('ackflow.slaAria', { pct: sla }));
  }

  renderDetail(task, pane) {
    clear(pane);
    if (!task) {
      pane.append(el('div', { class: 'pf-detail__empty' }, [
        el('pf-icon', { name: 'check-circle', size: '24' }),
        el('p', { class: 'pf-muted', text: this.t('ackflow.selectHint') })
      ]));
      return;
    }

    const ref = task.__ref || task.referenceId || task.RefIDD || task.id || '';
    const trace = ref ? buildCompactTrace(ref) : { relatedLinks: [] };
    const isAcked = isAcknowledged(task);

    pane.append(
      el('div', { class: 'pf-detail__head' }, [
        el('div', {}, [
          el('span', { class: 'pf-badge pf-badge--archived', text: ref }),
          el('h3', { text: task.title || task.subject })
        ]),
        el('span', { class: `pf-badge pf-badge--${isAcked ? 'replied' : 'pending'}`, text: task.status })
      ]),
      el('div', { class: 'af-detail__workspace' }, [
        el('div', { class: 'af-detail__email-preview' }, [
          el('span', { class: 'pf-overline', text: this.t('ackflow.emailCoordinates') }),
          el('div', {}, [
            el('strong', { text: this.t('ackflow.fromLabel') }),
            document.createTextNode(' DGO Digital Ops <noreply@dgo.gov.ng>'),
            el('br'),
            el('strong', { text: this.t('ackflow.subjectLabel') }),
            document.createTextNode(' ' + this.t('ackflow.subjectPrefix') + ' ' + (task.title || task.subject || ref))
          ])
        ]),
        el('div', { }, [
          el('button', {
            class: `pf-btn ${isAcked ? 'pf-btn-disabled' : 'pf-btn--primary'}`,
            text: isAcked ? this.t('ackflow.logged') : this.t('ackflow.ackReceipt'),
            disabled: isAcked ? 'disabled' : null,
            onClick: (e) => this.submitAck(task, e.currentTarget)
          }),
          el('button', {
            class: 'pf-btn pf-btn--ghost',
            text: this.t('ackflow.trackHistory'),
            onClick: () => globalThis.Platform.goToEntity(ref, 'response-tracking')
          }),
          ...(trace.relatedLinks || []).filter(({ type }) => type !== 'reference' && type !== 'task').slice(0, 4).map(({ type, moduleId, icon, count }) =>
            el('button', { class: 'pf-btn pf-btn--ghost pf-btn--sm', onClick: () => globalThis.Platform.goToEntity(ref, moduleId) }, [
              document.createTextNode(`${icon} ${this.t('entity.' + type)} (${count})`)
            ]))
        ])
      ])
    );
  }

  async submitAck(task, button) {
    const P = globalThis.Platform;
    const ref = task.__ref || task.id || '';
    if (button && button.dataset.pfBusy === 'true') return;

    const ok = await P.UI.confirm({
      titleKey: 'module.ackflow.title',
      summary: this.t('ackflow.confirmSummary'),
      confirmKey: 'common.actions.confirm',
      details: [
        { label: this.t('field.referenceId.label'), value: ref },
        { label: this.t('ackflow.taskTitle'), value: task.title || task.subject }
      ]
    });
    if (!ok) return;

    if (button) { button.dataset.pfBusy = 'true'; button.disabled = true; button.setAttribute('aria-busy', 'true'); }
    const by = (P.Persona?.email && P.Persona.email()) || `${(P.Persona?.current && P.Persona.current()) || 'web-ops'}@nitda.gov.ng`;
    const res = await acknowledgeTask(task, { ref, by });
    if (button) { button.dataset.pfBusy = 'false'; button.removeAttribute('aria-busy'); }
    if (res.ok) {
      P.UI.toast({ message: res.alreadyApplied ? this.t('ackflow.alreadyRecorded') : this.t('ackflow.recorded'), variant: 'success' });
      this.paint();
    } else {
      P.UI.toast({ message: res.message || this.t('ackflow.failed'), variant: 'danger' });
      if (button) button.disabled = false;
    }
  }
}

Modules.register(AckFlowModule);
export default AckFlowModule;
