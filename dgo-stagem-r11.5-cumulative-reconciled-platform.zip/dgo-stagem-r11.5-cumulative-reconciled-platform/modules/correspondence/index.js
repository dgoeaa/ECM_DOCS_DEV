/**
 * OBSIDIAN v4.2 — Intake Triage Desk Module
 * Remediated: High-fidelity split workspace displaying email cards, triage status, and logs.
 */
import { BaseModule } from '../../core/base-module.js';
import { appendRichSections } from '../../shared/utils/lens.js';
import { Modules } from '../../core/modules-registry.js';
import { aiClassify, createCorrespondence } from './service.js';
import { el, clear, withBusy } from '../../shared/utils/dom.js';
import { renderForm, emptyState } from '../../shared/utils/render.js';
import { stripHtmlToText } from '../../shared/utils/html-entities.js';
import { normalizeCorrespondenceRecord } from '../../shared/utils/correspondence-cleanup.js';


function stripHtmlPreview(value) {
  return stripHtmlToText(value);
}

class CorrespondenceModule extends BaseModule {
  static id = 'correspondence';
  static label = 'module.correspondence.title';
  static icon = 'mail';
  static nav = { group: 'INTAKE', order: 1 };
  static audience = 'general';
  static status = 'active';
  static base = new URL('.', import.meta.url);

    async onVisible(root, params) {
    this._splitEl = root.querySelector('.pf-corr__split');
    this._tableEl = root.querySelector('[data-region="table"]');
    this._detailEl = root.querySelector('[data-region="detail"]');
    const filterHost = root.querySelector('[data-region="filter"]');
    
    if (this._splitEl) {
      this._splitEl.setAttribute('data-view', 'list');
    }
    clear(filterHost);
    this._filter = document.createElement('pf-filter-bar');
    this._filter.statuses = [
      { value: 'pending', labelKey: 'status.pending' }, 
      { value: 'routed', labelKey: 'status.routed' },
      { value: 'replied', labelKey: 'status.replied' }, 
      { value: 'closed', labelKey: 'status.closed' }
    ];
    filterHost.appendChild(this._filter);
    this.on(this._filter, 'pf-filter:change', (e) => { 
      this._q = e.detail.query; 
      this._status = e.detail.status; 
      this.renderTable(); 
    });

    this.on(root.querySelector('[data-act="export"]'), 'click', () => this.exportCsv());
    this.on(root.querySelector('[data-act="new"]'), 'click', () => this.openCreate());

    const E = globalThis.Platform.Entities;
    if (!await this.ensureFabric(root)) return;
    this.bus('entity:email:changed', () => this.refresh());
    this.bus('entity:reference:updated', () => this.refresh());
    this.bus('context:reference:changed', (e) => { if (e.source !== this.id) this.selectRef(e.ref); });

    this.refresh();
    const deep = params && params.path && params.path[0];
    if (deep) this.selectRef(deep);
  }

  source() {
    return (globalThis.Platform.Entities.all('document') || []).map((r) => normalizeCorrespondenceRecord(r));
  }

  filtered() {
    return this.source().filter((r) => {
      const st = String(r.status || r.Status || '').toLowerCase();
      if (this._status && st !== this._status) return false;
      if (!this._q) return true;
      return [r.__cleanTitle, r.__cleanBody, r.__cleanSender, r.__cleanRef, r.subject, r.sender, r.from, r.__ref, r.title, r.category].some((v) => 
        String(v || '').toLowerCase().includes(this._q)
      );
    });
  }

  refresh() { 
    this._rows = this.filtered(); 
    this.renderTable(); 
    if (!this._selRef) this.renderDetail(null); 
  }

  renderTable() {
    this._rows = this.filtered();
    this._filter.count = this._rows.length;
    clear(this._tableEl);
    
    if (!this._rows.length) { 
      emptyState(this._tableEl, 'common.state.empty'); 
      return; 
    }
    
    const listContainer = el('div', { class: 'pf-corr-list' });
    this._rows.forEach((r) => {
      const st = String(r.__cleanStatus || r.status || r.Status || 'Pending');
      const itemCard = el('div', { 
        class: 'pf-corr-card', role: 'button', tabindex: '0',
        'aria-label': r.__cleanTitle || r.title || r.subject || 'Open correspondence',
        'data-ref': r.__cleanRef || r.__ref || r.__id || ''
      }, [
        el('div', { }, [
          el('span', { class: 'pf-overline pf-corr-card__ref', text: r.__cleanRef || r.__ref || 'ORPHAN' }),
          el('span', { class: 'pf-badge', text: st })
        ]),
        el('div', { class: 'pf-corr-card__title', text: r.__cleanTitle || r.title || r.subject || 'Untitled Correspondence' }),
        el('div', { }, [
          el('span', { text: r.__cleanSender || r.sender || r.from || 'Central Registry' }),
          el('span', { text: r.__cleanDate ? this.fmt(r.__cleanDate) : (r.ts ? this.fmt(r.ts) : '—') })
        ])
      ]);

      const openCard = () => { const refKey = r.__cleanRef || r.__ref || r.__id; if (r.__ref) globalThis.Platform.Context.setActive(r.__ref, this.id); this.selectRef(refKey, r); };
      itemCard.addEventListener('click', openCard);
      itemCard.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openCard(); } });
      listContainer.appendChild(itemCard);
    });

    this._tableEl.appendChild(listContainer);
    this.markSelected();
  }

  markSelected() {
    const cards = this._tableEl.querySelectorAll('.pf-corr-card');
    cards.forEach((card) => {
      const active = card.getAttribute('data-ref') === this._selRef;
      card.style.borderColor = active ? 'var(--dgo-color-action-primary)' : 'var(--dgo-color-border-default)';
      card.style.background = active ? 'var(--dgo-green-50)' : 'var(--dgo-color-surface-raised)';
    });
  }

    selectRef(ref, rec) {
    if (!ref) return;
    this._selRef = String(ref);
    const item = rec || this.source().find((r) => (r.__ref || r.__id || r.__cleanRef) === this._selRef);
    this.markSelected();
    if (this._splitEl) {
      this._splitEl.setAttribute('data-view', 'detail');
    }
    this.renderDetail(item);
  }


  _showList() {
    if (this._splitEl) this._splitEl.setAttribute('data-view', 'list');
    const activeCard = this._tableEl?.querySelector?.(`[data-ref="${this._selRef}"]`);
    if (activeCard && typeof activeCard.focus === 'function') activeCard.focus();
  }

    renderDetail(it) {
    clear(this._detailEl);
    if (!it) { 
      emptyState(this._detailEl, 'correspondence.selectHint'); 
      return; 
    }
    const ref = it.__ref || it.__id || '';
    
    // Mobile back navigation trigger
    const backBtn = el('button', {
      class: 'dgo-btn dgo-btn--secondary dgo-btn--sm pf-back-btn',
      text: '← Back to Inbox',
      onClick: () => {
        this._showList();
      }
    });
    
    const triageBar = document.createElement('pf-triage-bar');
    triageBar.item = it;
    this.on(triageBar, 'pf-triage:routed', () => this.refresh());
    this.on(triageBar, 'pf-triage:acknowledged', () => this.refresh());

    const classifyBtn = el('button', { class: 'dgo-btn dgo-btn--secondary dgo-btn--sm', text: `🧠 ${this.t('correspondence.aiClassify')}` });
    this.on(classifyBtn, 'click', () => withBusy(classifyBtn, () => this.classify(it), { busyLabel: this.t('common.actions.processing') }));

    const contentArea = el('div', { class: 'pf-corr-detail__body' }, [
      el('div', { class: 'pf-corr-detail__meta' }, [
        el('h2', { class: 'pf-corr-detail__title', text: it.__cleanTitle || it.subject || it.title || ref }),
        el('p', { class: 'sender-info', text: this.t('correspondence.fromMeta', { who: it.__cleanSender || it.sender || it.from || 'Central Registry', ref: it.__cleanRef || ref }) }),
        el('div', { class: 'pf-corr-detail__chips' }, [el('span', { class: 'pf-badge', text: it.__cleanStatus || it.status || 'Pending' }), it.__cleanDate ? el('span', { class: 'pf-chip', text: this.fmt(it.__cleanDate) }) : null, it.__cleanFileName ? el('span', { class: 'pf-chip pf-chip--file', text: it.__cleanFileName }) : null].filter(Boolean))
      ]),
      el('div', { class: 'pf-corr-detail__desc' }, [
        el('p', { text: it.__cleanBody || it.body || it.summary || 'No payload description available.' })
      ]),
      el('div', { class: 'pf-corr-detail__actions' }, [
        classifyBtn,
        el('button', { class: 'dgo-btn dgo-btn--secondary dgo-btn--sm', text: '📂 Open Folder', onClick: () => globalThis.Platform.goToEntity(ref, 'ops-hub') }),
        el('button', { class: 'dgo-btn dgo-btn--secondary dgo-btn--sm', text: '💬 Comments', onClick: () => globalThis.Platform.UI.openComments?.(ref) }), el('button', { class: 'dgo-btn dgo-btn--primary dgo-btn--sm', text: '⚡ Allocate Task', onClick: async () => { const r = await globalThis.Platform.UI.openEmailToTask(it); if (r && r.ok) this.refresh(); } })
      ])
    ]);

    this._detailEl.append(backBtn, triageBar, contentArea);
    appendRichSections(this._detailEl, it, this, { type: 'email', enableComments: false, enableActivity: false });
  }

  async classify(it) {
    const result = await this.call(aiClassify, { action: 'aiAnalyseEmail', emailId: it.__id, referenceId: it.__ref, subject: it.subject });
    if (result.ok) {
      const d = result.data || {};
      globalThis.Platform.Entities.upsert('email', { ...it, referenceId: it.__ref, category: d.category || it.category, priority: d.priority || it.priority, status: d.status || it.status });
      globalThis.Platform.UI.actionCompleted('correspondence.classified', { module: 'correspondence', target: it.__ref || it.referenceId || it.__id });
    }
  }

  openCreate() {
    globalThis.Platform.UI.modal({
      titleKey: 'correspondence.new', component: null, bodyKey: null,
      actions: [{ labelKey: 'common.actions.cancel' }]
    });
    const body = document.querySelector('pf-modal')?.shadowRoot?.querySelector('#m-body');
    if (body) renderForm(body, {
      fields: [
        { name: 'sender', labelKey: 'field.sender.label' },
        { name: 'subject', labelKey: 'field.subject.label' },
        { name: 'RefIDD', labelKey: 'field.referenceId.label' },
        { name: 'body', labelKey: 'correspondence.detailsLabel', type: 'textarea' },
        { name: 'priority', labelKey: 'field.priority.label', type: 'select',
          options: [
            { value: 'High', labelKey: 'priority.high' }, 
            { value: 'Medium', labelKey: 'priority.medium' }, 
            { value: 'Low', labelKey: 'priority.low' }
          ] 
        }
      ],
      submitKey: 'correspondence.new',
      onSubmit: async (values) => {
        const ok = await globalThis.Platform.UI.confirm({ 
          titleKey: 'correspondence.new', 
          summaryKey: 'action.confirmSummary',
          details: [ 
            { label: this.t('field.subject.label'), value: values.subject || '—' }, 
            { label: this.t('field.sender.label'), value: values.sender || '—' }, 
            { label: this.t('field.referenceId.label'), value: values.RefIDD || '—' } 
          ], 
          confirmKey: 'correspondence.new' 
        });
        if (!ok) return;
        const result = await this.call(createCorrespondence, { action: 'emailtotaskassignment', ...values });
        if (result.ok) {
          globalThis.Platform.Entities.upsert('email', { referenceId: values.RefIDD, subject: values.subject, sender: values.sender, body: values.body, priority: values.priority, status: 'Pending', ts: new Date().toISOString() });
          globalThis.Platform.UI.closeModal();
          globalThis.Platform.UI.actionCompleted('correspondence.created', { module: 'response-tracking' });
        }
      }
    });
  }

  exportCsv() {
    const cols = [['referenceId', 'Reference'], ['subject', 'Subject'], ['sender', 'Sender'], ['ts', 'Date'], ['priority', 'Priority'], ['status', 'Status']];
    const rows = (this._rows || []).map((r) => ({ referenceId: r.__ref, subject: r.subject || r.title, sender: r.sender || r.from, ts: r.ts, priority: r.priority, status: r.status || r.Status }));
    globalThis.Platform.Format.downloadCsv('correspondence.csv', globalThis.Platform.Format.toCsv(rows, cols.map(([key, label]) => ({ key, label }))));
  }

  fmt(v) { return globalThis.Platform?.Format?.dateTime ? globalThis.Platform.Format.dateTime(v) : String(v); }
}

Modules.register(CorrespondenceModule);
export default CorrespondenceModule;
