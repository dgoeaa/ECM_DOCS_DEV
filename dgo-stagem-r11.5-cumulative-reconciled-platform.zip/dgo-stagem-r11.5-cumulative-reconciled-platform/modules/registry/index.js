/**
 * OBSIDIAN v4.4 - Registry, File Movement & Minute Sheet Module
 * Phase 4: canonical minute-sheet lineage and route governance adoption.
 */
import { BaseModule } from '../../core/base-module.js';
import { Modules } from '../../core/modules-registry.js';
import { el, clear, withBusy } from '../../shared/utils/dom.js';
import { buildCompactTrace } from '../../shared/domain/reference-trace.js';
import { Lookups } from '../../shared/utils/lookups.js';
import { createMinute, appendConfirmedMinute, loadMinutes, minuteActionLabel, priorityLabel, summarizeMinutes } from '../../shared/domain/minute-ledger.js';
import { updateTask } from './service.js';
import { appendMovement } from '../../shared/domain/movement.js';

function statusBadge(status) {
  const clean = String(status || 'Pending').trim();
  const cls = clean.toLowerCase().replace(/[^a-z0-9]+/g, '-');
  return el('span', { class: `pf-badge pf-badge--${cls || 'pending'}`, text: clean || 'Pending' });
}

function option(value, text, selected) {
  return el('option', { value, text, selected: selected ? 'selected' : null });
}

class RegistryModule extends BaseModule {
  static id = 'registry';
  static label = 'module.registry.title';
  static icon = 'git-branch';
  static nav = { group: 'ROUTING', order: 1 };
  static audience = 'general';
  static status = 'active';
  static base = new URL('.', import.meta.url);

  async onVisible(root) {
    this._region = root.querySelector('[data-region="content"]') || root;
    this._selectedRef = this._selectedRef || null;
    if (!await this.ensureFabric(root)) return;
    await Lookups.load();
    this.bus('entity:bootstrapped', () => this.paint());
    this.bus('entity:changed', () => this.paint());
    this.paint();
  }

  paint() {
    clear(this._region);
    const E = globalThis.Platform.Entities;
    const refs = E.all('reference');
    const grid = el('div', { class: 'pf-list__split' });
    const leftPane = el('div', { class: 'pf-list__main' });
    const rightPane = el('aside', { class: 'pf-card pf-list__detail' });
    grid.append(leftPane, rightPane);
    this._region.append(grid);

    const wrap = el('div', { class: 'pf-card pf-table-wrap' });
    leftPane.append(wrap);

    if (refs.length === 0) {
      wrap.append(el('div', { class: 'pf-empty' }, [el('div', { class: 'pf-empty__title', text: this.t('common.state.empty') })]));
      this._renderEmptyDetail(rightPane);
      return;
    }

    const head = el('thead', {}, [
      el('tr', {}, [
        el('th', { text: 'File Reference' }),
        el('th', { text: 'Subject / Directive' }),
        el('th', { text: 'Location DSU' }),
        el('th', { text: 'Status' })
      ])
    ]);

    const body = el('tbody', {}, refs.map((r) => this._renderReferenceRow(wrap, rightPane, r)));
    wrap.append(el('table', { class: 'pf-table pf-table--selectable' }, [head, body]));

    if (this._selectedRef) {
      const active = wrap.querySelector(`tr[data-ref="${CSS.escape(this._selectedRef.referenceId)}"]`);
      if (active) {
        this._highlightRow(wrap, active);
        this._renderMinuteSheet(rightPane, this._selectedRef);
      } else {
        this._renderEmptyDetail(rightPane);
      }
    } else {
      this._renderEmptyDetail(rightPane);
    }
  }

  _renderReferenceRow(wrap, rightPane, r) {
    const isSelected = this._selectedRef && this._selectedRef.referenceId === r.referenceId;
    const tr = el('tr', {
      'data-ref': r.referenceId,
      tabindex: '0',
      'aria-selected': isSelected ? 'true' : 'false'
    }, [
      el('td', { text: r.referenceId, class: 'font-mono' }),
      el('td', { text: r.title || 'Untitled Dossier' }),
      el('td', { text: r.__directorate || 'Central Mailroom' }),
      el('td', {}, [statusBadge(r.status || 'Pending')])
    ]);

    const select = () => {
      this._selectedRef = r;
      this._highlightRow(wrap, tr);
      this._renderMinuteSheet(rightPane, r);
    };
    this.on(tr, 'click', select);
    this.on(tr, 'keydown', (event) => {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        select();
      }
    });
    return tr;
  }

  _highlightRow(container, tr) {
    container.querySelectorAll('tr').forEach((row) => row.setAttribute('aria-selected', 'false'));
    tr.setAttribute('aria-selected', 'true');
  }

  _renderEmptyDetail(pane) {
    clear(pane);
    pane.append(el('div', { class: 'pf-detail__empty' }, [
      el('pf-icon', { name: 'git-branch', size: '24' }),
      el('p', { class: 'pf-muted', text: 'Select an active digital file to inspect official minute entries.' })
    ]));
  }

  _renderMinuteSheet(pane, ref) {
    clear(pane);
    const refId = ref.referenceId;
    const trace = buildCompactTrace(refId);
    const storage = globalThis.Platform.Storage;
    const minutes = loadMinutes(storage, refId);
    const summary = summarizeMinutes(minutes);

    const sheet = el('section', { class: 'pf-minute-sheet', 'aria-label': 'Official minute sheet' }, [
      this._renderMinuteHeader(ref, trace, summary),
      this._renderMinuteTimeline(minutes)
    ]);

    pane.append(sheet, this._renderMinuteForm(ref, minutes));
  }

  _renderMinuteHeader(ref, trace, summary) {
    const meta = el('div', { class: 'pf-grid', style: 'margin-top:var(--space-3)' }, [
      this._statTile('Minutes', summary.total),
      this._statTile('Routed', summary.routed),
      this._statTile('Urgent', summary.urgent),
      this._statTile('Last action', summary.lastAction)
    ]);
    return el('header', {}, [
      el('span', { class: 'pf-overline', text: 'Official Minute Sheet' }),
      el('h3', { text: ref.title || 'Untitled Document' }),
      el('code', { text: `REF: ${ref.referenceId}` }),
      el('p', { class: 'pf-muted', text: `Trace: ${trace.counts.document || 0} document(s), ${trace.counts.task || 0} task(s), ${trace.counts.comment || 0} comment(s), ${trace.counts.approval || 0} approval(s)` }),
      meta
    ]);
  }

  _statTile(label, value) {
    return el('div', { class: 'pf-stat' }, [
      el('div', { class: 'pf-stat__label', text: label }),
      el('div', { class: 'pf-stat__value', text: String(value) })
    ]);
  }

  _renderMinuteTimeline(minutes) {
    const list = el('ol', { class: 'pf-detail__activity', style: 'margin-top:var(--space-4)' });
    if (!minutes.length) {
      list.append(el('li', { class: 'pf-detail__activity-item' }, [
        el('div', { class: 'pf-muted', text: 'No official minutes have been entered for this reference yet.' })
      ]));
      return list;
    }
    minutes.forEach((m) => {
      list.append(el('li', { class: 'pf-detail__activity-item' }, [
        el('div', { class: 'pf-detail__activity-when', text: globalThis.Platform.Format.dateTime(m.timestamp) }),
        el('div', { class: 'pf-detail__activity-what' }, [
          el('div', { class: 'pf-overline', text: `${m.num} - ${minuteActionLabel(m.action)} - ${priorityLabel(m.priority)}` }),
          el('p', { text: m.text }),
          el('p', { class: 'pf-muted', text: `By ${m.author}${m.routeToLabel ? ' - routed to ' + m.routeToLabel : ''}${m.correlationId ? ' - ' + m.correlationId : ''}` })
        ])
      ]));
    });
    return list;
  }

  _renderMinuteForm(ref, minutes) {
    const textarea = el('textarea', { class: 'pf-input dgo-textarea', rows: '3', placeholder: 'Enter directives, remarks, or comments...', required: true });
    const officers = globalThis.Platform.Lookups.users ? globalThis.Platform.Lookups.users() : [];
    const routeSelect = el('select', { class: 'pf-input dgo-select__field', required: true }, [
      option('', 'Route To...', false),
      ...officers.map((o) => option(o.value, `${o.label} (${o.sub || 'Representative'})`, false))
    ]);
    const actionSelect = el('select', { class: 'pf-input dgo-select__field', required: true }, [
      option('FOR_ACTION', 'For Action & Dispatch', true),
      option('FOR_ATTENTION', 'For Attention', false),
      option('FOR_REVIEW', 'For Policy Review', false),
      option('FOR_DG_ATTENTION', 'For DG Attention', false),
      option('COMPLY', 'Comply', false)
    ]);
    const prioritySelect = el('select', { class: 'pf-input dgo-select__field', required: true }, [
      option('LOW', 'Low', false),
      option('MEDIUM', 'Medium', true),
      option('HIGH', 'High', false),
      option('URGENT', 'Urgent', false)
    ]);
    const submitBtn = el('button', { class: 'dgo-btn dgo-btn--primary dgo-btn--block', type: 'submit', text: 'Append & Forward' });
    const form = el('form', { class: 'pf-form' }, [
      el('h4', { class: 'pf-overline', text: 'Constitute New Minute' }),
      el('div', { class: 'pf-field' }, [textarea]),
      el('div', { class: 'pf-field' }, [routeSelect]),
      el('div', { class: 'pf-field' }, [actionSelect]),
      el('div', { class: 'pf-field' }, [prioritySelect]),
      submitBtn
    ]);

    this.on(form, 'submit', async (event) => {
      event.preventDefault();
      await withBusy(submitBtn, async () => this._submitMinute({ ref, minutes, textarea, routeSelect, actionSelect, prioritySelect }));
    });
    return form;
  }

  async _submitMinute({ ref, textarea, routeSelect, actionSelect, prioritySelect }) {
    const text = textarea.value.trim();
    const targetUser = routeSelect.value;
    const targetLabel = routeSelect.selectedOptions && routeSelect.selectedOptions[0] ? routeSelect.selectedOptions[0].textContent : targetUser;
    const action = actionSelect.value;
    const priority = prioritySelect.value;
    if (!text || !targetUser) {
      globalThis.Platform.UI.toast({ message: 'Enter a minute and routing destination before forwarding.', variant: 'warning' });
      return;
    }

    const user = globalThis.Platform.Persona.profile() || { fullName: 'Desk Representative' };
    const minute = createMinute({ referenceId: ref.referenceId, text, action, priority, routeTo: targetUser, routeToLabel: targetLabel, profile: user });
    const res = await this.call(updateTask, {
      action: 'UPDATE_TASK',
      operation: 'update',
      mode: 'switch',
      taskId: ref.referenceId,
      status: 'ROUTED',
      progress: 50,
      priority,
      notes: `Minute appended: ${text}. Forwarded to: ${targetLabel}.`,
      minute
    });

    if (res && res.ok) {
      const confirmedMinute = { ...minute, correlationId: res.correlationId || minute.correlationId };
      appendConfirmedMinute(globalThis.Platform.Storage, ref.referenceId, confirmedMinute);
      appendMovement({ referenceId: ref.referenceId, action: confirmedMinute.action, from: ref.__directorate || 'Central Mailroom', to: targetUser, note: text, by: confirmedMinute.author, timestamp: confirmedMinute.timestamp, correlationId: confirmedMinute.correlationId, source: 'registry-minute' });
      const E = globalThis.Platform.Entities;
      E.upsert('reference', { ...ref, status: 'ROUTED', __directorate: targetUser, __lastMinuteAt: confirmedMinute.timestamp, __lastMinuteAction: confirmedMinute.action });
      textarea.value = '';
      routeSelect.selectedIndex = 0;
      actionSelect.selectedIndex = 0;
      prioritySelect.value = 'MEDIUM';
      globalThis.Platform.UI.toastSuccess('Minute appended and file routed.');
      this.paint();
    }
  }
}

Modules.register(RegistryModule);
export default RegistryModule;
