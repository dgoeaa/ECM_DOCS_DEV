/**
 * OBSIDIAN v4.2 — Registry Service Endpoint Setup
 * Remediated (INT-01): Added updateTask export mapped to SUBSIDIARY_ACTIONS.
 */
import { BaseService } from '../../core/base-service.js';

export const fetchData = BaseService.endpoint('SUBSIDIARY_ACTIONS', { cache:15000, expectedKeys:['success','data'] });
export const updateTask = BaseService.endpoint('SUBSIDIARY_ACTIONS', { expectedKeys: ['success', 'data'] });
export const serviceDescriptor = Object.freeze({ moduleId: 'registry', role: 'registry-write-workbench', serviceMode: 'read-write', endpoints: Object.freeze(['SUBSIDIARY_ACTIONS']) });
