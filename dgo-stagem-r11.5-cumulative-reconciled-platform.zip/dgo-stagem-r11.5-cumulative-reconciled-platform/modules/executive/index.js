/** OBSIDIAN v4.0 — module 'executive' (Executive · AGGREGATOR · audience:executive).
 *  DG/CEO overview: top-line KPIs, priority mix, overdue attention, and recent references —
 *  computed from Entities.counts() over the whole fabric. Cross-links into the lenses. */
import { BaseModule } from '../../core/base-module.js';
import { Modules } from '../../core/modules-registry.js';
import { el, clear } from '../../shared/utils/dom.js';
import { breakdownBars, attentionList } from '../../shared/utils/lens.js';
import { Charts } from '../../core/charts.js';
import { buildExecutiveSummary } from '../../shared/domain/rollups.js';
import { buildExecutiveResponseMatrix } from '../../shared/domain/response-matrix.js';

class ExecutiveModule extends BaseModule {
  static id = 'executive'; static label = 'module.executive.title'; static icon = 'briefcase';
  static nav = { group: 'REVIEW', order: 2 }; static audience = 'executive'; static status = 'active';
  static base = new URL('.', import.meta.url);

  async onVisible(root) {
    this._region = root.querySelector('[data-region="content"]') || root;
    const E = globalThis.Platform.Entities;
    if (!await this.ensureFabric(root)) return;
    this.bus('entity:bootstrapped', () => this.paint());
    this.bus('entity:changed', () => this.paint());
    this.paint();
  }

  _kpi(labelKey, value, modId, danger) {
    const card = el('button', { class: 'pf-stat' + (danger && value ? ' pf-stat--alert' : ''), style: 'text-align:left;width:100%;cursor:pointer' }, [
      el('div', { class: 'pf-stat__label', text: this.t(labelKey) }),
      el('div', { class: 'pf-stat__value', text: String(value) })
    ]);
    if (modId) this.on(card, 'click', () => globalThis.Platform.Router.navigate(modId));
    return card;
  }

  paint() {
    const summary = buildExecutiveSummary();
    const responseMatrix = buildExecutiveResponseMatrix();
    const c = summary.counts;
    clear(this._region);
    this._region.append(
      el('div', { class: 'pf-grid' }, [
        this._kpi('agg.kpi.references', summary.kpis.references || 0, 'response-tracking'),
        this._kpi('agg.kpi.openTasks', summary.kpis.openTasks || 0, 'orchestrator'),
        this._kpi('agg.kpi.pendingApprovals', summary.kpis.pendingApprovals || 0, 'approvals'),
        this._kpi('agg.kpi.overdue', summary.kpis.overdue || 0, 'orchestrator', true),
        this._kpi('Executive Matrix', responseMatrix.totalReferences || 0, 'response-tracking')
      ]),
      breakdownBars('agg.priorityMix', summary.priorityMix, { accent: 'var(--color-warning)' }),
      attentionList('agg.overdue', summary.overdueItems, { modId: 'orchestrator' }),
      this._renderMatrixPanel(responseMatrix),
      this._renderExecutiveCommandPanel(summary, responseMatrix),
      el('div', { class: 'pf-card', style: 'padding:var(--space-5);margin-top:var(--space-5)' }, [
        el('div', { class: 'pf-overline', text: this.t('charts.activity14d') }),
        el('div', { style: 'margin-top:var(--space-3)' }, [Charts.sparkline(summary.timeline, { label: this.t('charts.activity14d') })])
      ])
    );

    // Recent references — the spine's latest activity, deep-linking into response-tracking.
    const recent = summary.recent || [];
    const list = el('div', { class: 'pf-card', style: 'padding:var(--space-5);margin-top:var(--space-5)' }, [
      el('div', { class: 'pf-overline', text: this.t('agg.recent') }),
      el('div', { style: 'display:flex;flex-direction:column;gap:var(--space-1);margin-top:var(--space-3)' },
        recent.length ? recent.map((r) => {
          const row = el('button', { class: 'pf-btn pf-btn--ghost', style: 'justify-content:space-between;width:100%;text-align:left' }, [
            el('span', { text: r.title || r.referenceId }),
            el('span', { class: 'pf-badge pf-badge--info', text: r.referenceId })
          ]);
          this.on(row, 'click', () => globalThis.Platform.goToEntity(r.referenceId, 'response-tracking'));
          return row;
        }) : [el('p', { class: 'pf-muted', text: this.t('agg.none') })])
    ]);
    this._region.append(list);

  }


  _renderExecutiveCommandPanel(summary, matrix) {
    const P = globalThis.Platform;
    const users = P.RBAC?.users?.() || [];
    const activeUsers = users.filter((u) => u.status !== 'disabled').length;
    const elevatedUsers = users.filter((u) => ['systemAdmin','userAdmin','executive'].includes(u.role)).length;
    const riskTotal = (matrix.riskSummary?.critical || 0) + (matrix.riskSummary?.high || 0);
    const exportBtn = el('button', { class:'dgo-btn dgo-btn--secondary', type:'button', text:'Executive export', disabled:P.Persona.hasPermission?.('executive:export') ? null : 'disabled' });
    this.on(exportBtn, 'click', () => {
      const payload = { generatedAt:new Date().toISOString(), kpis:summary.kpis, risk:matrix.riskSummary, activeUsers, elevatedUsers };
      const blob = new Blob([JSON.stringify(payload,null,2)], { type:'application/json' });
      const url = URL.createObjectURL(blob); const a = document.createElement('a');
      a.href = url; a.download = 'dgo-executive-brief.json'; a.click(); URL.revokeObjectURL(url);
      P.UI.toast({ message:'Executive brief exported.', variant:'success' });
    });
    const userAdminBtn = el('button', { class:'dgo-btn dgo-btn--primary', type:'button', text:'Open user administration', disabled:P.Persona.hasPermission?.('user:view') ? null : 'disabled' });
    this.on(userAdminBtn, 'click', () => P.Router.navigate('user-admin'));
    return el('section', { class:'pf-card executive-command-panel', style:'padding:var(--space-5);margin-top:var(--space-5)' }, [
      el('div', { class:'pf-overline', text:'Executive Command Layer' }),
      el('div', { class:'pf-grid', style:'margin-top:var(--space-3)' }, [
        this._kpi('High / critical risk', riskTotal, 'response-tracking', true),
        this._kpi('Active users', activeUsers, 'user-admin'),
        this._kpi('Elevated access', elevatedUsers, 'user-admin', elevatedUsers > 3),
        this._kpi('Open approvals', summary.kpis.pendingApprovals || 0, 'approvals', (summary.kpis.pendingApprovals || 0) > 0)
      ]),
      el('p', { class:'pf-muted', text:'Executive view now combines operational health, response risk, pending approvals, and privileged access concentration.' }),
      el('div', { class:'pf-toolbar' }, [exportBtn, userAdminBtn])
    ]);
  }

  _renderMatrixPanel(matrix) {
    const body = el('tbody', {});
    (matrix.topRiskRows || []).slice(0, 8).forEach((row) => {
      const open = el('button', { type: 'button', class: 'pf-btn pf-btn--ghost', text: 'Open' });
      this.on(open, 'click', () => globalThis.Platform.goToEntity(row.referenceId, row.targetModule || 'response-tracking'));
      body.append(el('tr', {}, [
        el('td', { text: row.referenceId }),
        el('td', { text: row.title || row.referenceId }),
        el('td', { text: row.directorate || '—' }),
        el('td', { text: row.riskBand }),
        el('td', { text: row.actionCue }),
        el('td', {}, [open])
      ]));
    });
    if (!body.childNodes.length) body.append(el('tr', {}, [el('td', { colspan: '6', text: 'No response-matrix rows available.' })]));
    return el('div', { class: 'pf-card', style: 'padding:var(--space-5);margin-top:var(--space-5)' }, [
      el('div', { class: 'pf-overline', text: 'Executive Response Matrix' }),
      el('p', { class: 'pf-muted', text: `References: ${matrix.totalReferences}; overdue: ${matrix.overdueReferences}; pending review: ${matrix.pendingReviewReferences}; dead letters: ${matrix.deadLetterCount}; high/critical risk: ${(matrix.riskSummary?.critical || 0) + (matrix.riskSummary?.high || 0)}.` }),
      el('div', { class: 'pf-table-wrap', style: 'margin-top:var(--space-3)' }, [
        el('table', { class: 'pf-table' }, [
          el('thead', {}, [el('tr', {}, ['Reference', 'Title', 'Directorate', 'Risk', 'Cue', 'Action'].map((h) => el('th', { text: h })))]),
          body
        ])
      ])
    ]);
  }
}
Modules.register(ExecutiveModule);
export default ExecutiveModule;
