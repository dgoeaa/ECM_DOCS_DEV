/** Service for 'executive' — @see Endpoints#FETCH_ALL */
import { BaseService } from '../../core/base-service.js';
export const fetchData = BaseService.endpoint('FETCH_ALL', { cache:15000, expectedKeys:['ok','data'] });
export const serviceDescriptor = Object.freeze({ moduleId: 'executive', role: 'executive-lens', serviceMode: 'read', endpoints: Object.freeze(['FETCH_ALL']) });
