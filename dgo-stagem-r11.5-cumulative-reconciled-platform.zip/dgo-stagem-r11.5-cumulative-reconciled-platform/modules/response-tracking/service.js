/** Service for 'response-tracking' — @see Endpoints#SUBSIDIARY_ACTIONS */
import { BaseService } from '../../core/base-service.js';
export const fetchData = BaseService.endpoint('SUBSIDIARY_ACTIONS', { cache:15000, expectedKeys:['success','data'] });
export const serviceDescriptor = Object.freeze({ moduleId: 'response-tracking', role: 'response-lens', serviceMode: 'read', endpoints: Object.freeze(['SUBSIDIARY_ACTIONS']) });
