/** Service for 'lookup' — purely local; no remote endpoint needed (uses Entities + Lookups). */

export const serviceDescriptor = Object.freeze({ moduleId: 'lookup', role: 'reference-lens', serviceMode: 'local', endpoints: Object.freeze([]) });
export default {};
