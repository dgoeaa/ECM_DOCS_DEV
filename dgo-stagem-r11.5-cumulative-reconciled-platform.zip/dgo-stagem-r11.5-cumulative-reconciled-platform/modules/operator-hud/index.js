import { BaseModule } from '../../core/base-module.js';
import { Modules } from '../../core/modules-registry.js';
import { el, clear } from '../../shared/utils/dom.js';
import { renderSlaMeterNode } from '../../shared/utils/lens.js';
import { buildOperatorMatrix } from '../../shared/domain/rollups.js';

const PAGE_SIZES = [25, 50, 100];
const DEFAULT_PAGE_SIZE = 50;
const MAX_RENDERED_ROWS = 200;

class OperatorHudModule extends BaseModule {
  static id = 'operator-hud';
  static label = 'module.operator-hud.title';
  static icon = 'globe';
  static nav = { group: 'CrossPhase', order: 7 };
  static audience = 'all';
  static status = 'active';
  static base = new URL('.', import.meta.url);

  async onVisible(root) {
    this._region = root.querySelector('[data-region="content"]');
    this._page = this._page || 1;
    this._pageSize = this._pageSize || DEFAULT_PAGE_SIZE;
    this._renderScheduled = false;
    const E = globalThis.Platform.Entities;
    this.bus('entity:loading', () => this._schedulePaint());
    this.bus('entity:bootstrapped', () => this._schedulePaint());
    this.bus('entity:bootstrap-failed', () => this._schedulePaint());
    this.bus('entity:changed', () => this._schedulePaint());
    if (!E.isHydrated?.()) E.bootstrap?.().catch(() => this._schedulePaint());
    this.paint();
  }

  _schedulePaint() {
    if (this._renderScheduled) return;
    this._renderScheduled = true;
    requestAnimationFrame(() => { this._renderScheduled = false; this.paint(); });
  }

  paint() {
    if (!this._region) return;
    clear(this._region);
    const E = globalThis.Platform.Entities;
    const state = E.hydrationState?.() || { hydrated: E.isHydrated?.() };
    this._region.setAttribute('aria-busy', state.hydrated ? 'false' : 'true');
    if (!state.hydrated) {
      this._region.append(this._renderLoading(state));
      return;
    }

    const matrixModel = buildOperatorMatrix({ page: this._page, pageSize: this._pageSize, maxRows: MAX_RENDERED_ROWS });
    this._page = matrixModel.page;
    const kpiGrid = el('section', { class: 'hud-kpis' }, [
      this._mkKpi('total', matrixModel.totals.reference || 0, 'hud-kpi--info'),
      this._mkKpi('pending', matrixModel.totals.task || 0, 'hud-kpi--warn'),
      this._mkKpi('overdue', matrixModel.sla.counts.overdue || 0, 'hud-kpi--danger'),
      this._mkKpi('closed', matrixModel.closed || 0, 'hud-kpi--success')
    ]);
    const matrix = el('section', { class: 'hud-matrix pf-card' }, [
      el('div', { class: 'hud-matrix__hdr' }, [
        el('h2', { text: this.t('module.operator-hud.title') }),
        el('pf-identity-box')
      ]),
      this._renderTable(matrixModel)
    ]);
    this._region.append(kpiGrid, matrix);
  }

  _renderLoading(state) {
    return el('section', { class: 'pf-card pf-empty pf-empty--loading', role: 'status' }, [
      el('div', { class: 'pf-empty__title', text: state.lastError ? 'Unable to refresh HUD' : 'Loading operator HUD…' }),
      el('p', { class: 'pf-muted', text: state.lastError || 'Synchronising task health and SLA data.' })
    ]);
  }

  _mkKpi(key, val, toneClass) {
    return el('div', { class: `hud-kpi ${toneClass}` }, [
      el('div', { class: 'hud-kpi-lbl', text: this.t(`hud.kpi.${key}`) }),
      el('div', { class: 'hud-kpi-val', text: String(val) })
    ]);
  }

  _renderTable(model) {
    const tasks = model.tasks || [];
    if (!tasks.length) return el('div', { class: 'pf-empty', text: this.t('common.state.empty') });
    const total = model.total;
    const pageCount = model.pageCount;
    const start = model.start;
    const rows = model.rows;

    const controls = el('div', { class: 'pf-toolbar u-justify-between u-wrap u-gap-2' }, [
      el('span', { class: 'pf-muted u-text-sm', text: `${start + 1}-${Math.min(start + rows.length, total)} of ${total}` }),
      el('div', { class: 'u-flex u-items-center u-gap-2' }, [
        el('label', { class: 'pf-muted u-text-sm', text: 'Rows' }),
        this._pageSizeSelect(),
        el('button', { class: 'pf-btn pf-btn--ghost pf-btn--sm', type: 'button', text: 'Previous', disabled: this._page <= 1, onClick: () => { this._page--; this.paint(); } }),
        el('span', { class: 'pf-muted u-text-sm', text: `Page ${this._page} / ${pageCount}` }),
        el('button', { class: 'pf-btn pf-btn--ghost pf-btn--sm', type: 'button', text: 'Next', disabled: this._page >= pageCount, onClick: () => { this._page++; this.paint(); } })
      ])
    ]);

    const table = el('table', { class: 'pf-table' }, [
      el('thead', {}, [el('tr', {}, [
        el('th', { text: this.t('hud.matrix.id') }),
        el('th', { text: this.t('hud.matrix.subject') }),
        el('th', { text: this.t('field.assignedTo.label') }),
        el('th', { text: this.t('hud.matrix.health') }),
        el('th', { class: 'u-text-right', text: 'Action' })
      ])]),
      el('tbody', {}, rows.map(t => el('tr', { class: 'hud-row' }, [
        el('td', { class: 'font-mono u-fw-bold u-text-caption', text: t.id || t.__ref || t.__id || '—' }),
        el('td', { class: 'u-fw-semibold', text: t.title || t.subject || 'Untitled task' }),
        el('td', { text: t.assignedTo || 'Unassigned', class: 'pf-muted' }),
        el('td', {}, [renderSlaMeterNode(t)]),
        el('td', { class: 'u-text-right' }, [
          el('button', { class: 'pf-btn pf-btn--primary pf-btn--sm', text: 'Trace', onClick: () => globalThis.Platform.goToEntity(t.__ref, 'response-tracking') })
        ])
      ])))
    ]);
    return el('div', {}, [controls, el('div', { class: 'pf-table-wrap' }, [table])]);
  }

  _pageSizeSelect() {
    const select = el('select', { class: 'pf-input pf-input--sm', 'aria-label': 'Rows per page' },
      PAGE_SIZES.map(size => el('option', { value: String(size), selected: String(size) === String(this._pageSize), text: String(size) }))
    );
    this.on(select, 'change', () => { this._pageSize = Number(select.value) || DEFAULT_PAGE_SIZE; this._page = 1; this.paint(); });
    return select;
  }
}

Modules.register(OperatorHudModule);
export default OperatorHudModule;
