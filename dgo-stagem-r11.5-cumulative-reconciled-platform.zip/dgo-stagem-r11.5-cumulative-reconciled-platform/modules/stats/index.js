/** OBSIDIAN v4.0 — module 'stats' (Executive · AGGREGATOR · audience:executive).
 *  KPI tiles + by-status bar (shared mountAggregator) + status donut and 14-day activity
 *  sparkline (core/charts.js), all from Entities.counts(). No per-row fetch. */
import { BaseModule } from '../../core/base-module.js';
import { Modules } from '../../core/modules-registry.js';
import { mountAggregator } from '../../shared/utils/lens.js';
import { Charts } from '../../core/charts.js';
import { el, clear } from '../../shared/utils/dom.js';
import { buildSlaBoard } from '../../shared/domain/sla-projection.js';

class StatsModule extends BaseModule {
  static id = 'stats'; static label = 'module.stats.title'; static icon = 'trending-up';
  static nav = { group: 'CrossPhase', order: 4 }; static audience = 'executive'; static status = 'active';
  static base = new URL('.', import.meta.url);

  async onVisible(root) {
    const E = globalThis.Platform.Entities;
    if (!await this.ensureFabric(root)) return;
    this._root = root;
    mountAggregator(this, root, { tiles: [
      ['reference', 'response-tracking', 'table'], ['document', 'ops-hub', 'folder'],
      ['task', 'orchestrator', 'workflow'], ['email', 'correspondence', 'mail'],
      ['approval', 'approvals', 'check-circle'], ['comment', 'comments', 'message-square']
    ], table: null });
    this._charts();
    this.bus('entity:bootstrapped', () => this._charts());
    this.bus('entity:changed', () => this._charts());
  }

  _charts() {
    const region = (this._root && this._root.querySelector('[data-region="content"]')) || this._root;
    if (!region) return;
    let host = region.querySelector('#stats-charts');
    if (!host) { host = el('div', { id: 'stats-charts', class: 'pf-grid', style: 'margin-top:var(--space-6);gap:var(--space-6)' }); region.append(host); }
    clear(host);
    const E = globalThis.Platform.Entities;
    const c = E.counts();
    const timeline = this._timeline();
    const sla = buildSlaBoard([...(E.all('task') || []), ...(E.all('document') || [])]);
    const d = Charts.donut(c.byStatus, { label: this.t('charts.statusMix') });
    host.append(
      el('div', { class: 'pf-card', style: 'padding:var(--space-5)' }, [
        el('div', { class: 'pf-overline', text: this.t('charts.statusMix') }),
        el('div', { style: 'display:flex;gap:var(--space-5);align-items:center;margin-top:var(--space-3)' }, [d.svg, d.legend])
      ]),
      el('div', { class: 'pf-card', style: 'padding:var(--space-5)' }, [
        el('div', { class: 'pf-overline', text: this.t('charts.activity14d') }),
        el('div', { style: 'margin-top:var(--space-3)' }, [Charts.sparkline(timeline, { label: this.t('charts.activity14d') })])
      ]),
      el('div', { class: 'pf-card', style: 'padding:var(--space-5)' }, [
        el('div', { class: 'pf-overline', text: 'SLA projection' }),
        el('div', { class: 'pf-grid pf-grid--4', style: 'margin-top:var(--space-3)' }, [
          el('div', { class: 'pf-stat' }, [el('div', { class: 'pf-stat__label', text: 'Overdue' }), el('div', { class: 'pf-stat__value', text: String(sla.counts.overdue || 0) })]),
          el('div', { class: 'pf-stat' }, [el('div', { class: 'pf-stat__label', text: 'Due soon' }), el('div', { class: 'pf-stat__value', text: String(sla.counts.dueSoon || 0) })]),
          el('div', { class: 'pf-stat' }, [el('div', { class: 'pf-stat__label', text: 'On track' }), el('div', { class: 'pf-stat__value', text: String(sla.counts.onTrack || 0) })]),
          el('div', { class: 'pf-stat' }, [el('div', { class: 'pf-stat__label', text: 'Unknown' }), el('div', { class: 'pf-stat__value', text: String(sla.counts.unknown || 0) })])
        ])
      ])
    );
  }

  _timeline() {
    const E = globalThis.Platform.Entities;
    const rows = [...(E.all('task') || []), ...(E.all('document') || []), ...(E.all('email') || []), ...(E.all('reference') || [])];
    const days = [];
    const now = new Date();
    for (let i = 13; i >= 0; i--) {
      const d = new Date(now); d.setDate(now.getDate() - i);
      const key = d.toISOString().slice(0, 10);
      days.push({ label: key.slice(5), value: 0, key });
    }
    const byKey = new Map(days.map((d) => [d.key, d]));
    rows.forEach((r) => {
      const raw = r.ts || r.createdAt || r.Created || r.modifiedAt || r.date || r.Date;
      const dt = raw ? new Date(raw) : null;
      if (!dt || Number.isNaN(dt.getTime())) return;
      const key = dt.toISOString().slice(0, 10);
      if (byKey.has(key)) byKey.get(key).value++;
    });
    return days;
  }
}
Modules.register(StatsModule);
export default StatsModule;
