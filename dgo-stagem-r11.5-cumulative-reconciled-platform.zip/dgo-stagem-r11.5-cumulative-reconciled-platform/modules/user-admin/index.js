/** Stage M-R10.4 — User Administration module with UI RBAC role assignment. */
import { BaseModule } from '../../core/base-module.js';
import { Modules } from '../../core/modules-registry.js';
import { el, clear } from '../../shared/utils/dom.js';
import { PERMISSIONS } from '../../config/rbac.config.js';
import { UserAdminService } from './service.js';

class UserAdminModule extends BaseModule {
  static id = 'user-admin';
  static label = 'module.user-admin.title';
  static icon = 'users';
  static nav = { group: 'System', order: 1 };
  static audience = 'admin';
  static requiredPermission = PERMISSIONS.USER_VIEW;
  static status = 'active';
  static base = new URL('.', import.meta.url);

  async onVisible(root) {
    this._root = root.querySelector('[data-region="content"]') || root;
    this._editing = null;
    this.paint();
    this.bus('admin:users:changed', () => this.paint());
  }

  paint() {
    const P = globalThis.Platform;
    clear(this._root);
    if (!P.Persona.hasPermission(PERMISSIONS.USER_VIEW)) {
      this._root.append(el('div', { class: 'pf-card ua-card' }, [
        el('h2', { text: 'Access restricted' }),
        el('p', { class: 'pf-muted', text: 'Your current role does not include user-administration access.' })
      ]));
      return;
    }
    this._root.append(el('div', { class: 'ua-grid' }, [this._form(), this._table()]), this._rolesPanel());
  }

  _form(user = {}) {
    const P = globalThis.Platform;
    const canWrite = P.Persona.hasPermission(PERMISSIONS.USER_CREATE) || P.Persona.hasPermission(PERMISSIONS.USER_UPDATE);
    const roles = P.RBAC.roles();
    const name = el('input', { id:'ua-name', value:user.fullName || '', placeholder:'Full name' });
    const email = el('input', { id:'ua-email', value:user.email || '', placeholder:'name@example.gov.ng', type:'email' });
    const directorate = el('input', { id:'ua-directorate', value:user.directorate || '', placeholder:'Directorate / DSU key' });
    const role = el('select', { id:'ua-role' }, roles.map((r) => el('option', { value:r.id, text:r.label })));
    role.value = user.role || 'operator';
    const status = el('select', { id:'ua-status' }, [el('option',{value:'active',text:'Active'}), el('option',{value:'disabled',text:'Disabled'})]);
    status.value = user.status || 'active';
    const save = el('button', { class:'dgo-btn dgo-btn--primary', type:'button', text: user.id ? 'Update user' : 'Create user', disabled: canWrite ? null : 'disabled' });
    this.on(save, 'click', () => {
      const payload = { id:user.id, fullName:name.value, email:email.value, directorate:directorate.value, role:role.value, status:status.value, createdAt:user.createdAt };
      if (!payload.email || !payload.email.includes('@')) { P.UI.toast({message:'Enter a valid email address.', variant:'danger'}); email.focus(); return; }
      if (!payload.fullName.trim()) { P.UI.toast({message:'Enter the user full name.', variant:'danger'}); name.focus(); return; }
      if (!P.Persona.hasPermission(user.id ? PERMISSIONS.USER_UPDATE : PERMISSIONS.USER_CREATE)) { P.UI.toast({message:'Your role cannot save users.', variant:'warning'}); return; }
      UserAdminService.upsert(payload);
      P.UI.toast({message:`Saved ${payload.email}`, variant:'success'});
      this.paint();
    });
    const reset = el('button', { class:'dgo-btn dgo-btn--secondary', type:'button', text:'Clear form' });
    this.on(reset, 'click', () => { this._editing = null; this.paint(); });
    return el('section', { class:'ua-card' }, [
      el('div', { class:'pf-overline', text:'User profile' }),
      el('p', { class:'pf-muted', text:'Create and maintain user identity, directorate, status and role assignment.' }),
      el('div', { class:'ua-form' }, [
        this._field('Full name', name), this._field('Email', email), this._field('Directorate / DSU', directorate), this._field('Role', role), this._field('Status', status),
        el('div', { class:'ua-actions' }, [save, reset])
      ])
    ]);
  }

  _field(label, control) { return el('div', { class:'ua-field' }, [el('label', { text:label }), control]); }

  _table() {
    const P = globalThis.Platform;
    const users = UserAdminService.list();
    const body = el('tbody', {});
    users.forEach((u) => {
      const edit = el('button', { class:'dgo-btn dgo-btn--secondary dgo-btn--sm', type:'button', text:'Edit' });
      this.on(edit, 'click', () => { this._root.innerHTML=''; this._root.append(el('div', { class:'ua-grid' }, [this._form(u), this._table()]), this._rolesPanel()); });
      const disable = el('button', { class:'dgo-btn dgo-btn--danger dgo-btn--sm', type:'button', text:'Disable', disabled: P.Persona.hasPermission(PERMISSIONS.USER_DISABLE) && u.status !== 'disabled' ? null : 'disabled' });
      this.on(disable, 'click', () => { UserAdminService.disable(u.email); P.UI.toast({message:`Disabled ${u.email}`, variant:'warning'}); this.paint(); });
      body.append(el('tr', {}, [
        el('td', { text:u.fullName || '—' }),
        el('td', { text:u.email }),
        el('td', { text:u.directorate || '—' }),
        el('td', {}, [el('span', { class:'ua-role', text:P.RBAC.roles().find((r)=>r.id===u.role)?.label || u.role })]),
        el('td', {}, [el('span', { class:'ua-status ' + u.status, text:u.status })]),
        el('td', {}, [el('div', { class:'ua-actions' }, [edit, disable])])
      ]));
    });
    if (!users.length) body.append(el('tr', {}, [el('td', { colspan:'6', text:'No users have been configured yet.' })]));
    return el('section', { class:'ua-card' }, [
      el('div', { class:'pf-overline', text:'Users and assignments' }),
      el('div', { class:'ua-table-wrap' }, [el('table', {}, [
        el('thead', {}, [el('tr', {}, ['Name','Email','Directorate','Role','Status','Actions'].map((h)=>el('th',{text:h})))]), body
      ])])
    ]);
  }

  _rolesPanel() {
    const P = globalThis.Platform;
    return el('section', { class:'ua-card' }, [
      el('div', { class:'pf-overline', text:'Role capability matrix' }),
      el('p', { class:'pf-muted', text:'Role permissions are applied to navigation, module visibility and sensitive controls.' }),
      ...P.RBAC.roles().map((role) => el('details', { class:'ua-role-detail' }, [
        el('summary', {}, [el('strong', { text:role.label }), document.createTextNode(` · ${role.permissions.length} permission(s)`)]),
        el('div', { class:'ua-permission-grid' }, role.permissions.length ? role.permissions.map((p)=>el('span',{class:'ua-permission',text:p})) : [el('span',{class:'ua-permission',text:'read-only / no elevated permissions'})])
      ]))
    ]);
  }
}
Modules.register(UserAdminModule);
export default UserAdminModule;
