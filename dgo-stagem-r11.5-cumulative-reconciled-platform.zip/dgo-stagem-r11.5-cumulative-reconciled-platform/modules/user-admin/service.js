/** Stage M-R10.4 — User Administration service facade. */
export const UserAdminService = {
  list() { return globalThis.Platform?.RBAC?.users?.() || []; },
  upsert(user) { return globalThis.Platform?.RBAC?.upsertUser?.(user); },
  disable(email) { return globalThis.Platform?.RBAC?.disableUser?.(email); }
};
export default UserAdminService;
