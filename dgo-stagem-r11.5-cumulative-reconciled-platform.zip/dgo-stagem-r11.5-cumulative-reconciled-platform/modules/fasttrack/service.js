/** Compatibility service surface: retained for legacy imports and diagnostics; the active FastTrack board reads the hydrated entity fabric. */
/** Service for 'fasttrack' — @see Endpoints#SUBSIDIARY_ACTIONS */
import { BaseService } from '../../core/base-service.js';
export const fetchData = BaseService.endpoint('SUBSIDIARY_ACTIONS', { cache:15000, expectedKeys:['success','data'] });
export const serviceDescriptor = Object.freeze({ moduleId: 'fasttrack', role: 'sla-lens', serviceMode: 'read', endpoints: Object.freeze(['SUBSIDIARY_ACTIONS']) });
