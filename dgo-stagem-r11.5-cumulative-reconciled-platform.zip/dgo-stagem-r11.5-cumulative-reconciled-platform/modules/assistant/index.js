/** OBSIDIAN v4.0 — module 'assistant' (Operations · ACTION · audience:all).
 *  Live AI assistant over AI_CHAT (shared/utils/ai.js). Conversation state is held per session;
 *  each turn sends the full history to the flow and renders the reply. No placeholder content.
 *  Remediation: guarded composer prevents duplicate concurrent AI sends and always restores UI state. */
import { BaseModule } from '../../core/base-module.js';
import { Modules } from '../../core/modules-registry.js';
import { el, clear } from '../../shared/utils/dom.js';
import { AI } from '../../shared/utils/ai.js';

class AssistantModule extends BaseModule {
  static id = 'assistant'; static label = 'module.assistant.title'; static icon = 'message-circle';
  static nav = { group: 'CrossPhase', order: 6 }; static audience = 'all'; static status = 'active';
  static base = new URL('.', import.meta.url);

  async onVisible(root) {
    this._messages = this._messages || [];
    this._sending = false;
    this._sendSeq = this._sendSeq || 0;
    this._log = root.querySelector('[data-region="log"]');
    this._composer = root.querySelector('[data-region="composer"]');
    const form = this._composer;
    if (!form) return;
    clear(form);
    this._input = el('textarea', { class: 'pf-asst__input', rows: '2', 'aria-label': this.t('assistant.inputAria'),
      placeholder: this.t('assistant.placeholder') });
    this._sendBtn = el('button', { class: 'pf-btn pf-btn--primary', type: 'button', text: this.t('assistant.send') });
    this.on(this._sendBtn, 'click', () => this._send());
    this.on(this._input, 'keydown', (e) => {
      if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) { e.preventDefault(); this._send(); }
    });
    form.append(this._input, this._sendBtn);
    this._setBusy(false);
    this._paint();
  }

  onHidden() { this._sendSeq++; this._setBusy(false); }
  onUnmount() { this._sendSeq++; this._setBusy(false); }

  _setBusy(isBusy) {
    this._sending = !!isBusy;
    if (this._sendBtn) {
      this._sendBtn.disabled = !!isBusy;
      this._sendBtn.setAttribute('aria-busy', isBusy ? 'true' : 'false');
    }
    if (this._input) this._input.disabled = !!isBusy;
    if (this._composer) this._composer.setAttribute('aria-busy', isBusy ? 'true' : 'false');
  }

  _paint() {
    if (!this._log) return;
    clear(this._log);
    if (!this._messages.length) {
      this._log.append(el('p', { class: 'pf-muted pf-asst__empty', text: this.t('assistant.empty') }));
      return;
    }
    this._messages.forEach((m) => {
      this._log.append(el('div', { class: 'pf-asst__msg pf-asst__msg--' + (m.role === 'user' ? 'user' : 'ai') }, [
        el('span', { class: 'pf-asst__role', text: this.t(m.role === 'user' ? 'assistant.you' : 'assistant.ai') }),
        el('div', { class: 'pf-asst__body', text: m.content })
      ]));
    });
    this._log.scrollTop = this._log.scrollHeight;
  }

  async _send() {
    if (this._sending) return;
    const text = (this._input?.value || '').trim();
    if (!text) return;
    const seq = ++this._sendSeq;
    this._setBusy(true);
    this._messages.push({ role: 'user', content: text });
    this._input.value = '';
    this._paint();

    const P = globalThis.Platform || {};
    const routing = (P.Directory && typeof P.Directory.parsePrompt === 'function') ? P.Directory.parsePrompt(text) : [];
    if (routing.length) this._renderRouting(routing);
    const pending = el('div', { class: 'pf-asst__msg pf-asst__msg--ai pf-asst__pending', role: 'status', text: this.t('assistant.thinking') });
    this._log?.append(pending);
    if (this._log) this._log.scrollTop = this._log.scrollHeight;

    const scope = {
      directorate: (P.Context && P.Context.directorate && P.Context.directorate()) || 'all',
      persona: (P.Persona && P.Persona.current && P.Persona.current()) || null,
      userEmail: (P.Persona && P.Persona.email && P.Persona.email()) || null
    };

    try {
      const res = await this.call(() => AI.chat([...this._messages], { scope, ...scope, ...(routing.length ? { routing } : {}) }));
      if (seq !== this._sendSeq) return;
      pending.remove();
      const reply = res.ok ? (AI.summaryOf(res) || this.t('assistant.noReply')) : this.t('assistant.failed');
      this._messages.push({ role: 'assistant', content: reply });
      this._paint();
      if (routing.length) this._renderRouting(routing);
    } catch (err) {
      if (seq !== this._sendSeq) return;
      pending.remove();
      this._messages.push({ role: 'assistant', content: this.t('assistant.failed') });
      this._paint();
      P.Log?.warn?.('assistant.send-failed', { message: String(err && err.message || err) });
    } finally {
      if (seq === this._sendSeq) this._setBusy(false);
    }
  }

  /** Render parsed routing targets as an ordered chip row in the workspace. */
  _renderRouting(routing) {
    if (!this._log || !routing || !routing.length) return;
    const row = el('div', { class: 'pf-asst__routing' }, [
      el('span', { class: 'pf-overline', text: this.t('assistant.routingDetected') }),
      ...routing.map((r) => el('span', {
        class: 'pf-badge pf-badge--routed pf-asst__route',
        title: r.recipientAddress || '',
        text: `${r.sequence}. ${r.key}${r.recipientAddress ? ' → ' + r.recipientAddress : ''}`
      }))
    ]);
    this._log.append(row);
    this._log.scrollTop = this._log.scrollHeight;
  }
}
Modules.register(AssistantModule);
export default AssistantModule;
