/** OBSIDIAN v4.0 — module 'reports' (Executive · AGGREGATOR · audience:executive).
 *  KPI tiles + reference CSV table and a formatted NITDA Management Report with safe export feedback. */
import { BaseModule } from '../../core/base-module.js';
import { Modules } from '../../core/modules-registry.js';
import { mountAggregator } from '../../shared/utils/lens.js';
import { el } from '../../shared/utils/dom.js';
import { safeExport } from '../../shared/utils/safe-export.js';
import { API } from '../../core/api.js';
import { buildReportSummary } from '../../shared/domain/rollups.js';
import { buildExecutiveResponseMatrix } from '../../shared/domain/response-matrix.js';

class ReportsModule extends BaseModule {
  static id = 'reports'; static label = 'module.reports.title'; static icon = 'file-text';
  static nav = { group: 'CrossPhase', order: 5 }; static audience = 'executive'; static status = 'active';
  static base = new URL('.', import.meta.url);

  async onVisible(root) {
    if (!await this.ensureFabric(root)) return;
    mountAggregator(this, root, {
      tiles: [['reference', 'response-tracking', 'table'], ['document', 'ops-hub', 'folder'], ['task', 'orchestrator', 'workflow'], ['email', 'correspondence', 'mail'], ['approval', 'approvals', 'check-circle']]
    });
    this._mgmtReport(root);
  }

  _mgmtReport(root) {
    const P = globalThis.Platform;
    const summary = buildReportSummary();
    const c = summary.counts;
    const region = root.querySelector('[data-region="content"]') || root;
    const old = region.querySelector('#reports-mgmt');
    if (old) old.remove();

    const total = summary.totalActivities;
    const completed = summary.completed;
    const pendingAppr = summary.pendingApprovals;
    const overdue = summary.overdue;
    const reportTitle = this.t('reports.mgmtTitle') || 'NITDA Management Report';
    const recovery = API.Outbox.metrics ? API.Outbox.metrics() : { queued: API.Outbox.get().length, dueNow: 0, dead: API.Outbox.getDead().length, maxAttempts: 8 };
    const responseMatrix = buildExecutiveResponseMatrix({ api: API });
    const minuteCount = responseMatrix.rows.reduce((total, row) => total + (row.counts.minutes || 0), 0);

    const stat = (label, value) => el('div', { class: 'pf-stat' }, [
      el('div', { class: 'pf-stat__label', text: this.t(label) }),
      el('div', { class: 'pf-stat__value', text: String(value || 0) })
    ]);
    const section = (titleKey, body) => el('div', { class: 'u-mt-5' }, [
      el('div', { class: 'pf-overline', text: this.t(titleKey) }), body
    ]);
    const para = (text) => el('p', { class: 'pf-muted u-mt-2', text });

    const report = el('section', { id: 'reports-mgmt', class: 'pf-card u-mt-6 u-pad-6' }, [
      el('div', { class: 'pf-view__head u-pb-3' }, [
        el('h2', { text: reportTitle }),
        el('div', { class: 'pf-toolbar' }, [
          el('button', { class: 'pf-btn pf-btn--ghost', type: 'button', id: 'rep-print', onClick: () => this._printReport(total) }, [el('pf-icon', { name: 'printer', size: '14' }), document.createTextNode(' ' + this.t('reports.print'))]),
          el('button', { class: 'pf-btn pf-btn--ghost', type: 'button', id: 'rep-html', onClick: () => this._downloadHtml(reportTitle, total) }, [el('pf-icon', { name: 'download', size: '14' }), document.createTextNode(' ' + this.t('reports.downloadHtml'))]),
          el('button', { class: 'pf-btn pf-btn--primary', type: 'button', id: 'rep-email', onClick: () => this._sendEmail(reportTitle) }, [el('pf-icon', { name: 'mail', size: '14' }), document.createTextNode(' ' + this.t('reports.sendEmail'))])
        ])
      ]),
      el('div', { class: 'pf-grid pf-grid--4' }, [
        stat('reports.totalActivities', total), stat('reports.completed', completed), stat('reports.pendingApprovals', pendingAppr), stat('reports.overdue', overdue)
      ]),
      section('reports.keyInsights', para(`Current visible workload is ${total}. ${overdue} item(s) are overdue and ${pendingAppr} item(s) are awaiting review.`)),
      section('reports.activitySummary', para(`References: ${summary.activitySummary.references || 0}; documents: ${summary.activitySummary.documents || 0}; tasks: ${summary.activitySummary.tasks || 0}; emails: ${summary.activitySummary.emails || 0}; approvals: ${summary.activitySummary.approvals || 0}.`)),
      section('Governance Recovery', para(`Minute ledger entries: ${minuteCount}. Queued writes: ${recovery.queued}; due writes: ${recovery.dueNow}; dead letters: ${recovery.dead}; max retry attempts: ${recovery.maxAttempts}.`)),
      section('Executive Response Matrix', para(`Matrix references: ${responseMatrix.totalReferences}; overdue references: ${responseMatrix.overdueReferences}; pending review references: ${responseMatrix.pendingReviewReferences}; dead letters: ${responseMatrix.deadLetterCount}.`)),
      section('reports.conclusion', para(overdue || recovery.dead ? 'Immediate attention is required for overdue operational items or failed workflow deliveries.' : 'No overdue operational items or failed local workflow deliveries are currently visible in this scope.'))
    ]);
    region.append(report);
  }

  _printReport(total) {
    return safeExport({
      type: 'print', filename: 'management-report', hasData: total > 0,
      emptyMessage: 'There is no report data to print.',
      failureMessage: 'Report print failed. Please try again or use HTML download.',
      action: () => { if (typeof globalThis.print !== 'function') throw new Error('print unavailable'); globalThis.print(); }
    });
  }

  _downloadHtml(title, total) {
    return safeExport({
      type: 'html', filename: 'nitda-management-report.html', hasData: total > 0,
      emptyMessage: 'There is no report data to download.',
      failureMessage: 'HTML report download failed. Please try again or use CSV export.',
      action: () => globalThis.Platform.Format.downloadHtml('nitda-management-report.html', this._html(title))
    });
  }

  _sendEmail(title) {
    const P = globalThis.Platform;
    if (P.Actions && P.Actions.run) {
      return P.Actions.run('dispatchEmail', { email: { subject: title, bodyHtml: this._html(title) }, kind: 'management-report' });
    }
    P.UI.toast({ message: 'Report email dispatch is unavailable.', variant: 'danger' });
    return { ok: false };
  }

  _html(title) {
    const section = document.getElementById('reports-mgmt');
    const safeTitle = String(title || 'NITDA Management Report').replace(/[<>&"']/g, (ch) => ({ '<':'&lt;', '>':'&gt;', '&':'&amp;', '"':'&quot;', "'":'&#39;' }[ch]));
    const body = section ? this._serializeReportSection(section) : '';
    return `<!doctype html><html><head><meta charset="utf-8"><title>${safeTitle}</title></head><body>${body}</body></html>`;
  }

  _serializeReportSection(section) {
    const clone = section.cloneNode(true);
    clone.querySelectorAll('button, .pf-toolbar').forEach((node) => node.remove());
    if (typeof XMLSerializer === 'function') return new XMLSerializer().serializeToString(clone);
    const pre = document.createElement('pre');
    pre.textContent = clone.textContent || '';
    return new XMLSerializer().serializeToString(pre);
  }

  _countMinuteLedgerEntries() {
    let total = 0;
    try {
      for (let i = 0; i < (localStorage?.length || 0); i++) {
        const k = localStorage.key(i) || '';
        if (!k.includes('minutes.')) continue;
        const parsed = JSON.parse(localStorage.getItem(k) || '[]');
        if (Array.isArray(parsed)) total += parsed.length;
      }
    } catch (_) {}
    return total;
  }
}
Modules.register(ReportsModule);
export default ReportsModule;
