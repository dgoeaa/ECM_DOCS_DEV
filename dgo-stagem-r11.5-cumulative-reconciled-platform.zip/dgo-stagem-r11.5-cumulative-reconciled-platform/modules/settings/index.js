/**
 * OBSIDIAN v4.2 — Administrative Control Chamber
 * Remediated: Live locale toggle and mock environmental authorization controls.
 */
import { BaseModule } from '../../core/base-module.js';
import { Modules } from '../../core/modules-registry.js';
import { Endpoints } from '../../config/endpoints.config.js';
import { FeatureFlags } from '../../config/feature-flags.config.js';
import { API } from '../../core/api.js';
import { el, clear } from '../../shared/utils/dom.js';

const LS_PREFIX = 'obsidian.endpoint.';
const VALID_URL = /^https?:\/\/[^\s"'<>]+$/;
const ENDPOINT_OVERRIDES_ENABLED = FeatureFlags.endpointOverrides === true;

class SettingsModule extends BaseModule {
  static id = 'settings';
  static label = 'module.settings.title';
  static icon = 'settings';
  static nav = { group: 'System', order: 2 };
  static audience = 'admin';
  static status = 'active';
  static base = new URL('.', import.meta.url);

  async onVisible(root) {
    const region = root.querySelector('[data-region="content"]') || root;
    clear(region);

    const explainer = el('p', { class: 'pf-muted', style: 'margin-bottom:20px;line-height:1.5;',
      text: this.t('settings.endpointsExplainer') });
    const resetAllBtn = el('button', { class: 'dgo-btn dgo-btn--danger', type: 'button',
      text: `🔄 ${this.t('settings.resetAll')}` });
    resetAllBtn.addEventListener('click', () => this._resetAll(region));

    const toolbar = el('div', { class: 'pf-toolbar', style: 'margin-bottom:16px;display:flex;align-items:center;justify-content:space-between;width:100%;' }, [
      el('span', { class: 'pf-overline', text: this.t('settings.endpoints') }),
      resetAllBtn
    ]);

    // Endpoint list
    const list = el('div', { class: 'pf-settings__list', style: 'display:flex;flex-direction:column;gap:12px;' });
    const entries = Object.entries(Endpoints || {});
    let activeOverrides = 0;
    entries.forEach(([key, ep]) => {
      if (!ep.url) return;
      const overrideVal = ENDPOINT_OVERRIDES_ENABLED ? this._getOverride(key) : '';
      if (overrideVal) activeOverrides++;
      list.append(this._renderEndpointRow(key, ep, overrideVal));
    });

    const summary = el('div', { class: 'pf-card', style: 'padding:16px;margin-bottom:20px;background:var(--dgo-color-surface-sunken);border:1px solid var(--dgo-color-border-default);border-radius:10px;' }, [
      el('div', { style: 'display:flex;gap:16px;font-size:14px;' }, [
        el('span', {}, [el('strong', { text: String(entries.filter(([_, e]) => e.url).length) }), document.createTextNode(' ' + this.t('settings.totalEndpoints'))]),
        el('span', {}, [el('strong', { text: String(activeOverrides) }), document.createTextNode(' ' + this.t('settings.activeOverrides'))])
      ])
    ]);

    // Language switcher section
    const langSection = el('section', { class: 'pf-card', style: 'padding:16px;margin-bottom:20px;background:var(--dgo-color-surface-sunken);border:1px solid var(--dgo-color-border-default);border-radius:10px;' });
    langSection.append(el('div', { class: 'pf-overline', style: 'margin-bottom:8px;', text: this.t('settings.language') }));
    langSection.append(el('p', { class: 'pf-muted', style: 'font-size:13px;margin-bottom:12px;', text: this.t('settings.languageBlurb') }));
    const I = globalThis.Platform.I18n;
    const langs = [
      { code: 'en', label: 'English' },
      { code: 'fr', label: 'Français' },
      { code: 'ha', label: 'Hausa' }
    ];
    const langChips = el('div', { class: 'pf-chipgroup', role: 'radiogroup' });
    langs.forEach((l) => {
      const b = el('button', { type: 'button',
        class: 'pf-chip' + (I.locale() === l.code ? ' pf-chip--selected' : ''),
        text: l.label, 'data-lang': l.code });
      b.addEventListener('click', async () => {
        if (I.locale() === l.code) return;
        await I.switch(l.code);
        this.onVisible(root);
      });
      langChips.append(b);
    });
    langSection.append(langChips);
    const governanceSection = this._renderGovernanceRecoverySection(root);
    const performanceSection = this._renderPerformanceSection();
    region.append(langSection, governanceSection, performanceSection, explainer, summary, toolbar, list);
  }



  _renderPerformanceSection() {
    const metrics = globalThis.Platform?.Performance?.metrics?.() || { api:{}, ui:{}, entity:{} };
    const cache = globalThis.Platform?.API?.cacheStats?.() || {};
    const section = el('section', { class: 'pf-card', style: 'padding:16px;margin-bottom:20px;background:var(--dgo-color-surface-sunken);border:1px solid var(--dgo-color-border-default);border-radius:10px;' });
    section.append(el('div', { class:'pf-overline', style:'margin-bottom:8px;', text:'Performance' }));
    section.append(el('p', { class:'pf-muted', style:'font-size:13px;margin-bottom:12px;', text:'Live UI and frontend/backend operation metrics for cache, request and render behaviour.' }));
    section.append(el('div', { class:'pf-grid', style:'margin-bottom:12px;' }, [
      this._governanceTile('API calls', metrics.api.total || 0),
      this._governanceTile('Cache hits', metrics.api.cacheHits || 0),
      this._governanceTile('In-flight joins', metrics.api.inflightHits || 0),
      this._governanceTile('Read cache entries', cache.readCacheEntries || 0),
      this._governanceTile('Snapshot hits', metrics.entity.snapshotHits || 0),
      this._governanceTile('Counts hits', metrics.entity.countsHits || 0)
    ]));
    const clearCache = el('button', { type:'button', class:'dgo-btn dgo-btn--secondary', text:'Clear API read cache' });
    clearCache.addEventListener('click', () => { globalThis.Platform?.API?.clearReadCache?.(); globalThis.Platform.UI.toast({ message:'API read cache cleared.', variant:'info' }); });
    section.append(el('div', { class:'pf-toolbar' }, [clearCache]));
    return section;
  }

  _renderGovernanceRecoverySection(root) {
    const metrics = API.Outbox.metrics ? API.Outbox.metrics() : { queued: API.Outbox.get().length, dueNow: 0, dead: API.Outbox.getDead().length, maxAttempts: 8 };
    const section = el('section', { class: 'pf-card', style: 'padding:16px;margin-bottom:20px;background:var(--dgo-color-surface-sunken);border:1px solid var(--dgo-color-border-default);border-radius:10px;' });
    section.append(el('div', { class: 'pf-overline', style: 'margin-bottom:8px;', text: 'Governance & Recovery' }));
    section.append(el('p', { class: 'pf-muted', style: 'font-size:13px;margin-bottom:12px;', text: 'Monitor local write recovery, retry dead-lettered workflow transactions, and keep embedded endpoint governance visible to operators.' }));
    const stats = el('div', { class: 'pf-grid', style: 'margin-bottom:12px;' }, [
      this._governanceTile('Queued writes', metrics.queued),
      this._governanceTile('Due now', metrics.dueNow),
      this._governanceTile('Dead letters', metrics.dead),
      this._governanceTile('Max attempts', metrics.maxAttempts)
    ]);
    const retryBtn = el('button', { type: 'button', class: 'dgo-btn dgo-btn--primary', text: 'Retry dead letters', disabled: metrics.dead ? null : 'disabled' });
    const discardBtn = el('button', { type: 'button', class: 'dgo-btn dgo-btn--danger', text: 'Discard dead letters', disabled: metrics.dead ? null : 'disabled' });
    const processBtn = el('button', { type: 'button', class: 'dgo-btn dgo-btn--secondary', text: 'Process queue', disabled: metrics.queued ? null : 'disabled' });
    retryBtn.addEventListener('click', () => {
      const res = API.Outbox.retryDead();
      globalThis.Platform.UI.toast({ message: `Moved ${res.moved || 0} dead-letter item(s) back to the queue.`, variant: 'success' });
      this.onVisible(root);
    });
    discardBtn.addEventListener('click', async () => {
      if (!ENDPOINT_OVERRIDES_ENABLED) {
      globalThis.Platform.UI.toast({ message: 'Endpoint overrides are disabled for this build.', variant: 'info' });
      return;
    }
    const ok = await globalThis.Platform.UI.confirm({ title: 'Discard dead letters', summary: 'Remove all failed local write transactions from this browser?', danger: true });
      if (!ok) return;
      const res = API.Outbox.discardDead();
      globalThis.Platform.UI.toast({ message: `Discarded ${res.removed || 0} dead-letter item(s).`, variant: 'info' });
      this.onVisible(root);
    });
    processBtn.addEventListener('click', async () => {
      await API.Outbox.process();
      globalThis.Platform.UI.toast({ message: 'Outbox processing completed.', variant: 'info' });
      this.onVisible(root);
    });
    section.append(stats, el('div', { class: 'pf-toolbar' }, [retryBtn, discardBtn, processBtn]));
    return section;
  }

  _governanceTile(label, value) {
    return el('div', { class: 'pf-stat' }, [
      el('div', { class: 'pf-stat__label', text: label }),
      el('div', { class: 'pf-stat__value', text: String(value) })
    ]);
  }

  _renderEndpointRow(key, ep, currentOverride) {
    const row = el('div', { class: 'pf-settings__row pf-card', style: 'padding:16px;margin-bottom:12px;background:var(--dgo-color-surface-raised);border:1px solid var(--dgo-color-border-default);border-radius:10px;' });
    const head = el('div', { class: 'pf-settings__row-head', style: 'font-weight:700;font-size:14px;display:flex;align-items:center;gap:8px;' }, [
      el('strong', { text: key }),
      el('span', { class: 'pf-muted', text: ` · ${ep.flowName || ''}`, style: 'font-weight:400;color:var(--dgo-color-fg-muted);' }),
      currentOverride ? el('span', { class: 'pf-badge pf-badge--pending', text: this.t('settings.overrideActive'), style: 'background:var(--dgo-color-status-pending-bg);color:var(--dgo-color-status-pending-fg);padding:2px 8px;border-radius:10px;font-size:10px;' }) : null
    ].filter(Boolean));
    const def = el('div', { class: 'pf-settings__row-default', style: 'font-size:12px;margin:8px 0;' }, [
      el('span', { class: 'pf-overline', text: this.t('settings.defaultUrl'), style: 'display:block;margin-bottom:4px;' }),
      el('code', { class: 'pf-settings__url', text: this._redactedUrl(ep.url), style: 'display:block;padding:8px;background:var(--dgo-color-surface-sunken);border-radius:6px;font-family:var(--dgo-family-mono);word-break:break-all;' })
    ]);

    const inputId = `settings-${key}`;
    const input = el('input', { id: inputId, class: 'pf-input dgo-input', type: 'url',
      placeholder: ENDPOINT_OVERRIDES_ENABLED ? this.t('settings.overridePlaceholder') : 'Endpoint overrides disabled in this build',
      value: currentOverride || '', disabled: ENDPOINT_OVERRIDES_ENABLED ? null : 'disabled', style: 'width:100%;margin-bottom:8px;' });
    const errorSlot = el('p', { class: 'pf-field__error', hidden: true });

    const saveBtn = el('button', { class: 'dgo-btn dgo-btn--primary dgo-btn--sm', type: 'button',
      text: this.t('settings.save'), disabled: ENDPOINT_OVERRIDES_ENABLED ? null : 'disabled' });
    const clearBtn = el('button', { class: 'dgo-btn dgo-btn--secondary dgo-btn--sm', type: 'button',
      text: this.t('settings.clear'),
      disabled: (ENDPOINT_OVERRIDES_ENABLED && currentOverride) ? null : 'disabled' });

    saveBtn.addEventListener('click', () => {
      if (!ENDPOINT_OVERRIDES_ENABLED) {
        globalThis.Platform.UI.toast({ message: 'Endpoint overrides are disabled for this build.', variant: 'warning' });
        return;
      }
      errorSlot.hidden = true;
      const v = (input.value || '').trim();
      if (!v) { this._clearOverride(key); this._refreshRow(row, key, ep); return; }
      if (!VALID_URL.test(v)) {
        errorSlot.textContent = this.t('settings.invalidUrl'); errorSlot.hidden = false;
        input.focus(); return;
      }
      this._setOverride(key, v);
      this._refreshRow(row, key, ep);
      globalThis.Platform.UI.toast({ messageKey: 'settings.saved', vars: { key }, variant: 'success' });
    });
    clearBtn.addEventListener('click', () => {
      if (!ENDPOINT_OVERRIDES_ENABLED) return;
      this._clearOverride(key); input.value = '';
      this._refreshRow(row, key, ep);
      globalThis.Platform.UI.toast({ messageKey: 'settings.cleared', vars: { key }, variant: 'info' });
    });

    const controls = el('div', { class: 'pf-settings__row-controls' }, [
      el('div', { class: 'pf-field', style: 'flex:1' }, [
        el('label', { class: 'pf-label', for: inputId, text: this.t('settings.override') }),
        input, errorSlot
      ]),
      el('div', { class: 'pf-settings__row-actions', style: 'display:flex;gap:8px;margin-top:8px;' }, [saveBtn, clearBtn])
    ]);

    row.append(head, def, controls);
    return row;
  }

  _refreshRow(row, key, ep) {
    const replacement = this._renderEndpointRow(key, ep, this._getOverride(key));
    row.replaceWith(replacement);
  }

  _getOverride(key) {
    if (!ENDPOINT_OVERRIDES_ENABLED) return '';
    try { return (globalThis.localStorage && localStorage.getItem(LS_PREFIX + key)) || ''; }
    catch (_) { return ''; }
  }
  _setOverride(key, value) {
    if (!ENDPOINT_OVERRIDES_ENABLED) return;
    try { localStorage.setItem(LS_PREFIX + key, value); globalThis.Platform?.Bus?.emit?.('audit:endpoint-override-set', { endpointKey: key, ts: new Date().toISOString() }); }
    catch (_) { /* private browsing — silently fail */ }
  }
  _clearOverride(key) {
    if (!ENDPOINT_OVERRIDES_ENABLED) return;
    try { localStorage.removeItem(LS_PREFIX + key); globalThis.Platform?.Bus?.emit?.('audit:endpoint-override-cleared', { endpointKey: key, ts: new Date().toISOString() }); }
    catch (_) {}
  }

  async _resetAll(region) {
    if (!ENDPOINT_OVERRIDES_ENABLED) {
      globalThis.Platform.UI.toast({ message: 'Endpoint overrides are disabled for this build.', variant: 'info' });
      return;
    }
    const ok = await globalThis.Platform.UI.confirm({
      titleKey: 'settings.resetAll', summaryKey: 'settings.resetAllWarn',
      confirmKey: 'settings.resetAll', danger: true,
      details: [{ label: this.t('confirm.impact'), value: this.t('settings.resetAllImpact') }]
    });
    if (!ok) return;
    try {
      const toRemove = [];
      for (let i = 0; i < (localStorage?.length || 0); i++) {
        const k = localStorage.key(i);
        if (k && k.startsWith(LS_PREFIX)) toRemove.push(k);
      }
      toRemove.forEach((k) => localStorage.removeItem(k));
      globalThis.Platform.UI.toast({ messageKey: 'settings.resetAllDone', vars: { n: toRemove.length }, variant: 'success' });
      this.onVisible({ querySelector: () => region });
    } catch (_) {}
  }

  _truncUrl(url) {
    if (!url) return '';
    if (url.length <= 80) return url;
    const m = url.match(/^(https?:\/\/[^/]+)(\/[^?]+)/);
    return m ? `${m[1]}${m[2].slice(0, 60)}…` : url.slice(0, 80) + '…';
  }

  _redactedUrl(url) {
    if (!url) return '';
    try {
      const u = new URL(url);
      return `${u.origin}${u.pathname.replace(/\/workflows\/[^/]+/, '/workflows/[redacted]')}?api-version=1&sig=[redacted]`;
    } catch (_) {
      return '[endpoint redacted]';
    }
  }
}
Modules.register(SettingsModule);
export default SettingsModule;
