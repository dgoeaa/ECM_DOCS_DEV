/** Service for 'settings' — purely local; no remote endpoint needed. */

export const serviceDescriptor = Object.freeze({ moduleId: 'settings', role: 'admin-configuration-workbench', serviceMode: 'local', endpoints: Object.freeze([]) });
export default {};
