/** Stage M-R10.4 — RBAC runtime helper. This gates UI capabilities and module visibility. */
import { State } from './state.js';
import { Bus } from './bus.js';
import { DEFAULT_ROLE, ROLES, ROLE_ORDER, roleById, roleAllows } from '../config/rbac.config.js';

const USERS_KEY = 'admin.users';
const PROFILE_KEY = 'profile.user';
const nowIso = () => new Date().toISOString();
const clone = (v) => JSON.parse(JSON.stringify(v));

function profile() {
  try {
    const raw = localStorage.getItem('obsidian.' + PROFILE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}

function seedUsers() {
  const p = profile() || {};
  const email = p.email || 'current-user@local';
  return [{
    id: 'current-user',
    fullName: p.fullName || p.name || 'Current User',
    email,
    role: p.role || State.get('shared.session.role', DEFAULT_ROLE),
    persona: State.get('shared.session.persona', roleById(p.role || DEFAULT_ROLE)?.persona || 'general'),
    directorate: p.dsuKey || p.directorate || p.department || '',
    status: 'active',
    createdAt: nowIso(),
    updatedAt: nowIso()
  }];
}

export const RBAC = {
  roles() { return ROLE_ORDER.map((id) => ROLES[id]).filter(Boolean); },
  permissions(roleId) { return roleById(roleId)?.permissions || []; },
  currentRole() {
    const p = profile();
    return p?.role || State.get('shared.session.role', DEFAULT_ROLE);
  },
  can(permission) { return roleAllows(RBAC.currentRole(), permission); },
  require(permission) {
    const ok = RBAC.can(permission);
    if (!ok) Bus.emit('platform:rbac:denied', { permission, role: RBAC.currentRole(), ts: nowIso() });
    return ok;
  },
  users() {
    const stored = State.get(USERS_KEY, null);
    if (Array.isArray(stored) && stored.length) return clone(stored);
    const seeded = seedUsers();
    State.set(USERS_KEY, seeded);
    return clone(seeded);
  },
  saveUsers(users) {
    const clean = (Array.isArray(users) ? users : []).map((u, i) => ({
      id: u.id || `user-${Date.now()}-${i}`,
      fullName: String(u.fullName || '').trim(),
      email: String(u.email || '').trim().toLowerCase(),
      role: roleById(u.role) ? u.role : DEFAULT_ROLE,
      persona: u.persona || roleById(u.role || DEFAULT_ROLE)?.persona || 'general',
      directorate: String(u.directorate || '').trim(),
      status: u.status === 'disabled' ? 'disabled' : 'active',
      createdAt: u.createdAt || nowIso(),
      updatedAt: nowIso()
    })).filter((u) => u.email);
    State.set(USERS_KEY, clean);
    Bus.emit('admin:users:changed', { count: clean.length, ts: nowIso() });
    return clone(clean);
  },
  upsertUser(user) {
    const users = RBAC.users();
    const email = String(user.email || '').trim().toLowerCase();
    const idx = users.findIndex((u) => u.email === email || u.id === user.id);
    const next = {
      id: user.id || `user-${Date.now()}`,
      fullName: String(user.fullName || '').trim(),
      email,
      role: roleById(user.role) ? user.role : DEFAULT_ROLE,
      persona: user.persona || roleById(user.role || DEFAULT_ROLE)?.persona || 'general',
      directorate: String(user.directorate || '').trim(),
      status: user.status === 'disabled' ? 'disabled' : 'active',
      createdAt: user.createdAt || nowIso(),
      updatedAt: nowIso()
    };
    if (idx >= 0) users[idx] = { ...users[idx], ...next, createdAt: users[idx].createdAt || next.createdAt };
    else users.push(next);
    RBAC.saveUsers(users);
    Bus.emit('audit:user-upsert', { email: next.email, role: next.role, status: next.status, ts: nowIso() });
    return next;
  },
  setRole(email, role) {
    if (!roleById(role)) return null;
    const users = RBAC.users();
    const u = users.find((x) => x.email === String(email || '').toLowerCase());
    if (!u) return null;
    u.role = role;
    u.persona = roleById(role)?.persona || u.persona;
    u.updatedAt = nowIso();
    RBAC.saveUsers(users);
    Bus.emit('audit:role-assigned', { email: u.email, role, ts: nowIso() });
    return u;
  },
  disableUser(email) {
    const users = RBAC.users();
    const u = users.find((x) => x.email === String(email || '').toLowerCase());
    if (!u) return null;
    u.status = 'disabled';
    u.updatedAt = nowIso();
    RBAC.saveUsers(users);
    Bus.emit('audit:user-disabled', { email: u.email, ts: nowIso() });
    return u;
  }
};

export default RBAC;
