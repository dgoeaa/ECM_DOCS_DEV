/**
 * OBSIDIAN v4.2 — Storage Manager
 * Remediated (REL-01): Diagnostic log eviction under storage limits.
 */
import { Bus } from './bus.js';

const PFX = 'obsidian.';
const STORAGE_LIMIT_BYTES = 5 * 1024 * 1024;

const full = (k) => (k.startsWith(PFX) ? k : PFX + k);

function measureStorage() {
  if (typeof localStorage === 'undefined') return { usedBytes: 0, percent: 0, level: 'ok' };
  let usedBytes = 0;
  for (let i = 0; i < localStorage.length; i++) {
    const k = localStorage.key(i);
    if (!k) continue;
    const v = localStorage.getItem(k) || '';
    usedBytes += (k.length + v.length) * 2;
  }
  const percent = Math.min(100, Math.round((usedBytes / STORAGE_LIMIT_BYTES) * 100));
  const level = percent >= 90 ? 'critical' : percent >= 75 ? 'warning' : 'ok';
  return { usedBytes, limitBytes: STORAGE_LIMIT_BYTES, percent, level };
}

function evictLargestCache() {
  const targets = ['obsidian.requestLog.v1', 'obsidian.auditLog.v1'];
  let evicted = false;
  for (const t of targets) {
    try {
      const data = localStorage.getItem(t);
      if (data) {
        const parsed = JSON.parse(data);
        if (Array.isArray(parsed) && parsed.length > 50) {
          const keep = parsed.slice(-Math.floor(parsed.length * 0.1));
          localStorage.setItem(t, JSON.stringify(keep));
          evicted = true;
        } else {
          localStorage.removeItem(t);
          evicted = true;
        }
      }
    } catch (_) {}
  }
  return evicted;
}

export const Storage = {
  get(key, fallback = null) {
    try {
      const raw = localStorage.getItem(full(key));
      return raw == null ? fallback : JSON.parse(raw);
    } catch {
      return fallback;
    }
  },
  set(key, value) {
    const fKey = full(key);
    const serialized = JSON.stringify(value);
    let success = false;
    try {
      localStorage.setItem(fKey, serialized);
      success = true;
    } catch (e) {
      if (evictLargestCache()) {
        try {
          localStorage.setItem(fKey, serialized);
          success = true;
        } catch (_) {}
      }
      if (!success) {
        Bus.emit('platform:storage:error', { key, error: e.message });
      }
    }
    const metrics = measureStorage();
    if (metrics.level !== 'ok') {
      Bus.emit('platform:storage:pressure', metrics);
    }
    return success;
  },
  remove(key) {
    try {
      localStorage.removeItem(full(key));
    } catch { /* ignore */ }
  },
  getDiagnostics() { return measureStorage(); },
  install() {
    if (typeof window === 'undefined') return;
    window.addEventListener('storage', (e) => {
      if (!e.key || !e.key.startsWith(PFX)) return;
      let value = null;
      try { value = e.newValue == null ? null : JSON.parse(e.newValue); } catch { /* ignore */ }
      Bus.emit('platform:storage:changed', { key: e.key.slice(PFX.length), value });
    });
  }
};
export default Storage;
