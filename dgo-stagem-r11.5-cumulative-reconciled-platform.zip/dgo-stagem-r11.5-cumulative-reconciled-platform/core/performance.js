/** Stage M-R10.5 — Performance utilities and lightweight telemetry. */
import { PerformanceConfig } from '../config/performance.config.js';
import { Bus } from './bus.js';

const metrics = {
  api: { total: 0, cacheHits: 0, inflightHits: 0, network: 0, queued: 0, errors: 0, totalMs: 0 },
  ui: { scheduled: 0, longTasks: 0, lastLongTaskMs: 0 },
  entity: { snapshotHits: 0, countsHits: 0 }
};

export function debounce(fn, wait = PerformanceConfig.ui.filterDebounceMs) {
  let timer = null;
  return function debounced(...args) {
    clearTimeout(timer);
    timer = setTimeout(() => fn.apply(this, args), wait);
  };
}

export function schedule(fn, label = 'ui') {
  metrics.ui.scheduled++;
  const run = () => {
    const t0 = performance?.now?.() || Date.now();
    try { fn(); }
    finally {
      const dt = Math.round((performance?.now?.() || Date.now()) - t0);
      if (dt > PerformanceConfig.ui.longTaskWarnMs) {
        metrics.ui.longTasks++; metrics.ui.lastLongTaskMs = dt;
        Bus.emit('performance:long-task', { label, durationMs: dt });
      }
    }
  };
  if (typeof requestIdleCallback === 'function') requestIdleCallback(run, { timeout: 250 });
  else if (typeof requestAnimationFrame === 'function') requestAnimationFrame(run);
  else setTimeout(run, PerformanceConfig.ui.idleHydrationDelayMs);
}

export function stableKey(value) {
  const seen = new WeakSet();
  return JSON.stringify(value, (k, v) => {
    if (v && typeof v === 'object') {
      if (seen.has(v)) return '[Circular]';
      seen.add(v);
      if (!Array.isArray(v)) return Object.keys(v).sort().reduce((o, key) => { o[key] = v[key]; return o; }, {});
    }
    return v;
  });
}

export function recordApi(result) {
  metrics.api.total++;
  metrics.api.totalMs += Number(result?.durationMs || 0);
  if (result?.cacheHit) metrics.api.cacheHits++;
  if (result?.inflightHit) metrics.api.inflightHits++;
  if (result?.queued) metrics.api.queued++;
  if (result?.kind === 'network') metrics.api.network++;
  if (result && result.ok === false) metrics.api.errors++;
  if (Number(result?.durationMs || 0) > PerformanceConfig.api.requestBudgetWarnMs) {
    Bus.emit('performance:api-slow', { endpointKey: result.endpointKey, durationMs: result.durationMs, correlationId: result.correlationId });
  }
}

export const Performance = {
  config: PerformanceConfig,
  metrics: () => JSON.parse(JSON.stringify(metrics)),
  debounce,
  schedule,
  stableKey,
  recordApi,
  markSnapshotHit() { metrics.entity.snapshotHits++; },
  markCountsHit() { metrics.entity.countsHits++; }
};

export default Performance;
