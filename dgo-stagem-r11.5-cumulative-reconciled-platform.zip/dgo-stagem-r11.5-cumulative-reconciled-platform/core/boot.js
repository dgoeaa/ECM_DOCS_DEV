/**
 * OBSIDIAN v4.2 — Boot Loader & Systemic Onboarding Experience
 * Remediated: Active direct boot sequencer.
 */
import { Platform } from './platform.js';
import { AppConfig } from '../config/app.config.js';
import { FeatureFlags } from '../config/feature-flags.config.js';

let bootPromise = null;

export function boot({ outlet } = {}) {
  if (bootPromise) return bootPromise;
  bootPromise = (async () => {
  Platform.Lifecycle.mark('boot:start');
  let ready = false;
  try {
    Platform.Storage.install();
    Platform.Errors.install();
    Platform.State.hydrate();

    await Platform.I18n.load(Platform.State.get('shared.locale.code', AppConfig.defaultLocale));
    Platform.Format.setLocale(Platform.I18n.locale());

    Platform.Theme.init();
    Platform.Brand.init();
    Platform.Persona.init();
    Platform.HeaderContext?.init?.();

    const main = outlet || document.getElementById('module-outlet') || document.querySelector('.pf-shell__main');
    Platform.Nav.init();
    Platform.Router.init(main);

    if (typeof window !== 'undefined') {
      const setOnline = () => Platform.State.set('shared.connectivity.online', navigator.onLine);
      window.addEventListener('online', setOnline);
      window.addEventListener('offline', setOnline);
      setOnline();

      if (FeatureFlags.serviceWorker === true && 'serviceWorker' in navigator) {
        navigator.serviceWorker.addEventListener('message', (event) => {
          const msg = event.data || {};
          if (msg.source !== 'obsidian-service-worker') return;
          if (msg.type === 'sw:precache-failed' || msg.type === 'sw:fallback-failed') {
            Platform.Bus.emit('platform:warning:push', {
              key: msg.type,
              text: 'Offline cache is incomplete. Keep the app online and reload if content does not appear.',
              dismissable: true
            });
            Platform.UI?.toast?.({ message: 'Offline cache warning: reload while online if content does not appear.', variant: 'warning' });
          }
        });
      }
    }
    ready = true;
  } catch (e) {
    Platform.Log.error('boot.failed', { message: String(e && e.message || e) });
    throw e;
  } finally {
    Platform.Lifecycle.mark('boot:end');
    Platform.Lifecycle.measure('boot', 'boot:start', 'boot:end');
    
    if (typeof document !== 'undefined') {
      const l = document.getElementById('loader');
      if (ready && l) { l.remove(); }
      if (ready) Platform.Bus.emit('platform:ready');
    }
  }

  Platform.Entities.bootstrap().catch((e) => {
    const message = String(e && e.message || e);
    Platform.Log.warn('entities.bootstrap-failed', { message });
    Platform.Bus.emit('platform:warning:push', {
      key: 'entities.bootstrap-failed',
      text: 'Platform data did not finish loading. Workspaces will show retryable error states instead of empty results.',
      dismissable: true
    });
  });
  Platform.Lookups?.load?.().catch((e) => Platform.Log.warn('lookups.warm-failed', { message: String(e && e.message || e) }));
  return Platform;
  })();
  return bootPromise.catch((error) => { bootPromise = null; throw error; });
}

if (typeof window !== 'undefined') window.__obsidianBoot = boot;
export default boot;