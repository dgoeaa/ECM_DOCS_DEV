/** Stage M-R10.5 — UI rendering performance runtime. */
import { PerformanceConfig } from '../config/performance.config.js';
import { schedule } from './performance.js';

const STYLE_ID = 'dgo-r10-5-ui-performance-runtime';
function ensureStyle() {
  if (document.getElementById(STYLE_ID)) return;
  const css = `@layer overrides{
    #module-outlet :where(.pf-card,.pf-panel,.pf-table-wrap,[data-region="detail"],[data-region="preview"],.ua-card){contain:layout paint style;}
    #module-outlet :where(.pf-card,.pf-panel,.pf-table-wrap,.ua-card){content-visibility:auto;contain-intrinsic-size:1px 280px;}
    #module-outlet :where(.pf-bulk__list,.pf-md__gallery,[data-region="list"]){overscroll-behavior:contain;}
    .dgo-perf-note{font-size:.85rem;color:var(--dgo-color-fg-muted,var(--color-text-muted));padding:.45rem .65rem;border:1px dashed var(--dgo-color-border-default,var(--color-border));border-radius:10px;background:var(--dgo-color-surface-sunken,var(--color-surface-muted));}
  }`;
  const style = document.createElement('style'); style.id = STYLE_ID; style.textContent = css; document.head.appendChild(style);
}
function applyHints(root=document) {
  if (!PerformanceConfig.ui.enableContentVisibility) return;
  root.querySelectorAll?.('#module-outlet .pf-card,#module-outlet .pf-panel,#module-outlet .pf-table-wrap,#module-outlet [data-region="detail"],#module-outlet [data-region="preview"],#module-outlet .ua-card')
    .forEach((el) => { el.dataset.perfContain = 'true'; });
}
export const UIPerformance = {
  init() {
    ensureStyle();
    schedule(() => applyHints(document), 'ui-performance-initial');
    const mo = new MutationObserver((records) => {
      schedule(() => records.forEach((r) => r.addedNodes.forEach((n) => { if (n.nodeType === 1) applyHints(n); })), 'ui-performance-mutation');
    });
    mo.observe(document.body, { childList:true, subtree:true });
    globalThis.DGOPerformance = globalThis.DGOPerformance || {};
    globalThis.DGOPerformance.refreshUi = () => applyHints(document);
  }
};
if (typeof document !== 'undefined') {
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => UIPerformance.init(), { once:true });
  else UIPerformance.init();
}
export default UIPerformance;
