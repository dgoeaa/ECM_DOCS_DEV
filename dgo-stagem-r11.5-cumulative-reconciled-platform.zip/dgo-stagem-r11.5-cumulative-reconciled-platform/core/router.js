/** OBSIDIAN v4.3 — Core Router with responsiveness lifecycle containment. */
import { Bus } from './bus.js';
import { Modules } from './modules-registry.js';
import { Persona } from './persona-controller.js';
import { RoutesConfig } from '../config/routes.config.js';
import { Lifecycle } from './lifecycle.js';
import { loadingState, errorState } from '../shared/utils/render.js';

let outlet = null;
let activeId = null;
let activeInstance = null;
let activeKey = null;
let activeTransitionToken = 0;
let activeAbortController = null;
let hashListenerInstalled = false;
let personaOff = null;

function parseHash() {
  const h = (location.hash || '').replace(/^#\/?/, '');
  const [id, ...rest] = h.split('/');
  return { id: id || RoutesConfig.defaultRoute, params: { path: rest } };
}
function routeKey(id, params) { return id + ':' + JSON.stringify(params || {}); }
function firstParam(params) { return params && params.path && params.path[0]; }
async function cleanupActive() {
  const previous = activeInstance;
  if (!previous) return;
  activeAbortController?.abort?.();
  try { await previous.onHidden?.(outlet); } catch (e) { (globalThis.Platform?.Log)?.warn?.('router.onHidden-failed', { message:String(e && e.message || e) }); }
  try { await previous.onUnmount?.(outlet); } catch (e) { (globalThis.Platform?.Log)?.warn?.('router.onUnmount-failed', { message:String(e && e.message || e) }); }
  try { previous.destroy?.(); } catch (_) {}
}

async function transition() {
  const token = ++activeTransitionToken;
  const { id, params } = parseHash();
  const key = routeKey(id, params);

  if (key === activeKey && activeInstance) {
    Bus.emit('platform:route:suppressed', { id, params, reason: 'same-route' });
    return;
  }

  const redirect = RoutesConfig.redirects && RoutesConfig.redirects[id];
  if (redirect && redirect !== id) {
    Bus.emit('audit:route-redirected', { from: id, to: redirect, ts: new Date().toISOString() });
    return Router.navigate(redirect, firstParam(params));
  }

  let M = Modules.get(id);
  if (!M) {
    if (id === RoutesConfig.notFoundRoute) {
      if (outlet) {
        const empty = document.createElement('div');
        empty.className = 'pf-empty';
        const title = document.createElement('div');
        title.className = 'pf-empty__title';
        title.textContent = 'Workspace not found';
        empty.append(title);
        outlet.replaceChildren(empty);
      }
      Bus.emit('platform:route:changed', { id, params });
      return;
    }
    return Router.navigate(RoutesConfig.notFoundRoute);
  }

  const session = Persona.profile();
  const requiresAuth = M.audience !== 'all';
  if (requiresAuth && !session) {
    Bus.emit('audit:unauthorized-route-attempt', { id, ts: new Date().toISOString() });
    Bus.emit('auth:required', { targetRoute: id });
    return Router.navigate(RoutesConfig.deniedRoute);
  }
  if (M.status === 'sunset') return Router.navigate(RoutesConfig.sunsetRoute);
  if (!Persona.canSee(M.audience || 'all')) {
    Bus.emit('audit:route-denied', { id, persona: Persona.current() });
    return Router.navigate(RoutesConfig.deniedRoute);
  }

  Lifecycle.mark('route:start');
  Bus.emit('platform:route:transition-start', { id, params, token });
  await cleanupActive();
  if (token !== activeTransitionToken) return;

  activeAbortController = new AbortController();
  const instance = new M();
  instance.routeSignal = activeAbortController.signal;
  activeInstance = instance;
  activeId = id;
  activeKey = key;

  if (outlet) {
    outlet.id = 'module-outlet';
    outlet.dataset.routePending = id;
    outlet.setAttribute('aria-busy', 'true');
  }

  try {
    await instance.onMount?.(outlet, params);
    if (token !== activeTransitionToken || activeAbortController.signal.aborted) return;
    await instance.onVisible?.(outlet, params);
  } catch (e) {
    if (token !== activeTransitionToken) return;
    const message = String(e && e.message || e);
    (globalThis.Platform?.Log)?.error('router.mount-failed', { id, message });
    if (outlet) errorState(outlet, {
      title: 'Workspace failed to load',
      body: `The ${id} workspace could not be opened.`,
      details: message,
      retryLabel: 'Retry', homeLabel: 'Go home',
      onRetry: () => Router.navigate(id, firstParam(params)),
      onHome: () => Router.navigate(RoutesConfig.defaultRoute)
    });
  }

  if (outlet) { delete outlet.dataset.routePending; outlet.removeAttribute('aria-busy'); }
  Lifecycle.mark('route:end');
  Lifecycle.measure('route-transition', 'route:start', 'route:end');
  Bus.emit('platform:nav:changed', { id, params });
  Bus.emit('platform:route:changed', { id, params, token });
  Bus.emit('platform:route:transition-end', { id, params, token });
  if (globalThis.Platform?.A11y) globalThis.Platform.A11y.announce(id);
}

export const Router = {
  init(outletEl) {
    outlet = outletEl;
    if (!hashListenerInstalled) {
      window.addEventListener('hashchange', transition);
      hashListenerInstalled = true;
    }
    if (!personaOff) personaOff = Bus.on('platform:persona:changed', () => {
      const M = Modules.get(activeId);
      if (M && !Persona.canSee(M.audience || 'all')) Router.navigate(RoutesConfig.deniedRoute);
    });
    if (!location.hash) location.hash = '#/' + RoutesConfig.defaultRoute; else transition();
  },
  navigate(id, param) {
    const target = '#/' + id + (param ? '/' + encodeURIComponent(param) : '');
    if (location.hash === target) return transition();
    location.hash = target;
  },
  current() { return { id: activeId, instance: activeInstance, token: activeTransitionToken }; },
  abortActive() { activeAbortController?.abort?.(); }
};
export default Router;
