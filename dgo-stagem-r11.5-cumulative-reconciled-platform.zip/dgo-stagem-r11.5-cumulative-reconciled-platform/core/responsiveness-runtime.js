/**
 * DGO Obsidian Responsiveness Runtime Remediation
 * Implements bounded instrumentation, event dedupe, same-value suppression,
 * route/navigation counters, and safe runtime caps without changing business data.
 */
import { Bus } from './bus.js';
import { State } from './state.js';
import { Context } from './context.js';
import { Entities } from './entity-store.js';

export const ResponsivenessConfig = Object.freeze({
  guardDebounceMs: 50,
  guardIdleDelayMs: 250,
  maxNodesPerGuardPass: 200,
  maxGuardPassesPerFrame: 2,
  eventDedupeWindowMs: 100,
  stateBatchWindowMs: 16,
  entityBatchWindowMs: 32,
  navRebuildThrottleMs: 100,
  searchDebounceMs: 250,
  filterDebounceMs: 200,
  richPickerDebounceMs: 250,
  defaultPageSize: 50,
  maxRenderedRows: 200,
  maxLookupResultsPerType: 100,
  maxRichPickerResults: 100,
  chartRenderDelayMs: 100,
  diagnosticsRefreshThrottleMs: 5000,
  storageScanChunkSize: 100,
  jsonParseBudgetMs: 8,
  maxAuditEntries: 5000,
  maxRequestLogEntries: 2000,
  maxOutboxVisibleRows: 100,
  maxDeadletterVisibleRows: 100,
  outboxRetryUiThrottleMs: 1000,
  endpointPingConcurrency: 3,
  swFetchTimeoutMs: 5000,
  componentRenderDebounceMs: 16,
  maxToastStack: 5,
  shellRedrawThrottleMs: 100
});

const counters = globalThis.__dgoPerfCounters = globalThis.__dgoPerfCounters || {
  bus: Object.create(null),
  deduped: Object.create(null),
  routes: Object.create(null),
  stateSkipped: 0,
  contextSkipped: 0,
  entityEvents: 0,
  installedAt: new Date().toISOString()
};

function stable(value) {
  if (value == null) return String(value);
  if (typeof value !== 'object') return String(value);
  try {
    const seen = new WeakSet();
    return JSON.stringify(value, (k, v) => {
      if (k === 'ts' || k === 'timestamp' || k === 'time') return undefined;
      if (typeof v === 'function') return '[fn]';
      if (v && typeof v === 'object') {
        if (seen.has(v)) return '[circular]';
        seen.add(v);
      }
      return v;
    });
  } catch (_) { return '[unserializable]'; }
}

function same(a, b) { return stable(a) === stable(b); }

export function installResponsivenessRuntime() {
  const html = document.documentElement;
  if (html.dataset.dgoResponsivenessRuntime === 'installed') return;
  html.dataset.dgoResponsivenessRuntime = 'installed';

  // Bus event counters and conservative dedupe for high-frequency UI/cascade events.
  if (!Bus.__dgoResponsivenessWrapped) {
    const originalEmit = Bus.emit.bind(Bus);
    const recent = new Map();
    const dedupeTypes = /^(platform:ux:selected|platform:nav:changed|platform:nav:rebuilt|context:reference:changed|reference:change|platform:state:changed)$/;
    Bus.emit = function emitWithDedupe(event, detail) {
      counters.bus[event] = (counters.bus[event] || 0) + 1;
      if (/^entity:/.test(event)) counters.entityEvents++;
      if (dedupeTypes.test(event)) {
        const now = performance.now();
        const key = event + ':' + stable(detail);
        const last = recent.get(key) || 0;
        if (now - last < ResponsivenessConfig.eventDedupeWindowMs) {
          counters.deduped[event] = (counters.deduped[event] || 0) + 1;
          return detail;
        }
        recent.set(key, now);
        if (recent.size > 500) {
          const cutoff = now - ResponsivenessConfig.eventDedupeWindowMs * 10;
          for (const [k, t] of recent) if (t < cutoff) recent.delete(k);
        }
      }
      return originalEmit(event, detail);
    };
    Bus.__dgoResponsivenessWrapped = true;
  }

  // Same-value state suppression. This is intentionally conservative: no delayed batching of state writes.
  if (State && !State.__dgoResponsivenessWrapped) {
    const originalSet = State.set.bind(State);
    State.set = function setWithSameValueSuppression(path, value) {
      const previous = State.get(path, undefined);
      if (same(previous, value)) {
        counters.stateSkipped++;
        return value;
      }
      return originalSet(path, value);
    };
    State.__dgoResponsivenessWrapped = true;
  }

  // Active reference dedupe to prevent selection cascades.
  if (Context && !Context.__dgoResponsivenessWrapped && typeof Context.setActive === 'function') {
    const originalSetActive = Context.setActive.bind(Context);
    Context.setActive = function setActiveDeduped(refId, sourceModule) {
      const next = refId ? String(refId) : null;
      if (Context.activeReference && Context.activeReference() === next) {
        counters.contextSkipped++;
        return refId;
      }
      return originalSetActive(refId, sourceModule);
    };
    Context.__dgoResponsivenessWrapped = true;
  }

  // Entity read counters for diagnostics; does not alter results.
  if (Entities && !Entities.__dgoResponsivenessWrapped) {
    for (const name of ['all', 'byReference', 'counts']) {
      if (typeof Entities[name] !== 'function') continue;
      const original = Entities[name].bind(Entities);
      Entities[name] = function countedEntityRead(...args) {
        const key = 'entity.' + name;
        counters.bus[key] = (counters.bus[key] || 0) + 1;
        return original(...args);
      };
    }
    Entities.__dgoResponsivenessWrapped = true;
  }

  globalThis.__dgoResponsivenessConfig = ResponsivenessConfig;
  Bus.emit('platform:responsiveness:installed', { config: ResponsivenessConfig, ts: new Date().toISOString() });
}

installResponsivenessRuntime();
export default { ResponsivenessConfig, installResponsivenessRuntime };
