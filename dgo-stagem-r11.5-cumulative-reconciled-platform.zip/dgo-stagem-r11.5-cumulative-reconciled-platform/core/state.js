/**
 * OBSIDIAN v4.2 — State Machine Engine
 * Remediated (DATA-01): Automatic memory state cross-tab synchronizer.
 */
import { Bus } from './bus.js';
import { Storage } from './storage.js';
import { StateSchema, persistedPaths } from '../config/state.schema.js';

const tree = {};
const subs = new Map();

function getAt(path) {
  return path.split('.').reduce((o, k) => (o == null ? undefined : o[k]), tree);
}

function setAt(path, value) {
  const keys = path.split('.'); const last = keys.pop();
  let o = tree; for (const k of keys) { if (typeof o[k] !== 'object' || o[k] == null) o[k] = {}; o = o[k]; }
  o[last] = value;
}

function notify(path) {
  for (const [prefix, set] of subs) {
    if (path === prefix || path.startsWith(prefix + '.') || prefix.startsWith(path + '.')) {
      const val = getAt(prefix);
      for (const fn of [...set]) { 
        try { 
          fn(val, prefix); 
        } catch (e) { 
          (globalThis.Platform?.Log)?.error('state.sub-threw', { prefix, message: String(e) }); 
        } 
      }
    }
  }
}

export const State = {
  get: (path, fallback) => { const v = getAt(path); return v === undefined ? fallback : v; },
  set(path, value) {
    const prev = getAt(path);
    try { if (JSON.stringify(prev) === JSON.stringify(value)) return value; } catch (_) { if (prev === value) return value; }
    setAt(path, value);
    const def = StateSchema[path];
    if (def && def.persist) Storage.set(def.persist.replace(/^obsidian\./, ''), value);
    notify(path);
    Bus.emit('platform:state:changed', { path, value });
    return value;
  },
  subscribe(path, fn) {
    if (!subs.has(path)) subs.set(path, new Set());
    subs.get(path).add(fn);
    return () => subs.get(path)?.delete(fn);
  },
  hydrate() {
    for (const { path, key, def } of persistedPaths()) {
      const stored = Storage.get(key.replace(/^obsidian\./, ''), undefined);
      setAt(path, stored === undefined ? def : stored);
    }
    for (const [path, d] of Object.entries(StateSchema)) if (getAt(path) === undefined) setAt(path, d.default);

    // Cross-tab auto synchronizer
    Bus.on('platform:storage:changed', (e) => {
      const target = persistedPaths().find(p => p.key === e.key || p.key === `obsidian.${e.key}`);
      if (target) {
        const cur = getAt(target.path);
        if (cur !== e.value) {
          setAt(target.path, e.value);
          notify(target.path);
          Bus.emit('platform:state:changed', { path: target.path, value: e.value });
        }
      }
    });
  }
};
export default State;
