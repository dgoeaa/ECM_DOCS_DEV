/**
 * OBSIDIAN v4.2 — Persona & Session Controller
 * REMEDIATED (ARCH-02): Harden fallback sessions and require verified runtime state.
 */

import { State } from './state.js';
import { Bus } from './bus.js';
import { personaById, DEFAULT_PERSONA } from '../config/personas.config.js';
import { ELEVATED_PERSONAS, isIsolatedDirectorate, isElevatedDsuKey, hasCrossDirectorateFlag } from '../config/directorate.config.js';
import { roleById, DEFAULT_ROLE, roleAllows } from '../config/rbac.config.js';
import { BOOTSTRAP_ADMIN } from '../config/bootstrap-admin.config.js';

const TOKEN_KEY = 'auth.token';
const PROFILE_KEY = 'profile.user';
const _normKey = (v) => (v == null ? '' : String(v).trim().toUpperCase());
const _normEmail = (v) => String(v || '').trim().toLowerCase();
function explicitRoleFrom(payload = {}) { return payload.role || payload.Role || payload.AccessRole || payload['Access Role'] || payload.RBACRole || ''; }
function bootstrapRoleFor(email, explicitRole) {
  const cleanEmail = _normEmail(email);
  if (!cleanEmail || !BOOTSTRAP_ADMIN.enabled) return explicitRole || '';
  if (explicitRole && roleById(explicitRole)) return explicitRole;
  try {
    const stored = _normEmail(localStorage.getItem(BOOTSTRAP_ADMIN.storageEmailKey));
    if (stored && stored === cleanEmail) return BOOTSTRAP_ADMIN.role;
    if (!stored && BOOTSTRAP_ADMIN.mode === 'firstAuthenticatedEmail') {
      localStorage.setItem(BOOTSTRAP_ADMIN.storageEmailKey, cleanEmail);
      localStorage.setItem(BOOTSTRAP_ADMIN.storageClaimedKey, new Date().toISOString());
      Bus.emit(BOOTSTRAP_ADMIN.auditEvent, { email: cleanEmail, role: BOOTSTRAP_ADMIN.role, ts: new Date().toISOString() });
      return BOOTSTRAP_ADMIN.role;
    }
  } catch (_) {}
  return explicitRole || '';
}

export const Persona = {
  init() {
    if (!State.get('shared.session.persona')) {
      State.set('shared.session.persona', DEFAULT_PERSONA);
    }
    this.enforceGateway();
    Bus.on('platform:route:changed', () => this.enforceGateway());
  },

  current() {
    return State.get('shared.session.persona', DEFAULT_PERSONA);
  },

  switch(id) {
    if (!personaById(id)) return Persona.current();
    State.set('shared.session.persona', id);
    Bus.emit('platform:persona:changed', { id });
    Bus.emit('audit:persona-switch', { persona: id, ts: new Date().toISOString() });
    return id;
  },

  canSee(audience) {
    const p = personaById(Persona.current());
    if (!p) return audience === 'all' || audience === 'general';
    return p.audienceSees.includes(audience || 'all');
  },

  role() {
    const p = Persona.profile() || {};
    return p.role || State.get('shared.session.role', DEFAULT_ROLE);
  },

  hasPermission(permission) {
    return roleAllows(Persona.role(), permission);
  },

  getSession() {
    try {
      const token = localStorage.getItem('obsidian.' + TOKEN_KEY);
      const user = localStorage.getItem('obsidian.' + PROFILE_KEY);
      if (token && user) {
        const parsed = JSON.parse(user);
        if (parsed.expiresAt && new Date(parsed.expiresAt) < new Date()) {
          this.clearSession();
          return null;
        }
        return { token, user: parsed };
      }

      Bus.emit('audit:session-missing', { persona: this.current(), timestamp: new Date().toISOString() });
      return null;
    } catch {
      return null;
    }
  },

  normalizeProfile(userPayload = {}) {
    const email = _normEmail(userPayload.email || userPayload.userEmail || userPayload.mail || userPayload.UPN || '');
    const nameFromEmail = email ? email.split('@')[0].replace(/[._-]+/g, ' ').replace(/\b\w/g, (m) => m.toUpperCase()) : '';
    const rawRole = explicitRoleFrom(userPayload);
    const requestedRole = bootstrapRoleFor(email, rawRole) || State.get('shared.session.role', DEFAULT_ROLE);
    const roleInfo = roleById(requestedRole) || roleById(DEFAULT_ROLE);
    return { ...userPayload, email, fullName: userPayload.fullName || userPayload.displayName || userPayload.name || userPayload.FullName || nameFromEmail || 'Authenticated User', jobTitle: userPayload.jobTitle || userPayload.title || userPayload.JobTitle || userPayload['Job Title'] || '', department: userPayload.department || userPayload.Department || userPayload.directorate || userPayload.Directorate || userPayload.dsuKey || userPayload.DSU_KEY || '', directorate: userPayload.directorate || userPayload.Directorate || userPayload.department || userPayload.Department || userPayload.dsuKey || userPayload.DSU_KEY || '', dsuKey: userPayload.dsuKey || userPayload.DSU_KEY || userPayload.directorate || userPayload.department || '', role: roleInfo?.id || DEFAULT_ROLE, persona: userPayload.persona || userPayload.Persona || roleInfo?.persona || DEFAULT_PERSONA, bootstrapAdmin: (roleInfo?.id === BOOTSTRAP_ADMIN.role && !rawRole) || !!userPayload.bootstrapAdmin, bootstrapAdminEmail: roleInfo?.id === BOOTSTRAP_ADMIN.role ? email : (userPayload.bootstrapAdminEmail || ''), authenticatedAt: userPayload.authenticatedAt || new Date().toISOString(), expiresAt: userPayload.expiresAt || new Date(Date.now() + 28800000).toISOString() };
  },

  _storeProfile(profile) {
    const clean = Persona.normalizeProfile(profile || {});
    localStorage.setItem('obsidian.' + PROFILE_KEY, JSON.stringify(clean));
    State.set('shared.session.persona', clean.persona || DEFAULT_PERSONA);
    State.set('shared.session.role', clean.role || DEFAULT_ROLE);
    State.set('shared.session.userEmail', clean.email || '');
    State.set('shared.session.userName', clean.fullName || '');
    State.set('shared.session.directorate', clean.dsuKey || clean.directorate || '');
    Bus.emit('platform:session:active', { user: clean });
    Bus.emit('platform:header:changed', globalThis.Platform?.HeaderContext?.current?.() || {});
    return clean;
  },

  setSession(token, userPayload) {
    try {
      localStorage.setItem('obsidian.' + TOKEN_KEY, token);
      const profile = Persona._storeProfile(userPayload || {});
      Bus.emit('audit:session-profile-captured', { email: profile.email, role: profile.role, persona: profile.persona, directorate: profile.dsuKey || profile.directorate || '', ts: new Date().toISOString() });
      if (profile.email) Persona.hydrateProfileFromReferenceData(profile.email, { silent: true });
      return profile;
    } catch (_) { return null; }
  },

  setProfile(profilePatch = {}) {
    try {
      const existing = Persona.profile() || {};
      const saved = Persona._storeProfile({ ...existing, ...profilePatch, email: profilePatch.email || existing.email });
      Bus.emit('audit:profile-saved', { email: saved.email, source: saved.source || 'manual', ts: new Date().toISOString() });
      return saved;
    } catch (err) { Bus.emit('audit:profile-save-failed', { error: err?.message || String(err), ts: new Date().toISOString() }); throw err; }
  },

  async hydrateProfileFromReferenceData(email, opts = {}) {
    const requested = _normEmail(email || Persona.email() || '');
    if (!requested) return Persona.profile();
    try {
      const { Lookups } = await import('../shared/utils/lookups.js');
      await Lookups.load(false);
      const refProfile = Lookups.userProfileByEmail(requested);
      if (!refProfile) { if (!opts.silent) Bus.emit('profile:reference-user-not-found', { email: requested, ts: new Date().toISOString() }); return Persona.profile(); }
      const existing = Persona.profile() || {};
      const hydrated = Persona._storeProfile({ ...existing, ...refProfile, role: refProfile.role || existing.role, persona: refProfile.persona || existing.persona, email: requested, expiresAt: existing.expiresAt, authenticatedAt: existing.authenticatedAt || new Date().toISOString() });
      Bus.emit('profile:hydrated-from-reference-data', { email: requested, source: 'REFERENCE_DATA.users', ts: new Date().toISOString() });
      return hydrated;
    } catch (err) { if (!opts.silent) Bus.emit('profile:reference-hydration-failed', { email: requested, error: err?.message || String(err), ts: new Date().toISOString() }); return Persona.profile(); }
  },

  clearSession() {
    try {
      localStorage.removeItem('obsidian.' + TOKEN_KEY);
      localStorage.removeItem('obsidian.' + PROFILE_KEY);
      Bus.emit('platform:session:expired');
    } catch (_) {}
  },

  profile() {
    const sess = this.getSession();
    return sess ? sess.user : null;
  },

  email() {
    const p = this.profile();
    if (p && p.email) return p.email;
    return '';
  },

  enforceGateway() {
    if (typeof window === 'undefined') return;
    const sess = this.getSession();
    const isGated = !window.location.pathname.endsWith('tests.html') && !window.location.hash.startsWith('#/diagnostics');
    
    if (!sess && isGated) {
      Bus.emit('auth:required', { ts: new Date().toISOString() });
    }
  },

  directorate() {
    const p = this.profile() || {};
    const dsu = p.dsuKey ?? p.DSU_KEY ?? p.directorate ?? p.department ?? null;
    return dsu ? _normKey(dsu) : null;
  },

  directorateScope() {
    if (this.isElevated()) return ['all'];
    const own = this.directorate();
    return own ? [own] : [];
  },

  isElevated() {
    if (ELEVATED_PERSONAS.has(this.current())) return true;
    return isElevatedDsuKey(this.directorate());
  },

  canSeeRecord(rec) {
    if (!rec || typeof rec !== 'object') return true;
    const dsu = rec.__directorate;
    if (!dsu) return true;
    if (!isIsolatedDirectorate(dsu)) return true;
    if (this.isElevated()) return true;
    if (hasCrossDirectorateFlag(rec)) return true;
    
    const mine = this.directorate();
    return !!(mine && mine === _normKey(dsu));
  }
};

export default Persona;
