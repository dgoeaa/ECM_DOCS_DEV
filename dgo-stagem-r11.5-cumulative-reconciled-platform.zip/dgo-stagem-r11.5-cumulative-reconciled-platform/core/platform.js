/** OBSIDIAN v4.0 — platform.js · composes window.Platform from the emitted core/config.
 *  Later batches attach Forms/Tables/Charts/Palette/Shortcuts/Observability via Platform.extend(). */
import { AppConfig } from '../config/app.config.js';
import { Endpoints } from '../config/endpoints.config.js';
import { FeatureFlags } from '../config/feature-flags.config.js';
import { PERSONAS } from '../config/personas.config.js';
import { StateSchema } from '../config/state.schema.js';
import { BRANDS } from '../config/brand.config.js';
import { RoutesConfig } from '../config/routes.config.js';

import { Log } from './log.js';
import { Bus } from './bus.js';
import { Storage } from './storage.js';
import { State } from './state.js';
import { Errors } from './errors.js';
import { Format } from './format.js';
import { A11y } from './a11y.js';
import { I18n } from './i18n.js';
import { API } from './api.js';
import { BaseService } from './base-service.js';
import { Modules } from './modules-registry.js';
import { Theme } from './theme-manager.js';
import { Brand } from './brand-manager.js';
import { Persona } from './persona-controller.js';
import { Router } from './router.js';
import { Nav } from './nav-controller.js';
import { UI } from './ui.js';
import { Lifecycle } from './lifecycle.js';
import { Entities } from './entity-store.js';
import { Context, goToEntity } from './context.js';
import { Idempotency } from './idempotency.js';
import { AuditLog } from './audit-log.js';
import { ErrorRouter } from './error-router.js';
import { RBAC } from './rbac.js';
import { Performance } from './performance.js';
import { HeaderContext } from './header-context.js';
import { ModuleIntegration } from './module-integration.js';
import { Lookups } from '../shared/utils/lookups.js';   // U1: dropdown option-set provider (was never exposed on Platform)
import { DynamicActions } from '../shared/utils/dynamic-actions.js'; // universal channel for endpoint-less actions
import { Directory } from '../shared/utils/directory.js';  // directorate email/identity resolver (Dispatch / Q-6 / assistant)
import { Reviewers } from '../shared/utils/reviewers.js';  // Q-7 sequential reviewer engine
import { SLA } from './sla.js';                            // D-6 working-time SLA engine

const Platform = {
  Config:AppConfig, Endpoints, Flags:FeatureFlags, Routes:RoutesConfig,
  Personas:PERSONAS, StateSchema, BrandConfig:BRANDS,
  Log, Bus, Storage, State, Errors, Format, A11y, I18n,
  API, BaseService, Modules, Theme, Brand, Persona, Router, Nav, UI, Lifecycle,
  Entities, Context, goToEntity, Idempotency, AuditLog, ErrorRouter, RBAC, Performance, HeaderContext, ModuleIntegration, Lookups, Actions:DynamicActions,
  Directory, Reviewers, SLA,
  extend(obj) { Object.assign(Platform, obj); return Platform; }
};
if (typeof window !== 'undefined') window.Platform = Platform;
// A-10 — route uncaught platform errors through the canonical taxonomy too.
ErrorRouter.install();


// Global keyboard shortcuts — install once at platform boot.
(function _installShortcuts() {
  if (typeof globalThis === 'undefined' || typeof globalThis.addEventListener !== 'function') return;
  if (globalThis.document) {
    let gPressed = false; let gTimer = null;
    const isTyping = (e) => {
      const t = e.target;
      if (!t || !t.tagName) return false;
      const tag = t.tagName.toLowerCase();
      return tag === 'input' || tag === 'textarea' || tag === 'select' || t.isContentEditable;
    };
    globalThis.document.addEventListener('keydown', (e) => {
      // '?' opens shortcuts cheatsheet
      if (!isTyping(e) && e.key === '?') { e.preventDefault(); Platform.UI?.openShortcuts?.(); return; }
      // '/' focuses lookup module's search if available
      if (!isTyping(e) && e.key === '/') {
        const lookupQ = globalThis.document.getElementById('lookup-q');
        if (lookupQ) { e.preventDefault(); lookupQ.focus(); return; }
      }
      // 'g' then letter → navigate
      if (!isTyping(e) && e.key === 'g' && !gPressed) {
        gPressed = true; if (gTimer) clearTimeout(gTimer);
        gTimer = setTimeout(() => { gPressed = false; }, 700);
        return;
      }
      if (!isTyping(e) && gPressed) {
        const TARGETS = { h:'home', o:'ops-hub', l:'lookup', r:'response-tracking', s:'settings', d:'diagnostics', c:'correspondence', x:'dispatch' };
        const tgt = TARGETS[e.key.toLowerCase()];
        if (tgt) { e.preventDefault(); gPressed = false; Platform.Router?.navigate?.(tgt); return; }
      }
      // 'r' refresh fabric
      if (!isTyping(e) && e.key === 'r') {
        Platform.Entities?.bootstrap?.(true).catch(() => {});
        Platform.Lookups?.load?.(true).catch(() => {});
      }
      // 'n' open new assignment
      if (!isTyping(e) && e.key === 'n') {
        Platform.Router?.navigate?.('single-item-ops');
      }
    });
  }
})();

export default Platform;
export { Platform };


// --- DGO Command Palette (v2.1) Integration ---
(function initCMDK() {
  if (typeof document === 'undefined') return;
  window.addEventListener('DOMContentLoaded', () => {
    const $backdrop = document.getElementById('cmdkBackdrop');
    const $input    = document.getElementById('cmdkInput');
    const $listbox  = document.getElementById('cmdkListbox');
    const $status   = document.getElementById('cmdkStatus');
    if (!$backdrop || !$input || !$listbox) return;

    let activeIndex = 0;
    let visible = [];

    function getCommands() {
      const model = Platform.Nav?.model ? Platform.Nav.model() : { groups: [] };
      const cmds = [];
      (model.groups || []).forEach((group) => {
        (group.items || []).forEach((item) => {
          cmds.push({
            group: Platform.I18n?.t ? Platform.I18n.t(group.labelKey) : group.id,
            icon: item.icon || 'circle',
            label: Platform.I18n?.t ? Platform.I18n.t(item.labelKey || item.label || item.id) : (item.label || item.id),
            action: () => Platform.Router.navigate(item.id)
          });
        });
      });
      cmds.push(
        { group: 'Actions', icon: 'file-plus', label: 'New Assignment', action: () => Platform.Router.navigate('single-item-ops') },
        { group: 'System', icon: 'contrast', label: 'Cycle Theme', action: () => Platform.Bus.emit('platform:theme:cycle') }
      );
      
      if (Platform.Entities && Platform.Entities.isHydrated()) {
        const recent = Platform.Entities.counts().recent || [];
        recent.forEach(r => {
          cmds.push({
            group: 'Recent References',
            icon: 'file',
            label: `${r.__ref || r.referenceId} — ${r.title || r.subject || 'Untitled'}`,
            action: () => Platform.goToEntity(r.__ref || r.referenceId, 'response-tracking')
          });
        });
      }
      return cmds;
    }

    function render(q) {
      q = (q || '').trim().toLowerCase();
      const COMMANDS = getCommands();
      const filtered = q ? COMMANDS.filter(c => c.label.toLowerCase().includes(q)) : COMMANDS;
      visible = filtered;
      $listbox.replaceChildren();

      if (filtered.length === 0) {
        const empty = document.createElement('li');
        empty.className = 'dgo-cmdk__empty';
        empty.setAttribute('role', 'status');
        const strong = document.createElement('strong');
        strong.textContent = 'No matches';
        const hint = document.createTextNode('Try a different keyword.');
        empty.append(strong, hint);
        $listbox.appendChild(empty);
        return;
      }

      let lastGroup = null;
      let groupUL = null;
      filtered.forEach((cmd, i) => {
        if (cmd.group !== lastGroup) {
          const groupLi = document.createElement('li');
          groupLi.className = 'dgo-cmdk__group';
          const groupLabel = document.createElement('div');
          groupLabel.className = 'dgo-cmdk__group-label';
          groupLabel.textContent = cmd.group;
          groupUL = document.createElement('ul');
          groupLi.append(groupLabel, groupUL);
          $listbox.appendChild(groupLi);
          lastGroup = cmd.group;
        }
        const item = document.createElement('li');
        item.className = 'dgo-cmdk__item';
        item.id = `cmdk-option-${i}`;
        item.setAttribute('role', 'option');
        item.setAttribute('aria-selected', i === activeIndex ? 'true' : 'false');
        const icon = document.createElement('pf-icon');
        icon.setAttribute('name', cmd.icon);
        icon.setAttribute('size', '18');
        icon.className = 'dgo-cmdk__item-icon';
        const label = document.createElement('span');
        label.className = 'dgo-cmdk__item-label';
        label.textContent = cmd.label;
        item.append(icon, label);
        item.addEventListener('mousemove', () => { activeIndex = i; syncActive(); });
        item.addEventListener('click', () => invoke(i));
        groupUL.appendChild(item);
      });
      syncActive();
    }

    function syncActive() {
      const items = $listbox.querySelectorAll('.dgo-cmdk__item');
      items.forEach((it, i) => {
        const isSel = i === activeIndex;
        it.setAttribute('aria-selected', isSel ? 'true' : 'false');
        if (isSel) {
          $input.setAttribute('aria-activedescendant', it.id);
          it.scrollIntoView({ block: 'nearest' });
        }
      });
    }

    function step(dir) {
      if (!visible.length) return;
      activeIndex = (activeIndex + dir + visible.length) % visible.length;
      syncActive();
    }

    function invoke(i) {
      const cmd = visible[i];
      if (!cmd) return;
      close();
      cmd.action();
    }

    function open() {
      $backdrop.dataset.state = 'open';
      $backdrop.setAttribute('aria-hidden', 'false');
      $input.value = '';
      activeIndex = 0;
      render('');
      setTimeout(() => $input.focus(), 50);
    }

    function close() {
      $backdrop.dataset.state = 'closing';
      $backdrop.setAttribute('aria-hidden', 'true');
      $input.setAttribute('aria-activedescendant', '');
      setTimeout(() => { $backdrop.dataset.state = 'closed'; }, 150);
    }

    document.addEventListener('keydown', (e) => {
      const isMod = e.ctrlKey || e.metaKey;
      if (isMod && (e.key === 'k' || e.key === 'K')) {
        e.preventDefault();
        if ($backdrop.dataset.state === 'open') close(); else open();
      }
    });

    $input.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowDown') { e.preventDefault(); step(1); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); step(-1); }
      else if (e.key === 'Enter') { e.preventDefault(); invoke(activeIndex); }
      else if (e.key === 'Escape') { e.preventDefault(); close(); }
    });

    $input.addEventListener('input', () => { activeIndex = 0; render($input.value); });
    $backdrop.addEventListener('mousedown', (e) => { if (e.target === $backdrop) close(); });
  });
})();

