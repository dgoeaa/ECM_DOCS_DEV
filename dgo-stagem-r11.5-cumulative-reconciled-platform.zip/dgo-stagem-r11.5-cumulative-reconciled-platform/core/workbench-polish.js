/** Stage J — source-level operational workbench decorator.
 * Converts existing master/list/detail layouts into real pane workbenches at runtime.
 * This intentionally executes after module templates/styles are mounted so the rules are
 * injected later than module CSS and are observable in the browser.
 */
const STYLE_ID = 'dgo-workbench-polish-runtime-stage-m-r1';
const WORKBENCH_SELECTORS = [
  '.pf-list__split',
  '.pf-md__split',
  '.pf-ap',
  '.pf-dx',
  '.pf-corr__split',
  '.pf-si__layout',
  '.pf-bulk__layout'
].join(',');
const DETAIL_SELECTORS = [
  '.pf-list__detail',
  '.pf-md__detail',
  '.pf-ap__detail',
  '.pf-dx__detail',
  '.pf-corr__detail',
  '[data-region="detail"]',
  '[data-region="preview"]'
].join(',');
const MASTER_SELECTORS = [
  '.pf-list__main',
  '.pf-md__gallery',
  '.pf-ap__list',
  '.pf-dx__list',
  '.pf-corr__list',
  '[data-region="list"]',
  '[data-region="results"]',
  '[data-region="table"]'
].join(',');

const CSS = `
@layer utilities {
  :root {
    --dgo-wb-gap: clamp(.55rem, 1vw, .9rem);
    --dgo-wb-detail: clamp(21rem, 32vw, 31rem);
    --dgo-wb-max-h: calc(100dvh - clamp(8rem, 13vh, 11.5rem));
    --dgo-wb-min-h: 30rem;
  }

  #module-outlet [data-dgo-workbench="1"] {
    display: grid !important;
    grid-template-columns: minmax(0, 1fr) minmax(20rem, var(--dgo-wb-detail)) !important;
    gap: var(--dgo-wb-gap) !important;
    align-items: stretch !important;
    min-width: 0 !important;
  }

  @media (min-width: 901px) and (orientation: landscape) {
    #module-outlet [data-dgo-workbench="1"] {
      min-height: min(var(--dgo-wb-min-h), var(--dgo-wb-max-h)) !important;
      height: clamp(var(--dgo-wb-min-h), 72dvh, var(--dgo-wb-max-h)) !important;
      max-height: var(--dgo-wb-max-h) !important;
      overflow: hidden !important;
    }

    #module-outlet [data-dgo-master="1"] {
      min-width: 0 !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: auto !important;
      overscroll-behavior: contain !important;
      scrollbar-gutter: stable both-edges !important;
      -webkit-overflow-scrolling: touch !important;
    }

    #module-outlet [data-dgo-master="1"] .pf-table-wrap,
    #module-outlet [data-dgo-master="1"].pf-table-wrap,
    #module-outlet [data-dgo-master="1"] [data-region="table"] {
      height: 100% !important;
      max-height: 100% !important;
      overflow: auto !important;
    }

    #module-outlet [data-dgo-detail="1"] {
      position: sticky !important;
      top: clamp(.75rem, 2vh, 1.25rem) !important;
      align-self: start !important;
      min-width: 0 !important;
      min-height: min(18rem, 100%) !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: auto !important;
      overscroll-behavior: contain !important;
      scrollbar-gutter: stable !important;
      -webkit-overflow-scrolling: touch !important;
    }

    #module-outlet [data-dgo-detail="1"] > :where(header, .pf-detail__head, .pf-detail__header, .af-detail__head, .pf-ap__head, .pf-dx__head, .pf-corr__head):first-child {
      position: sticky !important;
      top: 0 !important;
      z-index: 3 !important;
      background: color-mix(in srgb, var(--color-surface-raised, #fff) 94%, transparent) !important;
      backdrop-filter: blur(10px);
      border-bottom: 1px solid color-mix(in srgb, var(--color-border, #e5e7eb) 70%, transparent) !important;
      margin: -1rem -1rem .75rem !important;
      padding: 1rem !important;
    }
  }

  @media (max-width: 900px), (orientation: portrait) {
    #module-outlet [data-dgo-workbench="1"] {
      grid-template-columns: 1fr !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
    }
    #module-outlet [data-dgo-master="1"],
    #module-outlet [data-dgo-detail="1"],
    #module-outlet [data-dgo-master="1"] .pf-table-wrap {
      position: static !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
    }
    #module-outlet [data-dgo-workbench="1"][data-view="list"] [data-dgo-detail="1"] { display: none !important; }
    #module-outlet [data-dgo-workbench="1"][data-view="detail"] [data-dgo-master="1"] { display: none !important; }
    #module-outlet [data-dgo-workbench="1"][data-view="detail"] [data-dgo-detail="1"] { display: block !important; }
  }
  @media (min-width: 901px) and (orientation: landscape) {
    #module-outlet .dgo-back-to-list { display: none !important; }
  }
  @media (max-width: 900px), (orientation: portrait) {
    #module-outlet .dgo-back-to-list { display: inline-flex !important; align-items: center; gap: .35rem; margin-block-end: .55rem; }
  }

  #module-outlet :where(tbody tr, .pf-row, .pf-list__item, .pf-md__row, .pf-dx__item, .pf-ap__item, .pf-corr__row) {
    cursor: pointer;
    scroll-margin-block: .75rem;
  }

  #module-outlet :where(tbody tr:focus-visible, .pf-row:focus-visible, .pf-list__item:focus-visible, .pf-md__row:focus-visible, .pf-dx__item:focus-visible, .pf-ap__item:focus-visible, .pf-corr__row:focus-visible) {
    outline: 3px solid color-mix(in srgb, var(--color-brand-primary, #05583b) 36%, transparent) !important;
    outline-offset: -3px !important;
  }

  #module-outlet [data-dgo-detail="1"] :where(.pf-empty, .dgo-empty, [data-state="empty"]) {
    min-height: 100% !important;
    display: grid !important;
    place-content: center !important;
    text-align: center !important;
  }
}
`;

function appendStyle() {
  if (typeof document === 'undefined') return;
  let style = document.getElementById(STYLE_ID);
  if (!style) {
    style = document.createElement('style');
    style.id = STYLE_ID;
    style.textContent = CSS;
  }
  // Move to the end so it wins over module styles appended during mount.
  document.head.appendChild(style);
}

function ensureBackButton(detail, workbench) {
  if (!detail || detail.querySelector?.(':scope > .dgo-back-to-list')) return;
  const btn = document.createElement('button');
  btn.type = 'button';
  btn.className = 'dgo-back-to-list dgo-btn dgo-btn--ghost';
  btn.textContent = 'Back to list';
  btn.addEventListener('click', () => { workbench.dataset.view = 'list'; });
  detail.insertBefore(btn, detail.firstChild || null);
}

function markWorkbench(workbench) {
  if (!workbench) return;
  if (workbench.dataset.dgoWorkbench !== '1') workbench.dataset.dgoWorkbench = '1';
  if (!workbench.dataset.view) workbench.dataset.view = 'list';

  const directChildren = Array.from(workbench.children || []);
  const detail = directChildren.find((child) => child.matches?.(DETAIL_SELECTORS)) || workbench.querySelector?.(`:scope > ${DETAIL_SELECTORS}`);
  if (detail) { detail.dataset.dgoDetail = '1'; ensureBackButton(detail, workbench); }

  const master = directChildren.find((child) => child !== detail && child.matches?.(MASTER_SELECTORS)) || directChildren.find((child) => child !== detail);
  if (master) master.dataset.dgoMaster = '1';

  workbench.querySelectorAll?.(DETAIL_SELECTORS).forEach((node) => { node.dataset.dgoDetail = '1'; ensureBackButton(node, workbench); });
  workbench.querySelectorAll?.(MASTER_SELECTORS).forEach((node) => {
    if (!node.closest?.('[data-dgo-detail="1"]')) node.dataset.dgoMaster = '1';
  });
}

function decorateRows(root) {
  root.querySelectorAll?.('tbody tr, .dgo-row, .dgo-card-row, .pf-row, .pf-list__item, .pf-md__row, .pf-md__card, .pf-dx__item, .pf-dx__card, .pf-ap__item, .pf-corr-card, .pf-corr__row').forEach((row) => {
    if (!row.hasAttribute('tabindex')) row.setAttribute('tabindex', '0');
    if (!row.hasAttribute('role')) row.setAttribute('role', 'option');
    if (!row.hasAttribute('aria-selected')) row.setAttribute('aria-selected', 'false');
  });
}

function decorate(root = document) {
  if (!root || !root.querySelectorAll) return;
  appendStyle();
  root.querySelectorAll(WORKBENCH_SELECTORS).forEach(markWorkbench);
  // If the root itself is the split container, include it too.
  if (root.matches?.(WORKBENCH_SELECTORS)) markWorkbench(root);
  decorateRows(root);
}

let observer = null;
function install() {
  if (typeof document === 'undefined') return;
  appendStyle();
  decorate(document);
  if (!observer) { observer = { disconnect(){} }; globalThis.Platform?.Bus?.on?.('platform:route:transition-end', () => { decorate(document.getElementById('module-outlet') || document); appendStyle(); }); }
}

export const WorkbenchPolish = { install, decorate, appendStyle };
if (typeof document !== 'undefined') install();
export default WorkbenchPolish;
