/**
 * OBSIDIAN / DGO Digital Ops — Runtime UX Guard
 * Responsiveness remediation: contained MutationObserver, idempotent DOM processing,
 * guarded table wrapping, fallback dedupe, selection dedupe and frame-bounded work.
 */
const UX_PATCH_ID = 'stage-m-r1-responsiveness-guard-v2';
const CFG = globalThis.__dgoResponsivenessConfig || {
  guardDebounceMs: 50, guardIdleDelayMs: 250, maxNodesPerGuardPass: 200, maxGuardPassesPerFrame: 2, enableFallbackInjection: true, enableTableWrapping: true
};
const PROCESSED = 'dgoProcessed';
const TABLE_WRAPPED = 'dgoTableWrapped';
const EMPTY_CREATED = 'dgoEmptyCreated';
const DETAIL_CREATED = 'dgoDetailCreated';

const INTERACTIVE_SELECTOR = [
  'button', 'a[href]', 'input', 'select', 'textarea',
  '[role="button"]', '[role="tab"]', '[data-action]', '[data-ref]', '[data-id]', '[data-key]',
  '.pf-row', '.pf-card', '.pf-list__item', '.pf-md__row', '.pf-dx__item', '.pf-ap__item',
  '.pf-corr-card', '.pf-bulk__item', '.dgo-q', '.dgo-card'
].join(',');
const SELECTABLE_SELECTOR = [
  '[data-selectable="true"]', '[role="option"]', 'tbody tr',
  '.dgo-row', '.dgo-card-row', '.pf-row', '.pf-list__item', '.pf-md__row', '.pf-md__card', '.pf-dx__item', '.pf-dx__card', '.pf-ap__item',
  '.pf-corr-card', '.pf-corr__row', '.pf-bulk__item', '.dgo-q'
].join(',');
const SELECTION_CONTAINER_SELECTOR = [
  '#module-outlet', 'main', 'section', 'article', '.pf-module', '.pf-card', '.dgo-master', '.dgo-detail', '.dgo-workspace',
  '.pf-list__split', '.pf-md__split', '.pf-corr__split', '.pf-table-wrap', '.pf-list__main', '.pf-list__detail'
].join(',');
const DETAIL_SELECTOR = '[data-region="detail"], [class*="detail"], [class*="preview"]';

let observer = null;
let scheduled = false;
let processing = false;
let queue = [];
let passesThisFrame = 0;
let frameResetScheduled = false;
const counters = globalThis.__dgoUxGuardCounters = globalThis.__dgoUxGuardCounters || {
  mutationCallbacks:0, nodesQueued:0, processed:0, tablesWrapped:0, emptyFallbacks:0, detailFallbacks:0, skipped:0, skippedSemantic:0, skippedDisabled:0
};

function emit(name, detail) { try { globalThis.Platform?.Bus?.emit?.(name, detail); } catch (_) {} }
function targetRoot() { return document.getElementById('module-outlet') || document.querySelector('main[slot="main"]') || document.body; }
function isEditable(el) { return !!el?.closest?.('input,textarea,select,[contenteditable="true"]'); }
function moduleRootOf(el) { return el?.closest?.('[id^="module-"], .pf-module, main, #module-outlet') || targetRoot(); }
function markDataset(el, key) { if (el?.dataset) el.dataset[key] = '1'; }
function wasMarked(el, key) { return el?.dataset?.[key] === '1'; }

function disconnect() { try { observer?.disconnect?.(); } catch (_) {} }
function reconnect() {
  const root = targetRoot();
  try { observer?.observe(root, { childList: true, subtree: true }); } catch (_) {}
}
function withObserverPaused(fn) {
  disconnect();
  try { return fn(); } finally { reconnect(); }
}

function markInteractive(el) {
  if (!el || wasMarked(el, PROCESSED)) { counters.skipped++; return; }
  if (el.matches?.('th, thead, tfoot, label, fieldset, legend, .pf-field, .pf-label')) { counters.skippedSemantic++; markDataset(el, PROCESSED); return; }
  if (el.matches?.('[disabled], [aria-disabled="true"]')) { counters.skippedDisabled++; markDataset(el, PROCESSED); return; }
  if (el.matches('button,a[href],input,select,textarea')) { markDataset(el, PROCESSED); return; }
  if (!el.hasAttribute('role') && (el.matches('[data-ref],[data-id],[data-key],.pf-card,.pf-list__item,.pf-md__row,.pf-dx__item,.pf-ap__item,.pf-corr-card,.pf-bulk__item,.dgo-q') || el.tagName === 'TR')) {
    el.setAttribute('role', 'button');
  }
  if (!el.hasAttribute('tabindex') && !el.closest('button,a,input,select,textarea')) el.setAttribute('tabindex', '0');
  el.classList.add('ux-interactive');
  markDataset(el, PROCESSED);
}

function wrapTable(table) {
  if (CFG.enableTableWrapping === false) return;
  if (!table || wasMarked(table, TABLE_WRAPPED) || table.closest('.pf-table-wrap,.ux-table-wrap')) return;
  const parent = table.parentNode;
  if (!parent) return;
  const wrapper = document.createElement('div');
  wrapper.className = 'ux-table-wrap pf-table-wrap';
  wrapper.dataset.dgoGuardOwned = '1';
  parent.insertBefore(wrapper, table);
  wrapper.appendChild(table);
  table.classList.add('ux-table-safe');
  markDataset(table, TABLE_WRAPPED);
  counters.tablesWrapped++;
}

function ensureFallbacks(root) {
  if (CFG.enableFallbackInjection === false) return;
  const outlet = targetRoot();
  const scope = root === document ? outlet : root;
  scope.querySelectorAll?.('[data-region="content"]').forEach((region) => {
    if (wasMarked(region, EMPTY_CREATED)) return;
    const hasMeaningful = region.querySelector(':scope > *:not(.pf-empty):not([hidden])');
    if (!hasMeaningful && region.textContent.trim().length === 0) {
      const empty = document.createElement('div');
      empty.className = 'pf-empty ux-empty-fallback';
      empty.dataset.dgoGuardOwned = '1';
      const title = document.createElement('div');
      title.className = 'pf-empty__title';
      title.textContent = 'No records to display';
      const message = document.createElement('p');
      message.textContent = 'This workspace is ready and has no visible records for the current view.';
      empty.append(title, message);
      region.appendChild(empty);
      markDataset(region, EMPTY_CREATED);
      counters.emptyFallbacks++;
    }
  });
  scope.querySelectorAll?.(DETAIL_SELECTOR).forEach((detail) => {
    if (wasMarked(detail, DETAIL_CREATED)) return;
    const hasMeaningful = detail.querySelector(':scope > *:not(.ux-detail-fallback)');
    if (!hasMeaningful && detail.textContent.trim().length === 0) {
      const fallback = document.createElement('div');
      fallback.className = 'pf-empty ux-detail-fallback';
      fallback.dataset.dgoGuardOwned = '1';
      const title = document.createElement('div');
      title.className = 'pf-empty__title';
      title.textContent = 'Select a record';
      const message = document.createElement('p');
      message.textContent = 'Details will appear here.';
      fallback.append(title, message);
      detail.appendChild(fallback);
      markDataset(detail, DETAIL_CREATED);
      counters.detailFallbacks++;
    }
    detail.classList.add('ux-detail-safe');
  });
}

function decorate(root = targetRoot()) {
  if (!root) return;
  withObserverPaused(() => {
    const scope = root.nodeType === 1 ? root : targetRoot();
    if (scope.matches?.(INTERACTIVE_SELECTOR)) markInteractive(scope);
    scope.querySelectorAll?.(INTERACTIVE_SELECTOR)?.forEach(markInteractive);
    if (scope.matches?.('table,.pf-table')) wrapTable(scope.matches('table') ? scope : scope.querySelector('table'));
    scope.querySelectorAll?.('table,.pf-table')?.forEach((t) => wrapTable(t.tagName === 'TABLE' ? t : t.querySelector('table')));
    ensureFallbacks(scope);
  });
}

function processQueue() {
  scheduled = false;
  if (processing) return;
  processing = true;
  passesThisFrame++;
  const batch = queue.splice(0, CFG.maxNodesPerGuardPass || 200);
  counters.processed += batch.length;
  try { batch.forEach((n) => { if (n && n.isConnected !== false) decorate(n); }); }
  finally { processing = false; }
  if (queue.length && passesThisFrame < (CFG.maxGuardPassesPerFrame || 2)) schedule();
  else if (queue.length) setTimeout(schedule, CFG.guardDebounceMs || 50);
}
function schedule() {
  if (scheduled) return;
  scheduled = true;
  if (!frameResetScheduled) {
    frameResetScheduled = true;
    requestAnimationFrame(() => { passesThisFrame = 0; frameResetScheduled = false; });
  }
  requestAnimationFrame(processQueue);
}
function enqueue(node) {
  if (!node || node.nodeType !== 1) return;
  queue.push(node);
  counters.nodesQueued++;
  if (queue.length > 1000) queue = queue.slice(-1000);
  schedule();
}

let selectedKey = null;
function isSelectionTarget(el) {
  if (!el || isEditable(el) || el.matches('[role="tab"],button,a[href],input,select,textarea')) return false;
  if (el.closest?.('[data-dgo-detail="1"]')) return false;
  if (el.matches?.(SELECTION_CONTAINER_SELECTOR) && !el.matches('tbody tr,.dgo-row,.dgo-card-row,.pf-row,.pf-list__item,.pf-md__row,.pf-md__card,.pf-dx__item,.pf-dx__card,.pf-ap__item,.pf-corr-card,.pf-corr__row,.pf-bulk__item,.dgo-q,[data-selectable="true"],[role="option"]')) return false;
  if (el.matches?.('.pf-card') && !el.matches?.('.pf-md__card,.pf-corr-card,.pf-dx__card,.dgo-card-row,[data-selectable="true"],[role="option"]')) return false;
  return !!el.matches?.(SELECTABLE_SELECTOR);
}
function showPortraitDetail(el) {
  const wb = el.closest?.('[data-dgo-workbench="1"],.dgo-workspace,.pf-list__split,.pf-md__split,.pf-corr__split,.pf-dx');
  if (!wb || !matchMedia('(max-width: 900px), (orientation: portrait)').matches) return;
  wb.dataset.view = 'detail';
}
function setSelected(el) {
  if (!isSelectionTarget(el)) return;
  const key = el.dataset.ref || el.dataset.id || el.dataset.key || el.textContent?.slice(0, 80) || '';
  if (key && selectedKey === key && el.classList.contains('is-selected')) return;
  selectedKey = key;
  const root = moduleRootOf(el);
  root.querySelectorAll?.('.is-selected,[aria-selected="true"][data-ux-selected="1"]')?.forEach((n) => {
    if (n !== el && !n.matches('[role="tab"]')) {
      n.classList.remove('is-selected');
      if (n.dataset.uxSelected === '1') n.setAttribute('aria-selected', 'false');
    }
  });
  el.classList.add('is-selected');
  el.dataset.uxSelected = '1';
  el.setAttribute('aria-selected', 'true');
  showPortraitDetail(el);
  emit('platform:ux:selected', { ref: el.dataset.ref || null, id: el.dataset.id || null, key: el.dataset.key || null });
}
function onClick(e) { const target = e.target?.closest?.(SELECTABLE_SELECTOR); if (target) setSelected(target); }
function onKeydown(e) {
  if (e.key !== 'Enter' && e.key !== ' ') return;
  const target = e.target?.closest?.('.ux-interactive,[role="button"],[role="tab"],[data-ref],[data-id],[data-key]');
  if (!target || target.matches('button,a[href],input,select,textarea')) return;
  e.preventDefault(); target.click();
}
function onResize() { enqueue(targetRoot()); }

function install() {
  if (document.documentElement.dataset.dgoGuardInstalled === UX_PATCH_ID) return;
  document.documentElement.dataset.dgoGuardInstalled = UX_PATCH_ID;
  document.addEventListener('click', onClick, true);
  document.addEventListener('keydown', onKeydown, true);
  window.addEventListener('resize', onResize, { passive: true });
  window.addEventListener('orientationchange', () => setTimeout(onResize, 150), { passive: true });
  observer = null; // M-R9.0: no continuous observer; decorate at route end only.
  globalThis.Platform?.Bus?.on?.('platform:route:transition-end', () => setTimeout(() => decorate(targetRoot()), 0));
  enqueue(targetRoot());
  setTimeout(() => enqueue(targetRoot()), CFG.guardIdleDelayMs || 250);
  emit('platform:ux:guard-installed', { patch: UX_PATCH_ID, observerTarget: '#module-outlet' });
}

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', install, { once: true });
else install();

export const RuntimeUxGuard = { install, decorate, counters, patchId: UX_PATCH_ID };
export default RuntimeUxGuard;
