/**
 * DGO Digital Ops - Entry & Authentication Logic
 * Integrated with Obsidian v4.2 Platform APIs
 */
import { Persona } from './persona-controller.js';
import { API } from './api.js';

const DGOEntry = {
  // ==========================================
  // BOOT SEQUENCE (optional entry experience)
  // ==========================================
  initBootSequence() {
    const fill = document.getElementById('progress-fill');
    const log = document.getElementById('telemetry-log');
    const shutter = document.getElementById('shutter');
    if (!fill || !log) return;

    // Check for existing session natively
    const session = Persona.getSession();
    const targetUrl = session ? 'index.html' : 'login.html';

    const bootSteps = [
      { msg: "> INITIALIZING E01 GATEWAY...", time: 300, progress: 15 },
      { msg: "> SYNCING ODATA CACHE...", time: 800, progress: 35 },
      { msg: "> VERIFYING DSU_KEY DIRECTORY...", time: 1400, progress: 60 },
      { msg: "> SECURING SUBSIDIARY ACTIONS...", time: 2100, progress: 85 },
      { msg: `> PLATFORM READY. ROUTING TO ${session ? 'WORKSPACE' : 'GATEWAY'}...`, time: 2600, progress: 100 }
    ];

    bootSteps.forEach(step => {
      setTimeout(() => {
        fill.style.width = `${step.progress}%`;
        const span = document.createElement('span');
        span.textContent = step.msg;
        log.appendChild(span);
        if (log.children.length > 4) log.removeChild(log.firstChild);
        
        if (step.progress === 100) {
          setTimeout(() => {
            shutter.classList.add('shutter-active');
            setTimeout(() => window.location.href = targetUrl, 600);
          }, 400);
        }
      }, step.time);
    });
  },

  // ==========================================
  // GATEWAY / LOGIN (login.html)
  // ==========================================
  initGateway() {
    const phase1 = document.getElementById('phase-1');
    const phase2 = document.getElementById('phase-2');
    const emailInput = document.getElementById('email-input');
    const reqBtn = document.getElementById('btn-request-otp');
    const verifyBtn = document.getElementById('btn-verify-otp');
    const otpInputs = document.querySelectorAll('.entry-otp-input');
    const displayEmail = document.getElementById('display-email');
    
    if (!phase1 || !phase2) return;

    let userEmail = "";

    // STEP 1: REQUEST OTP
    reqBtn.addEventListener('click', async () => {
      const email = emailInput.value.trim();
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

      if (!emailRegex.test(email)) {
        emailInput.parentElement.classList.add('is-error');
        setTimeout(() => emailInput.parentElement.classList.remove('is-error'), 400);
        return;
      }

      reqBtn.classList.add('is-loading');
      
      const res = await API.callAPI('OTP_GENERATE', {
        action: 'generate',
        identifier: email,
        purpose: 'LOGIN'
      });

      reqBtn.classList.remove('is-loading');

      if (res.ok) {
        userEmail = email;
        displayEmail.textContent = userEmail;
        phase1.classList.remove('is-active');
        phase2.classList.add('is-active');
        otpInputs[0].focus();
      } else {
        emailInput.parentElement.classList.add('is-error');
        console.error("OTP Generation Failed:", res.errors);
      }
    });

    // OTP Input Matrix Logic
    otpInputs.forEach((input, index) => {
      input.addEventListener('input', (e) => {
        e.target.value = e.target.value.replace(/[^0-9]/g, '');
        if (e.target.value && index < otpInputs.length - 1) otpInputs[index + 1].focus();
      });

      input.addEventListener('keydown', (e) => {
        if (e.key === 'Backspace' && !e.target.value && index > 0) {
          otpInputs[index - 1].focus();
          otpInputs[index - 1].value = ''; 
        }
        if (e.key === 'Enter') verifyBtn.click();
      });

      input.addEventListener('paste', (e) => {
        e.preventDefault();
        const pasteData = e.clipboardData.getData('text').replace(/[^0-9]/g, '').slice(0, 6);
        pasteData.split('').forEach((char, i) => {
          if (otpInputs[index + i]) {
            otpInputs[index + i].value = char;
            otpInputs[index + i].focus();
          }
        });
      });
    });

    // STEP 2: VERIFY OTP
    verifyBtn.addEventListener('click', async () => {
      const code = Array.from(otpInputs).map(i => i.value).join('');
      const otpGroup = document.querySelector('.entry-otp-group');

      if (code.length < 6) {
        otpGroup.classList.add('is-error');
        setTimeout(() => otpGroup.classList.remove('is-error'), 400);
        return;
      }

      verifyBtn.classList.add('is-loading');

      const res = await API.callAPI('OTP_VERIFY', {
        action: 'verify',
        identifier: userEmail,
        otp_code: code
      });

      if (res.ok && res.data && res.data.valid !== false) {
        const authUser = res.data.user || res.data.profile || res.data || {};
        Persona.setSession(res.data.token || res.data.accessToken || 'dgo-secure-token', {
          ...authUser,
          email: authUser.email || authUser.userEmail || userEmail,
          fullName: authUser.fullName || authUser.displayName || authUser.name || res.data.fullName || 'Operator',
          dsuKey: authUser.dsuKey || authUser.DSU_KEY || authUser.directorate || authUser.department || res.data.dsuKey || 'DEFAULT',
          department: authUser.department || authUser.directorate || authUser.dsuKey || res.data.dsuKey || 'DEFAULT',
          jobTitle: authUser.jobTitle || authUser.title || '',
          role: authUser.role || '',
          authenticatedAt: new Date().toISOString()
        });
        try { await Persona.hydrateProfileFromReferenceData(userEmail, { silent: true }); } catch (_) {}

        verifyBtn.classList.remove('is-loading');
        const btnText = document.createElement('span');
        btnText.className = 'btn-text';
        btnText.textContent = 'Verified ✓';
        verifyBtn.replaceChildren(btnText);
        verifyBtn.style.background = 'var(--entry-glow-accent)';
        
        setTimeout(() => {
          document.getElementById('shutter').classList.add('shutter-active');
          setTimeout(() => window.location.href = 'index.html', 600);
        }, 500);

      } else {
        verifyBtn.classList.remove('is-loading');
        otpGroup.classList.add('is-error');
        otpInputs.forEach(i => i.value = '');
        otpInputs[0].focus();
        setTimeout(() => otpGroup.classList.remove('is-error'), 400);
      }
    });
  }
};

document.addEventListener('DOMContentLoaded', () => {
  DGOEntry.initBootSequence();
  DGOEntry.initGateway();
});
