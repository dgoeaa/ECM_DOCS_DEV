/** OBSIDIAN v4.3 — bus.js · pub/sub event hub with responsiveness counters and conservative dedupe. */
const listeners = new Map(); // event -> Set<fn>
const recent = new Map();
const DEDUPE_WINDOW_MS = 100;
const DEDUPE_EVENTS = /^(platform:ux:selected|platform:nav:changed|platform:nav:rebuilt|context:reference:changed|reference:change|platform:state:changed)$/;

function counters() {
  return globalThis.__dgoPerfCounters = globalThis.__dgoPerfCounters || { bus:Object.create(null), deduped:Object.create(null) };
}
function stable(value) {
  if (value == null) return String(value);
  if (typeof value !== 'object') return String(value);
  try { return JSON.stringify(value, (k, v) => (k === 'ts' || k === 'timestamp') ? undefined : v); }
  catch (_) { return '[unserializable]'; }
}

export const Bus = {
  on(event, handler) {
    if (!listeners.has(event)) listeners.set(event, new Set());
    listeners.get(event).add(handler);
    return () => Bus.off(event, handler);
  },
  once(event, handler) {
    const off = Bus.on(event, (d) => { off(); handler(d); });
    return off;
  },
  off(event, handler) { const s = listeners.get(event); if (s) s.delete(handler); },
  emit(event, detail) {
    const C = counters();
    C.bus[event] = (C.bus[event] || 0) + 1;
    if (DEDUPE_EVENTS.test(event)) {
      const now = performance.now ? performance.now() : Date.now();
      const key = event + ':' + stable(detail);
      const last = recent.get(key) || 0;
      if (now - last < DEDUPE_WINDOW_MS) {
        C.deduped[event] = (C.deduped[event] || 0) + 1;
        return detail;
      }
      recent.set(key, now);
      if (recent.size > 500) {
        const cutoff = now - DEDUPE_WINDOW_MS * 10;
        for (const [k, t] of recent) if (t < cutoff) recent.delete(k);
      }
    }
    const s = listeners.get(event);
    if (s) for (const fn of [...s]) { try { fn(detail, event); } catch (e) { reportBusError(event, e); } }
    return detail;
  },
  diagnostics() {
    const out = {};
    for (const [event, set] of listeners) out[event] = set.size;
    return { listeners: out, counters: counters() };
  }
};
function reportBusError(event, e) {
  const L = globalThis.Platform && globalThis.Platform.Log;
  if (L) L.error('bus.handler-threw', { event, message: String(e && e.message || e) });
}
export default Bus;
