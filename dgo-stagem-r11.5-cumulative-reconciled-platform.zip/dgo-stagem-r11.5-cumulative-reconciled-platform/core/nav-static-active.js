/** Stage M-R7 static navigation activation and drawer close. */
function sync(){
  const current=(location.hash||'#/home').replace(/^#\/?/,'').split('/')[0]||'home';
  document.querySelectorAll('#dgo-static-nav a[data-route]').forEach(a=>{
    const on=a.dataset.route===current;
    if(on)a.setAttribute('aria-current','page'); else a.removeAttribute('aria-current');
  });
}
function install(){
  if(typeof document==='undefined'||document.__dgoStaticNavActive)return;
  document.__dgoStaticNavActive=true;
  document.addEventListener('click',ev=>{
    const a=ev.target.closest?.('#dgo-static-nav a[data-route]');
    if(!a)return;
    document.dispatchEvent(new CustomEvent('dgo:navigation-selected'));
    document.querySelectorAll('pf-app-shell').forEach(s=>s.removeAttribute('nav-open'));
    setTimeout(sync,0);
  },true);
  window.addEventListener('hashchange',sync);
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',sync,{once:true}); else sync();
  setTimeout(sync,150); setTimeout(sync,700);
}
install();
export default { install, sync };
