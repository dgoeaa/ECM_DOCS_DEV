/** Stage M-R10.5 — Optimized Core API Engine & Outbox Agent.
 * Adds read request de-duplication, short-lived read caching, bounded outbox concurrency,
 * safe response parsing and telemetry while preserving all endpoint contracts. */
import { Endpoints } from '../config/endpoints.config.js';
import { Idempotency } from './idempotency.js';
import { Storage } from './storage.js';
import { Bus } from './bus.js';
import { FeatureFlags } from '../config/feature-flags.config.js';
import { PerformanceConfig } from '../config/performance.config.js';
import { stableKey, recordApi } from './performance.js';

const DEFAULT_TIMEOUT_MS = 45000;
const OUTBOX_KEY = 'obsidian.sync_outbox';
const DEADLETTER_KEY = 'obsidian.outbox_deadletter';
const MAX_ATTEMPTS = 8;
const WRITE_FLOWS = new Set(['SINGLE_ASSIGNMENT','BULK_ASSIGNMENT','BULK_ASSIGNMENT_DIRECT','EMAIL_RELATED_TASK','DYNAMIC_GLOBAL_ACTIONS','SUBSIDIARY_ACTIONS']);
const ENV_PROFILES = { dev: {}, test: {}, prod: {} };
const READ_CACHE = new Map();
const INFLIGHT = new Map();

function detectEnvironment() {
  if (typeof window === 'undefined') return 'prod';
  try {
    const forced = FeatureFlags.endpointOverrides === true ? localStorage.getItem('obsidian.env_profile') : '';
    if (forced) return forced;
    const h = (location.hostname || '').toLowerCase();
    if (h === 'localhost' || h === '127.0.0.1' || h.endsWith('.local')) return 'dev';
    if (h.includes('staging') || h.includes('test') || h.includes('uat')) return 'test';
  } catch (_) {}
  return 'prod';
}
const ACTIVE_ENV = detectEnvironment();

function resolveUrl(endpointKey, defaultUrl) {
  try {
    if (FeatureFlags.endpointOverrides === true) {
      const override = localStorage.getItem('obsidian.endpoint.' + endpointKey);
      if (override && /^https?:\/\//.test(override)) {
        Bus.emit('audit:endpoint-override-used', { endpointKey, ts: new Date().toISOString() });
        return override;
      }
    }
  } catch (_) {}
  const profile = ENV_PROFILES[ACTIVE_ENV];
  if (profile && profile[endpointKey]) return profile[endpointKey];
  return defaultUrl;
}

function uuid() {
  if (globalThis.crypto && crypto.randomUUID) return crypto.randomUUID();
  return 'cid-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
}
function safeParse(text) {
  if (!text) return null;
  try { return JSON.parse(text); }
  catch (_) { return { ok:false, errors:[{ code:'PARSE_ERROR', message:'Service returned non-JSON response.' }], raw: text.slice(0, 1000) }; }
}
function deriveData(body) {
  if (!body) return null;
  if (body.data !== undefined && body.data !== null) {
    let d = body.data;
    if (typeof d === 'string') {
      const t = d.trim();
      if (t.startsWith('{') || t.startsWith('[')) { try { d = JSON.parse(t); } catch (_) {} }
    }
    return d;
  }
  if (typeof body === 'object') {
    const d = {}; const omit = new Set(['ok','success','status','statusCode','errors','meta','correlationId']);
    for (const [k, v] of Object.entries(body)) if (!omit.has(k)) d[k] = v;
    if (Object.keys(d).length) return d;
  }
  return null;
}
function normalizeResponse(body, headers, durationMs, correlationId, httpStatus, endpointKey) {
  const httpFailed = !!(httpStatus && httpStatus >= 400);
  if (body && typeof body === 'object' && 'ok' in body) {
    const status = httpStatus || (body.status && Number(body.status.http)) || (body.ok ? 200 : 500);
    const realOk = !!body.ok && !httpFailed;
    return { ok: realOk, kind: realOk ? 'ok' : 'server', endpointKey, errorKind: realOk ? undefined : (body.errors && body.errors[0]?.kind) || 'INTERNAL_ERROR', status, data: deriveData(body), errors: body.errors || [], body, headers, durationMs, correlationId };
  }
  return { ok: !httpFailed, kind: httpFailed ? 'server' : 'ok', endpointKey, status: httpStatus || 200, data: deriveData(body), errors: [], body, headers, durationMs, correlationId };
}
function cacheKey(endpointKey, payload) { return endpointKey + '::' + stableKey(payload || {}); }
function cacheGet(key) {
  const hit = READ_CACHE.get(key);
  if (!hit) return null;
  if (Date.now() - hit.ts > PerformanceConfig.api.readCacheTtlMs) { READ_CACHE.delete(key); return null; }
  return { ...hit.value, cacheHit: true, durationMs: 0 };
}
function cachePut(key, value) {
  if (!value || !value.ok) return;
  READ_CACHE.set(key, { ts: Date.now(), value });
  while (READ_CACHE.size > PerformanceConfig.api.maxReadCacheEntries) READ_CACHE.delete(READ_CACHE.keys().next().value);
}
function clearReadCache() { READ_CACHE.clear(); }

export const Outbox = {
  _processing: null,
  get() { return Storage.get(OUTBOX_KEY, []); },
  save(queue) { Storage.set(OUTBOX_KEY, queue); Bus.emit('platform:outbox:changed', { queueLength: Array.isArray(queue) ? queue.length : 0 }); },
  getDead() { return Storage.get(DEADLETTER_KEY, []); },
  saveDead(queue) { Storage.set(DEADLETTER_KEY, queue); Bus.emit('platform:outbox:changed', { deadLength: Array.isArray(queue) ? queue.length : 0 }); },
  push(endpointKey, payload) {
    const queue = this.get();
    const idempotencyKey = payload?.idempotencyKey || Idempotency.normalizeInput({ endpointKey, payload, opts: {} }).idempotencyKey;
    const existing = queue.find((item) => item.endpointKey === endpointKey && item.payload && item.payload.idempotencyKey === idempotencyKey);
    if (existing) return { ok:true, outboxId:existing.id, status:'QUEUED_LOCAL' };
    const txId = `TX-${Date.now()}-${Math.random().toString(36).substring(2,9).toUpperCase()}`;
    queue.push({ id:txId, endpointKey, payload:{ ...(payload || {}), idempotencyKey }, timestamp:new Date().toISOString(), attempts:0, nextRetry:Date.now() });
    this.save(queue); this.process(); recordApi({ ok:true, queued:true, endpointKey });
    return { ok:true, outboxId:txId, status:'QUEUED_LOCAL' };
  },
  metrics() { const queued=this.get(); const dead=this.getDead(); const dueNow=queued.filter((item)=>!item.nextRetry || item.nextRetry<=Date.now()).length; return { queued:queued.length, dueNow, dead:dead.length, maxAttempts:MAX_ATTEMPTS, concurrency:PerformanceConfig.api.maxOutboxConcurrency }; },
  retryDead(id) {
    const dead=this.get(); const selected=id?dead.filter((item)=>item.id===id):dead;
    if (!selected.length) return { ok:false, moved:0 };
    const now=Date.now(); const retryItems=selected.map((item)=>({ id:item.id, endpointKey:item.endpointKey, payload:item.payload||{}, timestamp:item.timestamp||new Date().toISOString(), attempts:0, nextRetry:now, retryOf:item.id }));
    this.save(this.get().concat(retryItems)); this.saveDead(id?dead.filter((item)=>item.id!==id):[]); this.process(); return { ok:true, moved:retryItems.length };
  },
  discardDead(id) { const dead=this.getDead(); const next=id?dead.filter((item)=>item.id!==id):[]; const removed=dead.length-next.length; this.saveDead(next); return { ok:true, removed }; },
  process() { if (this._processing) return this._processing; const p=this._processOnce().catch(()=>{}).finally(()=>{ if (this._processing===p) this._processing=null; }); this._processing=p; return p; },
  async _deliver(item) {
    const ep = Endpoints[item.endpointKey]; const url = resolveUrl(item.endpointKey, ep ? ep.url : '');
    if (!url) throw new Error('Endpoint URL is not configured.');
    const controller = new AbortController(); const timer=setTimeout(()=>controller.abort('timeout'), 20000);
    try {
      const response = await fetch(url, { method: ep.method || 'POST', headers:{ ...ep.headers, 'Content-Type':'application/json', 'X-Correlation-ID':item.id, 'X-Idempotency-Key':item.payload.idempotencyKey || item.id }, body:JSON.stringify(item.payload), signal:controller.signal });
      const body = safeParse(await response.text());
      let logicalOk = true;
      if (body && typeof body === 'object') { if ('ok' in body && !body.ok) logicalOk=false; if ('success' in body && !body.success) logicalOk=false; }
      if (response.ok && logicalOk) return { ok:true, body };
      throw new Error((body && body.errors && body.errors[0]?.message) || (body && body.message) || ('Server returned status ' + response.status));
    } finally { clearTimeout(timer); }
  },
  async _processOnce() {
    if (typeof navigator !== 'undefined' && !navigator.onLine) return;
    let queue = this.get(); if (!queue.length) return;
    const due = queue.filter((item)=>!item.nextRetry || item.nextRetry<=Date.now()).slice(0, PerformanceConfig.api.maxOutboxConcurrency);
    await Promise.all(due.map(async (item) => {
      try {
        await this._deliver(item);
        this.save(this.get().filter((q)=>q.id!==item.id));
        Bus.emit('platform:outbox:delivered', { endpointKey:item.endpointKey, id:item.id });
      } catch (err) {
        item.attempts++;
        if (item.attempts >= MAX_ATTEMPTS) {
          this.save(this.get().filter((q)=>q.id!==item.id));
          const dead=this.getDead(); dead.push({ ...item, error:err.message, failedAt:new Date().toISOString() }); this.saveDead(dead);
          Bus.emit('platform:outbox:deadletter', { endpointKey:item.endpointKey, id:item.id, error:err.message });
        } else {
          item.nextRetry = Date.now() + Math.min(1000 * Math.pow(2, item.attempts), 7200000);
          const current=this.get(); const target=current.find((q)=>q.id===item.id);
          if (target) { target.attempts=item.attempts; target.nextRetry=item.nextRetry; this.save(current); }
        }
      }
    }));
    if (this.get().some((item)=>!item.nextRetry || item.nextRetry<=Date.now())) setTimeout(()=>this.process(), 0);
  }
};
if (typeof window !== 'undefined') window.addEventListener('online', () => Outbox.process());

async function directFetch(endpointKey, payload, opts, correlationId, t0) {
  const ep = Endpoints[endpointKey];
  const elapsed = () => Math.round(((globalThis.performance && performance.now()) || Date.now()) - t0);
  if (!ep) return { ok:false, kind:'config', endpointKey, status:0, errors:[{ code:'UNKNOWN_ENDPOINT', message:'Unknown endpoint' }] };
  const url = resolveUrl(endpointKey, ep.url);
  const controller = new AbortController(); const timer = setTimeout(()=>controller.abort('timeout'), opts.timeoutMs || ep.timeoutMs || DEFAULT_TIMEOUT_MS);
  try {
    const response = await fetch(url, { method:ep.method || 'POST', headers:{ ...ep.headers, 'X-Correlation-ID':correlationId }, body:JSON.stringify(payload), signal:controller.signal });
    const text = await response.text(); const body = safeParse(text); const headers = {}; response.headers.forEach((v,k)=>{ headers[k]=v; });
    return normalizeResponse(body, headers, elapsed(), correlationId, response.status, endpointKey);
  } catch (err) {
    return { ok:false, kind:'network', endpointKey, status:0, errors:[{ code:'FETCH_ERROR', message:err.message }], durationMs:elapsed(), correlationId };
  } finally { clearTimeout(timer); }
}

export async function callAPI(endpointKey, payload = {}, opts = {}) {
  const isWrite = WRITE_FLOWS.has(endpointKey);
  const isOnline = typeof navigator !== 'undefined' && navigator.onLine;
  if (isWrite && !opts.forceDirect) {
    const idempotencyKey = payload.idempotencyKey || opts.idempotencyKey || Idempotency.normalizeInput({ endpointKey, payload, opts }).idempotencyKey;
    const finalPayload = { ...payload, idempotencyKey };
    clearReadCache();
    if (isOnline) {
      const directResponse = await callAPI(endpointKey, finalPayload, { ...opts, forceDirect:true });
      if (directResponse.ok) return directResponse;
      if (directResponse.kind === 'network' || directResponse.status === 503 || directResponse.status === 504 || directResponse.status === 0) {
        const outboxRef = Outbox.push(endpointKey, finalPayload);
        return { ok:true, outboxId:outboxRef.outboxId, status:'QUEUED_LOCAL', warning:'Action queued locally due to connection error.' };
      }
      return directResponse;
    }
    return Outbox.push(endpointKey, finalPayload);
  }

  const correlationId = opts.correlationId || uuid();
  const t0 = (globalThis.performance && performance.now()) || Date.now();
  const key = !isWrite ? cacheKey(endpointKey, payload) : null;
  if (!isWrite && !opts.noCache) {
    const hit = cacheGet(key);
    if (hit) { hit.endpointKey = endpointKey; recordApi(hit); return hit; }
    if (PerformanceConfig.api.inflightDedupe && INFLIGHT.has(key)) {
      const res = await INFLIGHT.get(key);
      const clone = { ...res, inflightHit:true, durationMs:0 };
      recordApi(clone); return clone;
    }
  }
  const p = directFetch(endpointKey, payload, opts, correlationId, t0).then((res)=>{ if (!isWrite && !opts.noCache) cachePut(key, res); recordApi(res); return res; }).finally(()=>{ if (key) INFLIGHT.delete(key); });
  if (!isWrite && key) INFLIGHT.set(key, p);
  return p;
}

export const API = { callAPI, Outbox, clearReadCache, getEnvironment: () => ACTIVE_ENV, cacheStats: () => ({ readCacheEntries: READ_CACHE.size, inflight: INFLIGHT.size }) };
export default API;
