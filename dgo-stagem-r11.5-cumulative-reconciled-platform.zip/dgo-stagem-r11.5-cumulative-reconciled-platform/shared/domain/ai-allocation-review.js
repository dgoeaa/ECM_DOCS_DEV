/** Phase 9 — AI allocation review-before-commit primitives. */
export function createAllocationReview({ recommendation = {}, source = 'ai', reviewer = '', ref = '', now = new Date() } = {}) {
  return Object.freeze({
    id: `AI-ALLOC-${Date.now()}`,
    ref: ref || recommendation.referenceId || recommendation.ref || '',
    source,
    reviewer,
    status: 'pending-human-review',
    requiresHumanApproval: true,
    recommendation: { ...recommendation },
    createdAt: new Date(now).toISOString()
  });
}
export function approveAllocationReview(review, approver = '', now = new Date()) {
  if (!review || review.requiresHumanApproval !== true) throw new Error('Allocation review requires a human-review object.');
  return Object.freeze({ ...review, status: 'approved-for-commit', approver, approvedAt: new Date(now).toISOString() });
}
export function rejectAllocationReview(review, reviewer = '', reason = '', now = new Date()) {
  return Object.freeze({ ...review, status: 'rejected', reviewer, reason, rejectedAt: new Date(now).toISOString() });
}
export default { createAllocationReview, approveAllocationReview, rejectAllocationReview };
