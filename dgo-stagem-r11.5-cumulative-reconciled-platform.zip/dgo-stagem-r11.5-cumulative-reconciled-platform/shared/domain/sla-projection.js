import { SlaConfig } from '../../config/sla.config.js';
/** Platform Coherence Phase 3 — canonical SLA projection domain.
 * Centralizes overdue/due-soon/on-track/unknown classification for dashboards, FastTrack,
 * Ackflow metrics, HUD meters, reports, and shared rendering helpers. */
const DEFAULT_DUE_SOON_HOURS = 48;
const DAY_MS = 24 * 60 * 60 * 1000;

export function businessDateKey(date = new Date()) { return new Date(date).toISOString().slice(0, 10); }
export function isBusinessDay(date = new Date(), config = SlaConfig) {
  const d = new Date(date);
  const day = d.getDay();
  return (config.workingDays || [1,2,3,4,5]).includes(day) && !(config.holidays || []).includes(businessDateKey(d));
}
export function addBusinessDaysISO(days = 1, from = new Date(), config = SlaConfig) {
  const d = new Date(from);
  let remaining = Math.max(0, Number(days) || 0);
  while (remaining > 0) {
    d.setDate(d.getDate() + 1);
    if (isBusinessDay(d, config)) remaining -= 1;
  }
  d.setHours(config.workEndHour || 16, 0, 0, 0);
  return d.toISOString().slice(0, 10);
}
export function activeSlaConfig() { return SlaConfig; }

export const SLA_KEYS = Object.freeze(['overdue', 'dueSoon', 'onTrack', 'unknown']);

export function extractDueDate(record = {}) {
  return record.dueDate || record.DueDate || record.taskDue || record.taskDueDate || record.TaskDueDate ||
    record.TaskDue || record.deadline || record.Deadline || record.SLA_Due || record.ackDue || record.AcknowledgementDueBy || '';
}

export function extractStartDate(record = {}) {
  return record.ts || record.createdAt || record.Created || record.receivedAt || record.date || record.StartDate || record.startDate || '';
}

export function isTerminalForSla(record = {}) {
  return /closed|archived|cold-archived|complete|completed|approved|dispatched|acknowledged|resolved/i
    .test(String(record.status || record.Status || ''));
}

export function parseDateOrNull(value) {
  if (!value) return null;
  const ms = Date.parse(value);
  return Number.isFinite(ms) ? ms : null;
}

function fromKey(key, extra = {}) {
  const cls = key === 'overdue' ? 'action' : key === 'dueSoon' ? 'pending' : key === 'onTrack' ? 'replied' : 'archived';
  const tone = key === 'overdue' ? 'danger' : key === 'dueSoon' ? 'warning' : key === 'onTrack' ? 'success' : 'neutral';
  return { key, cls, tone, ...extra };
}

export function classifyRecordSla(record = {}, { now = Date.now(), dueSoonHours = SlaConfig.dueSoonHours || DEFAULT_DUE_SOON_HOURS } = {}) {
  if (!record || typeof record !== 'object') return fromKey('unknown', { reason: 'missing-record' });
  if (isTerminalForSla(record)) return fromKey('onTrack', { reason: 'terminal-status' });

  const dueRaw = extractDueDate(record);
  const dueMs = parseDateOrNull(dueRaw);
  if (dueRaw && dueMs == null) return fromKey('unknown', { reason: 'malformed-due-date', dueRaw });
  if (dueMs != null) {
    const delta = dueMs - now;
    if (delta < 0) return fromKey('overdue', { dueAt: dueRaw, deltaMs: delta });
    if (delta <= dueSoonHours * 60 * 60 * 1000) return fromKey('dueSoon', { dueAt: dueRaw, deltaMs: delta });
    return fromKey('onTrack', { dueAt: dueRaw, deltaMs: delta });
  }

  const startRaw = extractStartDate(record);
  const startMs = parseDateOrNull(startRaw);
  if (startRaw && startMs == null) return fromKey('unknown', { reason: 'malformed-start-date', startRaw });
  const S = globalThis.Platform && globalThis.Platform.SLA;
  if (S && typeof S.evaluate === 'function' && startMs != null) {
    const evaluated = S.evaluate(startRaw, record.priority || record.Priority);
    if (evaluated.state === 'breached') return fromKey('overdue', { engine: evaluated });
    if (evaluated.state === 'due-soon') return fromKey('dueSoon', { engine: evaluated });
    return fromKey('onTrack', { engine: evaluated });
  }
  return fromKey('unknown', { reason: 'no-date' });
}

export function buildSlaBoard(records = [], opts = {}) {
  const counts = { overdue: 0, dueSoon: 0, onTrack: 0, unknown: 0 };
  const items = (records || []).map((record) => {
    const _sla = classifyRecordSla(record, opts);
    if (counts[_sla.key] == null) counts.unknown += 1; else counts[_sla.key] += 1;
    return { ...record, _sla };
  });
  return { items, counts, total: items.length };
}

export function computeSlaCompliance(records = [], opts = {}) {
  const board = buildSlaBoard(records, opts);
  const measured = board.counts.overdue + board.counts.dueSoon + board.counts.onTrack;
  if (!measured) return null;
  return Math.round(((board.counts.dueSoon + board.counts.onTrack) / measured) * 100);
}

export function renderSlaMeterModel(recordOrValue, opts = {}) {
  if (typeof recordOrValue === 'number') {
    const pct = Math.max(0, Math.min(100, Math.round(recordOrValue)));
    return { pct, key: pct < 35 ? 'overdue' : pct < 70 ? 'dueSoon' : 'onTrack', label: pct < 35 ? 'At risk' : pct < 70 ? 'Due soon' : 'On track' };
  }
  const classified = classifyRecordSla(recordOrValue || {}, opts);
  const dueMs = parseDateOrNull(extractDueDate(recordOrValue || {}));
  let pct = classified.key === 'overdue' ? 15 : classified.key === 'dueSoon' ? 55 : classified.key === 'onTrack' ? 90 : 0;
  if (dueMs != null && classified.key !== 'unknown') {
    const startMs = parseDateOrNull(extractStartDate(recordOrValue || {})) || (Date.now() - DAY_MS);
    const span = Math.max(1, dueMs - startMs);
    const remaining = Math.max(0, dueMs - Date.now());
    pct = Math.max(0, Math.min(100, Math.round((remaining / span) * 100)));
  }
  const label = classified.key === 'overdue' ? 'Overdue' : classified.key === 'dueSoon' ? 'Due soon' : classified.key === 'onTrack' ? 'On track' : 'Unknown';
  return { pct, key: classified.key, label, cls: classified.cls, tone: classified.tone, classified };
}

export function buildSlaCounts(records = [], opts = {}) { return buildSlaBoard(records, opts).counts; }
export function buildSlaMetric(records = [], opts = {}) {
  const value = computeSlaCompliance(records, opts);
  return { value, label: value == null ? 'N/A' : `${value}%`, tone: value == null ? 'neutral' : value >= 90 ? 'success' : value >= 70 ? 'warning' : 'danger', counts: buildSlaCounts(records, opts) };
}
export function buildSlaMeterModel(recordOrValue, opts = {}) { return renderSlaMeterModel(recordOrValue, opts); }
export default { extractDueDate, extractStartDate, isTerminalForSla, businessDateKey, isBusinessDay, addBusinessDaysISO, activeSlaConfig, classifyRecordSla, buildSlaBoard, buildSlaCounts, computeSlaCompliance, buildSlaMetric, renderSlaMeterModel, buildSlaMeterModel };
