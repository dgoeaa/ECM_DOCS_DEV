/** Append-only registry movement domain keyed by reference. */
const KEY_PREFIX = 'movement.';
function storage() { return globalThis.Platform?.Storage; }
function persona() {
  const P = globalThis.Platform?.Persona;
  const prof = P?.profile?.() || {};
  return prof.fullName || prof.name || prof.email || P?.current?.() || 'web-ops';
}
export function movementStorageKey(referenceId) { return `${KEY_PREFIX}${String(referenceId || '').trim()}`; }
export function normalizeMovement(raw = {}, index = 0) {
  const r = raw && typeof raw === 'object' ? raw : {};
  const referenceId = String(r.referenceId || r.ref || r.__ref || '').trim();
  return Object.freeze({
    id: r.id || `MOV-${referenceId || 'REF'}-${Date.now()}-${index + 1}`,
    referenceId,
    action: String(r.action || r.status || 'MOVED').trim().toUpperCase(),
    from: r.from || r.fromDsu || r.previous || '',
    to: r.to || r.toDsu || r.routeTo || r.target || '',
    note: String(r.note || r.text || r.comments || '').trim(),
    by: r.by || r.author || persona(),
    timestamp: r.timestamp || r.ts || new Date().toISOString(),
    correlationId: r.correlationId || '',
    source: r.source || 'client'
  });
}
export function loadMovements(referenceId, store = storage()) {
  const list = store?.get?.(movementStorageKey(referenceId), []) || [];
  return Array.isArray(list) ? list.map((m, i) => normalizeMovement(m, i)) : [];
}
export function saveMovements(referenceId, movements, store = storage()) {
  if (!store?.set) return false;
  return store.set(movementStorageKey(referenceId), Array.isArray(movements) ? movements : []);
}
export function appendMovement(record = {}, store = storage()) {
  const referenceId = String(record.referenceId || record.ref || record.__ref || '').trim();
  if (!referenceId) return { ok: false, message: 'Movement requires a reference id.' };
  const current = loadMovements(referenceId, store);
  const movement = normalizeMovement(record, current.length);
  const next = current.concat(movement);
  saveMovements(referenceId, next, store);
  globalThis.Platform?.Bus?.emit?.('audit:movement-appended', movement);
  return { ok: true, movement, movements: next };
}
export function summarizeMovements(movements = []) {
  const list = Array.isArray(movements) ? movements : [];
  const last = list.length ? list[list.length - 1] : null;
  return Object.freeze({ total: list.length, lastAction: last?.action || 'none', lastAt: last?.timestamp || '', lastTo: last?.to || '' });
}
export default { movementStorageKey, normalizeMovement, loadMovements, saveMovements, appendMovement, summarizeMovements };
