/**
 * Phase 11 — Browser runtime smoke execution plan.
 * Produces deterministic browser-level route, workspace, and dry-run interaction checks.
 */
const DEFAULT_ROUTES = Object.freeze([
  'home', 'ops-hub', 'registry', 'response-tracking', 'single-item-ops', 'bulk-assignment',
  'correspondence', 'approvals', 'executive', 'reports', 'diagnostics', 'settings', 'lookup'
]);
const DEFAULT_DRY_RUNS = Object.freeze([
  { id: 'single-assignment', module: 'single-item-ops', label: 'Single assignment review-before-commit', expected: 'opens confirmation before workflow write' },
  { id: 'bulk-assignment', module: 'bulk-assignment', label: 'Bulk assignment preview', expected: 'requires selected records and signed confirmation' },
  { id: 'executive-matrix-open', module: 'executive', label: 'Executive matrix open action', expected: 'deep-links into response tracking' },
  { id: 'diagnostics-smoke', module: 'diagnostics', label: 'Diagnostics smoke panel', expected: 'reports runtime readiness without write side effects' }
]);
function safeListModules(platform) {
  try { return platform?.Modules?.list?.() || []; } catch (_) { return []; }
}
function routeOk(route, modules) { return modules.some((m) => m && m.id === route); }
export function buildBrowserSmokePlan({ platform = globalThis.Platform, routes = DEFAULT_ROUTES, dryRuns = DEFAULT_DRY_RUNS } = {}) {
  const modules = safeListModules(platform);
  const routeChecks = routes.map((route) => Object.freeze({
    id: `route:${route}`,
    route,
    ok: routeOk(route, modules),
    expected: `#/${route}`,
    severity: routeOk(route, modules) ? 'info' : 'critical'
  }));
  const dryRunChecks = dryRuns.map((item) => {
    const ok = routeOk(item.module, modules);
    return Object.freeze({ ...item, ok, severity: ok ? 'info' : 'warning' });
  });
  const failures = routeChecks.concat(dryRunChecks).filter((item) => !item.ok);
  return Object.freeze({
    generatedAt: new Date().toISOString(),
    status: failures.some((item) => item.severity === 'critical') ? 'fail' : failures.length ? 'warn' : 'pass',
    routeChecks,
    dryRunChecks,
    totals: { routes: routeChecks.length, dryRuns: dryRunChecks.length, failed: failures.length }
  });
}
export function serializeSmokePlan(plan) {
  return JSON.stringify(plan || buildBrowserSmokePlan(), null, 2);
}
export default { buildBrowserSmokePlan, serializeSmokePlan };
