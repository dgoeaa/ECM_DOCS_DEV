/** Phase 9 — Executive response matrix domain. */
import { loadMinutes, summarizeMinutes } from './minute-ledger.js';
function all(E, type) { try { return E?.all?.(type) || []; } catch (_) { return []; } }
function byRef(E, ref) { try { return E?.byReference?.(ref) || {}; } catch (_) { return {}; } }
function statusOf(items, fallback = '') {
  const live = (items || []).find((item) => !/closed|archived|complete|done|resolved/i.test(String(item.status || '')));
  return (live || (items || [])[0] || {}).status || fallback || 'open';
}
function overdue(items) {
  const now = Date.now();
  return (items || []).filter((item) => {
    const due = Date.parse(item.dueDate || item.taskDue || item.TaskDueDate || item.TaskDue || '');
    if (Number.isNaN(due) || due >= now) return false;
    return !/closed|archived|complete|done|resolved/i.test(String(item.status || ''));
  }).length;
}
function riskBand(score) {
  if (score >= 80) return 'critical';
  if (score >= 55) return 'high';
  if (score >= 30) return 'watch';
  return 'normal';
}
function actionCue(row) {
  if (row.overdue > 0) return 'Escalate overdue work';
  if (/pending|review|approval/i.test(String(row.status))) return 'Review pending decision';
  if ((row.counts.minutes || 0) === 0) return 'Confirm minute trail';
  return 'Monitor';
}
export function buildExecutiveResponseMatrix({ entities = globalThis.Platform?.Entities, storage = globalThis.Platform?.Storage, api = globalThis.Platform?.API } = {}) {
  const refs = all(entities, 'reference');
  const rows = refs.map((ref) => {
    const refId = ref.referenceId || ref.__ref || ref.__id || ref.id || '';
    const bundle = byRef(entities, refId);
    const minutes = storage ? loadMinutes(storage, refId) : [];
    const minuteSummary = summarizeMinutes(minutes);
    const tasks = bundle.task || [];
    const approvals = bundle.approval || [];
    const emails = bundle.email || [];
    const docs = bundle.document || [];
    const comments = bundle.comment || [];
    const counts = { documents: docs.length, tasks: tasks.length, emails: emails.length, approvals: approvals.length, comments: comments.length, minutes: minutes.length };
    const overdueCount = overdue(tasks.concat(docs));
    const status = statusOf(tasks.concat(approvals, docs), ref.status);
    const score = Math.min(100, (overdueCount * 40) + (/pending|review|approval/i.test(String(status)) ? 20 : 0) + ((counts.minutes || 0) === 0 ? 10 : 0) + ((counts.tasks || 0) > 3 ? 10 : 0));
    const row = {
      referenceId: refId,
      title: ref.title || ref.subject || refId,
      status,
      directorate: ref.__directorate || ref.PrimaryDSU || ref.AssignedDSU || '',
      counts,
      overdue: overdueCount,
      riskScore: score,
      riskBand: riskBand(score),
      minuteSummary,
      lastActivityAt: ref.ts || ref.createdAt || minuteSummary.lastAt || ''
    };
    row.actionCue = actionCue(row);
    row.targetModule = row.overdue > 0 ? 'orchestrator' : /pending|review|approval/i.test(String(row.status)) ? 'approvals' : 'response-tracking';
    return Object.freeze(row);
  });
  const outbox = api?.Outbox?.metrics ? api.Outbox.metrics() : { queued: 0, dueNow: 0, dead: 0, maxAttempts: 0 };
  const sortedRows = rows.slice().sort((a, b) => (b.riskScore || 0) - (a.riskScore || 0));
  return Object.freeze({
    generatedAt: new Date().toISOString(),
    totalReferences: rows.length,
    overdueReferences: rows.filter((row) => row.overdue > 0).length,
    pendingReviewReferences: rows.filter((row) => /pending|review|approval/i.test(String(row.status))).length,
    deadLetterCount: outbox.dead || 0,
    riskSummary: {
      critical: rows.filter((row) => row.riskBand === 'critical').length,
      high: rows.filter((row) => row.riskBand === 'high').length,
      watch: rows.filter((row) => row.riskBand === 'watch').length,
      normal: rows.filter((row) => row.riskBand === 'normal').length
    },
    outbox,
    rows,
    topRiskRows: sortedRows.slice(0, 10)
  });
}
export default { buildExecutiveResponseMatrix };
