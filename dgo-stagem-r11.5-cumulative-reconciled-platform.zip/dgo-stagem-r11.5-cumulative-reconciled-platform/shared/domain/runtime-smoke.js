/**
 * Phase 10 — Runtime smoke-test domain.
 * Lightweight in-browser checks; no dependencies, no network writes, no framework assumptions.
 */
function check(id, label, ok, detail = '', severity = 'info') {
  return Object.freeze({ id, label, ok: !!ok, detail, severity, ts: new Date().toISOString() });
}
export function runRuntimeSmokeChecks({ platform = globalThis.Platform, doc = globalThis.document } = {}) {
  const checks = [];
  const modules = platform?.Modules;
  const entities = platform?.Entities;
  const api = platform?.API;
  const router = platform?.Router;
  const bus = platform?.Bus;
  const i18n = platform?.I18n;
  const ui = platform?.UI;
  let moduleCount = 0;
  try { moduleCount = modules?.list ? modules.list().length : 0; } catch (_) { moduleCount = 0; }
  checks.push(check('platform-global', 'Platform global available', !!platform, platform ? 'Platform facade is present.' : 'Platform facade is missing.', 'critical'));
  checks.push(check('modules-registry', 'Modules registered', moduleCount > 0, `${moduleCount} module(s) registered.`, moduleCount ? 'info' : 'critical'));
  checks.push(check('router', 'Router available', !!router?.navigate, router?.navigate ? 'Router navigate function present.' : 'Router navigate function missing.', 'critical'));
  checks.push(check('event-bus', 'Event bus available', !!bus?.emit && !!bus?.on, bus ? 'Bus emit/on present.' : 'Event bus missing.', 'critical'));
  checks.push(check('i18n', 'i18n available', !!i18n?.t, i18n?.t ? 'Translation function present.' : 'Translation function missing.', 'warning'));
  checks.push(check('ui-facade', 'UI facade available', !!ui?.toast && !!ui?.confirm, ui ? 'Toast and confirm helpers present.' : 'UI helpers missing.', 'warning'));
  checks.push(check('entity-fabric', 'Entity fabric available', !!entities?.counts && !!entities?.bootstrap, entities ? 'Entity fabric methods present.' : 'Entity fabric missing.', 'critical'));
  let hydrated = false;
  let counts = {};
  try { hydrated = !!entities?.isHydrated?.(); counts = entities?.counts?.() || {}; } catch (_) {}
  checks.push(check('entity-hydration', 'Entity hydration state readable', typeof hydrated === 'boolean', `Hydrated: ${hydrated}; reference count: ${counts.reference || 0}.`, 'info'));
  const outboxMetrics = api?.Outbox?.metrics ? api.Outbox.metrics() : null;
  checks.push(check('outbox-governance', 'Outbox governance available', !!outboxMetrics, outboxMetrics ? `Queued ${outboxMetrics.queued}; dead ${outboxMetrics.dead}.` : 'Outbox metrics unavailable.', 'warning'));
  const unsafeSelectors = ['script[src^="http://"]', 'script[src^="https://"]'];
  let externalScripts = 0;
  try { externalScripts = unsafeSelectors.reduce((n, selector) => n + (doc?.querySelectorAll?.(selector)?.length || 0), 0); } catch (_) {}
  checks.push(check('external-script-scan', 'No external runtime script dependencies detected in DOM', externalScripts === 0, `${externalScripts} external script tag(s) detected.`, externalScripts ? 'warning' : 'info'));
  checks.push(check('dom-sink-policy', 'Unsafe DOM sink policy closed', true, 'Static source scan is handled by build validation; runtime policy remains zero-sink.', 'info'));
  const failed = checks.filter((item) => !item.ok);
  return Object.freeze({
    generatedAt: new Date().toISOString(),
    status: failed.some((item) => item.severity === 'critical') ? 'fail' : failed.length ? 'warn' : 'pass',
    total: checks.length,
    passed: checks.filter((item) => item.ok).length,
    failed: failed.length,
    checks
  });
}
export default { runRuntimeSmokeChecks };
