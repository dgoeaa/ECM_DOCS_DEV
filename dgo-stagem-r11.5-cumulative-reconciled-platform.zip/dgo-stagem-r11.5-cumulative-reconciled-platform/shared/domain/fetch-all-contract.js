/**
 * Phase 9 — Fetch-All Contract Domain
 * Defines a canonical client-side contract for Fetch_All responses without adding dependencies.
 */
const COLLECTION_ALIASES = Object.freeze({
  reference: ['reference', 'references', 'refs', 'Reference', 'References', 'Refs'],
  document: ['document', 'documents', 'docs', 'Document', 'Documents', 'Docs'],
  task: ['task', 'tasks', 'Task', 'Tasks'],
  email: ['email', 'emails', 'Email', 'Emails'],
  approval: ['approval', 'approvals', 'Approval', 'Approvals'],
  comment: ['comment', 'comments', 'Comment', 'Comments'],
  activity: ['activity', 'activities', 'Activity', 'Activities'],
  users: ['users', 'Users', 'userDirectory', 'UserDirectory'],
  categories: ['categories', 'Categories', 'categoryDirectory', 'CategoryDirectory'],
  departments: ['departments', 'Departments', 'directorates', 'Directorates']
});

function isObject(value) { return value && typeof value === 'object' && !Array.isArray(value); }
function firstArray(value) {
  if (Array.isArray(value)) return value;
  if (isObject(value)) return Object.values(value).find(Array.isArray) || [];
  return [];
}
function getByAlias(source, type) {
  const keys = COLLECTION_ALIASES[type] || [type];
  for (const key of keys) {
    if (source && source[key] != null) return source[key];
  }
  return null;
}
function unwrapCandidate(value) {
  if (!isObject(value)) return value;
  if (isObject(value.data)) return value.data;
  if (typeof value.data === 'string') {
    try { return JSON.parse(value.data); } catch (_) { return value.data; }
  }
  if (isObject(value.body)) return unwrapCandidate(value.body);
  return value;
}
function hasCollections(value) {
  if (!isObject(value)) return false;
  return Object.keys(COLLECTION_ALIASES).some((type) => getByAlias(value, type) != null);
}
export function normalizeFetchAllEnvelope(result = {}) {
  const body = unwrapCandidate(result.body != null ? result.body : result.data);
  const candidates = [];
  if (hasCollections(body)) candidates.push(body);
  if (isObject(body)) {
    Object.values(body).forEach((value) => {
      const unwrapped = unwrapCandidate(value);
      if (hasCollections(unwrapped)) candidates.push(unwrapped);
    });
  }
  const sources = candidates.length ? candidates : (isObject(body) ? [body] : []);
  const counts = {};
  const canonical = {};
  Object.keys(COLLECTION_ALIASES).forEach((type) => {
    const rows = [];
    sources.forEach((source) => {
      const val = getByAlias(source, type);
      if (val != null) rows.push(...firstArray(val));
    });
    canonical[type] = rows;
    counts[type] = rows.length;
  });
  return Object.freeze({
    ok: !!result.ok,
    status: result.status || result.body?.status || 0,
    kind: result.kind || (result.ok ? 'ok' : 'unknown'),
    correlationId: result.correlationId || result.body?.correlationId || '',
    durationMs: result.durationMs || 0,
    generatedAt: new Date().toISOString(),
    sources,
    canonical,
    counts,
    hasEntityCollections: Object.entries(counts).some(([key, value]) => !['users', 'categories', 'departments'].includes(key) && value > 0)
  });
}
export function buildFetchAllRefreshEvent(contract, extra = {}) {
  return Object.freeze({
    source: 'FETCH_ALL',
    ok: !!contract?.ok,
    status: contract?.status || 0,
    correlationId: contract?.correlationId || '',
    durationMs: contract?.durationMs || 0,
    counts: contract?.counts || {},
    generatedAt: contract?.generatedAt || new Date().toISOString(),
    ...extra
  });
}
export default { normalizeFetchAllEnvelope, buildFetchAllRefreshEvent };
