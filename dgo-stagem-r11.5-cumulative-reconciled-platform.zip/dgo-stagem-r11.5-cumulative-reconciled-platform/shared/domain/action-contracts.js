/** Platform Coherence Phase 1 — dynamic action contract scaffold. */
import { dynamicActionContract } from '../../config/dynamic-actions.config.js';
export function getActionContract(action) { return dynamicActionContract(action); }
export function validateActionPayload(action, payload = {}) { const c = getActionContract(action); if (!c) return { ok:false, missing:[], message:'Unknown action contract.' }; const missing = (c.required || []).filter((k) => payload[k] == null || payload[k] === ''); return { ok: missing.length === 0, missing, contract: c }; }
export default { getActionContract, validateActionPayload };
