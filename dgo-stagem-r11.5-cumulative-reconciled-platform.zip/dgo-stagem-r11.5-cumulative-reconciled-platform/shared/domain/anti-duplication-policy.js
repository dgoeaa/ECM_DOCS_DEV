/**
 * DGO Stage M-R8.1 — Anti-duplication and redundancy policy.
 *
 * This is a static governance helper used by diagnostics, certification tooling,
 * and future CI checks. It intentionally does not mutate modules at runtime.
 */
import { FEATURE_CLUSTERS, MODULE_ROLE, WRITE_WORKFLOW_OWNER, assertNoDuplicateWriteOwners } from '../../config/feature-ownership.config.js';

export const REDUNDANCY_THRESHOLDS = Object.freeze({
  moduleTokenSimilarityReview: 0.42,
  sharedUtilitySimilarityReview: 0.40,
  functionSimilarityReview: 0.78,
  viewTemplateSimilarityReview: 0.72,
  stylesheetSimilarityReview: 0.72
});

export const REFACTOR_RULES = Object.freeze([
  'Do not delete route-level modules during certification unless a duplicate route or duplicate write owner is confirmed.',
  'Every write workflow must have exactly one authoritative owner module.',
  'Read-only dashboards and lenses may overlap intentionally, but must not perform hidden write actions.',
  'Common list/detail/filter/table/empty/loading/error primitives belong in shared utilities or design-system classes.',
  'Endpoint payload construction belongs in service/domain contracts, not duplicated button handlers.',
  'CSS consolidation must follow browser screenshot verification, not precede it.'
]);

export function redundancyPolicySnapshot() {
  return Object.freeze({
    thresholds: REDUNDANCY_THRESHOLDS,
    rules: REFACTOR_RULES,
    featureClusters: FEATURE_CLUSTERS,
    moduleRoles: MODULE_ROLE,
    writeWorkflowOwner: WRITE_WORKFLOW_OWNER,
    ownershipCheck: assertNoDuplicateWriteOwners()
  });
}

export default { REDUNDANCY_THRESHOLDS, REFACTOR_RULES, redundancyPolicySnapshot };
