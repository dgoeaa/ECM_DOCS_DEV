/** Phase 9 — Assignment Cascade Preview Domain. */
function addDaysISO(days, now = new Date()) {
  const d = new Date(now); d.setDate(d.getDate() + Number(days || 0)); return d.toISOString().slice(0, 10);
}
function categoryDefault(lookups, category, subCategory = '') {
  const cats = (lookups?.categories && lookups.categories()) || [];
  return cats.find((c) => c.raw && String(c.raw.Category || '') === String(category || '') && (!subCategory || String(c.raw.Subcategory || '') === String(subCategory)))
      || cats.find((c) => c.raw && String(c.raw.Category || '') === String(category || '')) || null;
}
function departmentDefault(lookups, dsuKey) {
  const deps = (lookups?.departments && lookups.departments()) || [];
  return deps.find((d) => d.raw && String(d.raw.DSU_KEY || '') === String(dsuKey || '')) || null;
}
export function buildAssignmentCascadePreview({ draft = {}, lookups = globalThis.Platform?.Lookups, now = new Date() } = {}) {
  const rawCategory = draft.categoryRaw || categoryDefault(lookups, draft.category, draft.subCategory)?.raw || null;
  const primaryDSU = draft.primaryDSU || rawCategory?.['Default Primary Responsible'] || rawCategory?.DSU_KEY || '';
  const dept = departmentDefault(lookups, primaryDSU)?.raw || null;
  const categoryCode = draft.categoryCode || rawCategory?.['Category Code'] || '';
  const subCategoryCode = draft.subCategoryCode || rawCategory?.['SubCategory Code'] || '';
  const urgency = String(draft.priority || rawCategory?.Priority || 'P3 (Normal)').toLowerCase();
  const high = /p1|urgent|high/.test(urgency);
  const medium = /p2|medium/.test(urgency);
  const ackDue = draft.ackDue || addDaysISO(high ? 1 : 2, now);
  const taskDue = draft.taskDue || addDaysISO(high ? 2 : medium ? 4 : 7, now);
  const recommendedAssignee = draft.assignedTo || dept?.DSU_HeadEmail || dept?.DSU_HeadPersonalEmail || '';
  const recommendedAssigneeTitle = draft.assignedToTitle || dept?.DSU_HeadTitle || dept?.Title || '';
  const confidence = rawCategory && dept ? 0.86 : rawCategory ? 0.68 : 0.42;
  const warnings = [];
  if (!rawCategory) warnings.push('No matching category record found.');
  if (!primaryDSU) warnings.push('No primary DSU identified.');
  if (!recommendedAssignee) warnings.push('No assignee email resolved from directory.');
  const governanceChecks = [
    { id: 'human-review', ok: true, label: 'Human confirmation required before write.' },
    { id: 'category', ok: !!rawCategory, label: rawCategory ? 'Category record resolved.' : 'Category record unresolved.' },
    { id: 'directorate', ok: !!primaryDSU, label: primaryDSU ? 'Primary DSU resolved.' : 'Primary DSU unresolved.' },
    { id: 'assignee', ok: !!recommendedAssignee, label: recommendedAssignee ? 'Assignee email resolved.' : 'Assignee email unresolved.' }
  ];
  return Object.freeze({
    requiresHumanApproval: true,
    governanceChecks,
    category: draft.category || rawCategory?.Category || '',
    subCategory: draft.subCategory || rawCategory?.Subcategory || '',
    categoryCode,
    subCategoryCode,
    primaryDSU,
    recommendedAssignee,
    recommendedAssigneeTitle,
    priority: draft.priority || (high ? 'P1 (High)' : medium ? 'P2 (Medium)' : 'P3 (Normal)'),
    ackDue,
    taskDue,
    confidence,
    warnings,
    rationale: [
      rawCategory ? 'Category lookup matched.' : 'Category lookup not matched.',
      dept ? 'Primary DSU resolved to directorate directory.' : 'Directorate directory did not resolve a primary DSU.',
      'Human confirmation is required before any workflow write.'
    ]
  });
}
export default { buildAssignmentCascadePreview };
