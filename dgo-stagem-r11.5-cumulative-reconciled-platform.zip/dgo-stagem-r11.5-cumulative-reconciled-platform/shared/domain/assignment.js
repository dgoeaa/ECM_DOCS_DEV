import { validateAssignmentDraft as validateDomainAssignmentDraft } from './validators.js';
import { addBusinessDaysISO } from './sla-projection.js';
/** Platform Coherence Phase 2 — canonical assignment domain.
 * Owns shared assignment normalization and Power Automate-compatible payload construction for
 * single-item and bulk assignment surfaces. The exported functions intentionally preserve the
 * legacy field aliases consumed by the existing flows. */
const SOURCE = 'DGO_FAST_Track_WEB_OPS';
const DEVICE_ID = 'standalone-html';

function todayISO(now = new Date()) { return now.toISOString().slice(0, 10); }
function addDaysISO(days, now = new Date()) { return addBusinessDaysISO(days, now); }
function userEmailOf(P = globalThis.Platform) {
  return (P?.Persona?.email && P.Persona.email()) || `${(P?.Persona?.current && P.Persona.current()) || 'web-ops'}@nitda.gov.ng`;
}
function deviceOf(nav = globalThis.navigator || {}) { return { id: DEVICE_ID, platform: nav.platform || '', ua: nav.userAgent || '' }; }
export function normalizeRecipients(value) {
  if (Array.isArray(value)) return value.map((v) => String(v).trim()).filter(Boolean);
  return String(value || '').split(/[;,]/).map((v) => v.trim()).filter(Boolean);
}
export function recipientsToFlowString(value) { return normalizeRecipients(value).join(';'); }
export function normalizeDueDates({ ackDue = '', taskDue = '' } = {}, now = new Date()) {
  const fallback = addDaysISO(1, now);
  return { ackDue: ackDue || fallback, taskDue: taskDue || fallback };
}
export function findCategoryRecord(lookups, category, subCategory = '') {
  const cats = (lookups?.categories && lookups.categories()) || [];
  return (cats.find((c) => c.raw && c.raw.Category === category && (!subCategory || c.raw.Subcategory === subCategory)) || {}).raw || null;
}
export function resolveCategoryDefaults(lookups, category, subCategory = '') {
  const rec = findCategoryRecord(lookups, category, subCategory);
  if (!rec) return { record: null, categoryCode: '', subCategoryCode: '', primaryDSU: '', assignedToTitle: '' };
  const primaryDSU = rec['Default Primary Responsible'] || '';
  const dept = ((lookups?.departments && lookups.departments()) || []).find((x) => x.raw && x.raw.DSU_KEY === primaryDSU)?.raw || null;
  return {
    record: rec,
    categoryCode: rec['Category Code'] || '',
    subCategoryCode: rec['SubCategory Code'] || '',
    primaryDSU,
    assignedToTitle: dept ? (dept.DSU_HeadTitle || '') : ''
  };
}
export function normalizeSelectedDocument(doc = {}, fallbackRef = '') {
  const ref = fallbackRef || doc.__ref || doc.referenceId || doc.RefIDD || doc.__id || doc.id || '';
  const id = doc.__id || doc.id || ref;
  const title = doc.title || doc.Title || doc.subject || doc.Subject || ref;
  return { id, ref, title, description: doc.description || doc.Description || '', attachmentLink: doc.attachmentLink || doc.AttachmentLink || '' };
}
export function buildSingleAssignmentPayload({ draft = {}, platform = globalThis.Platform, nav = globalThis.navigator || {}, now = new Date() } = {}) {
  const d = draft || {};
  const day = todayISO(now);
  const { ackDue, taskDue } = normalizeDueDates({ ackDue: d.ackDue, taskDue: d.taskDue }, now);
  const userEmail = userEmailOf(platform);
  const doc = normalizeSelectedDocument(d.sourceDoc || {}, d.ref);
  const copyTo = recipientsToFlowString(d.copyTo || []);
  const preRef = `${day.replace(/-/g, '')}-${doc.id}-${d.categoryCode || ''}-${d.subCategoryCode || ''}-`;
  const task = {
    StartDate: day, ActivityID: doc.id, Title: doc.title, Description: doc.description, Status: 'New',
    Category: d.category || '', CategoryCode: d.categoryCode || '', SubCategory: d.subCategory || '', SubCategoryCode: d.subCategoryCode || '',
    PrimaryDSU: d.primaryDSU || '', AssignedTo: d.assignedTo || '', AssignedToTitle: d.assignedToTitle || '', AssignedDSU: d.primaryDSU || '',
    supportingAssignedTo: d.supportAssignedTo || '', SupportAssignedTo: d.supportAssignedTo || '', SupportAssignedToTitle: d.supportAssignedToTitle || '',
    SupportDSU: d.supportDSU || '', SupportDSUKey: d.supportDSU || '', AckDue: ackDue, AcknowledgementDueBy: ackDue, AcknolwedgementDueBy: ackDue,
    TaskDue: taskDue, TaskDueDate: taskDue, Timeline: 'N/A', CopyTo: copyTo, Priority: d.priority || 'P3 (Normal)',
    PreReferenceID: preRef, Categorization: `${d.category || ''}-${d.subCategory || ''}`, AttachmentLink: doc.attachmentLink,
    Comments: d.comments || '', ActionRequired: d.actionRequired || '', CreatedBy: userEmail
  };
  const selection = { ID: doc.id, RefIDD: String(doc.id), Title: doc.title };
  return {
    payload: {
      action: 'singleassignment', operation: 'create', mode: 'single', source: SOURCE, userEmail, method: 'POST', device: deviceOf(nav),
      AssignmentType: d.assignmentType || 'newassignment', NewActivityTask: task, Selected: selection,
      payload: { task: { ...task }, selection: { single: selection, items: [] }, assignment: { type: d.assignmentType || 'newassignment' } }
    },
    taskRecord: {
      referenceId: d.ref || doc.ref || String(doc.id), title: d.title || d.activityTask || doc.title, assignedTo: d.assignedTo || '',
      priority: d.priority || 'P3 (Normal)', status: 'Assigned', assignmentType: d.assignmentType || 'newassignment',
      taskDue, ackDue, category: d.category || '', subCategory: d.subCategory || '', ts: new Date(now).toISOString()
    },
    ackDue, taskDue, userEmail, selectedItem: selection
  };
}
export function normalizeBulkSelection(selectedRefs = [], entities) {
  const E = entities || globalThis.Platform?.Entities;
  const docs = (E?.all && E.all('document')) || [];
  return [...selectedRefs].map((key) => {
    const doc = docs.find((x) => String(x.__ref || x.__id) === String(key)) || { __id: key, __ref: key, title: '' };
    const id = doc.__id || key;
    return { ID: id, RefIDD: String(id), Title: doc.title || doc.Title || '' };
  });
}
export function buildBulkAssignmentPayload({ draft = {}, selectedRefs = [], entities, lookups, platform = globalThis.Platform, nav = globalThis.navigator || {}, now = new Date() } = {}) {
  const d = draft || {};
  const category = d.category || '', subCategory = d.subCategory || '';
  const defaults = resolveCategoryDefaults(lookups, category, subCategory);
  const assignee = d.assignee || '', coAssignee = d.coAssignee || '', copyTo = recipientsToFlowString(d.copyTo || []);
  const priority = d.priority || 'P3 (Normal)', actionRequired = d.actionRequired || '', comments = d.comments || '';
  const day = todayISO(now);
  const { ackDue, taskDue } = normalizeDueDates({ ackDue: d.ackDue, taskDue: d.taskDue }, now);
  const userEmail = userEmailOf(platform);
  const selectedItems = normalizeBulkSelection(selectedRefs, entities);
  const assignedToTitle = defaults.assignedToTitle || assignee;
  const task = {
    StartDate: day, Title: '', Status: 'New', Category: category, CategoryCode: defaults.categoryCode, SubCategory: subCategory, SubCategoryCode: defaults.subCategoryCode,
    PrimaryDSU: defaults.primaryDSU, AssignedTo: assignee, AssignedToTitle: assignedToTitle, AssignedDSU: defaults.primaryDSU,
    supportingAssignedTo: coAssignee, SupportAssignedTo: coAssignee, SupportAssignedToTitle: '', SupportDSU: '', Priority: priority,
    AcknowledgementDueBy: ackDue, AcknolwedgementDueBy: ackDue, TaskDueDate: taskDue, CopyTo: copyTo, ActionRequired: actionRequired,
    Comments: comments, CreatedBy: userEmail, Timeline: 'N/A', Categorization: `${category}-${subCategory}`
  };
  return {
    payload: {
      action: 'bulkassignment', operation: 'create', mode: 'bulk', source: SOURCE, userEmail, method: 'POST', device: deviceOf(nav),
      AssignmentType: 'bulkassignment', NewActivityTask: task, SelectedItems: selectedItems,
      payload: { task: { ...task }, selection: { items: selectedItems }, assignment: { type: 'bulkassignment' } }
    },
    selectedItems, total: selectedItems.length, ackDue, taskDue, userEmail,
    taskRecords: selectedItems.map((it) => ({ referenceId: it.RefIDD, title: it.Title, assignedTo: assignee, priority, status: 'Assigned', assignmentType: 'bulkassignment', category, subCategory, taskDue, ackDue, ts: new Date(now).toISOString() }))
  };
}
export function validateAssignmentDraft(draft = {}, opts = {}) {
  return validateDomainAssignmentDraft(draft, opts);
}
export default { normalizeRecipients, recipientsToFlowString, normalizeDueDates, resolveCategoryDefaults, normalizeSelectedDocument, buildSingleAssignmentPayload, buildBulkAssignmentPayload, normalizeBulkSelection, validateAssignmentDraft };
