/** Platform Coherence Phase 5 — canonical rollup domain.
 * This is the single dashboard/report/HUD projection layer over Platform.Entities.
 * Aggregator modules should consume these models instead of each recomputing counts, SLA, status mix,
 * recent activity, and attention queues independently. */
import { buildSlaBoard } from './sla-projection.js';

const ENTITY_TYPES = ['reference', 'document', 'task', 'email', 'approval', 'comment', 'activity'];
const CLOSED_RE = /complete|completed|closed|approved|dispatched|archived|resolved/i;
const PENDING_RE = /pending|review/i;

function platform() { return globalThis.Platform || {}; }
function entities() { return platform().Entities || {}; }
function safeAll(type) {
  try { return entities().all?.(type) || []; } catch (_) { return []; }
}
function safeCounts() {
  try { return entities().counts?.() || {}; } catch (_) { return {}; }
}
function byStatusCount(statusMap = {}, matcher) {
  return Object.entries(statusMap || {}).filter(([s]) => matcher.test(String(s))).reduce((sum, [, n]) => sum + Number(n || 0), 0);
}
function recentReferences(counts, references) {
  const recent = Array.isArray(counts.recent) && counts.recent.length ? counts.recent : references;
  return recent.slice(0, 8);
}
function fabricSnapshot() {
  const counts = safeCounts();
  const records = Object.fromEntries(ENTITY_TYPES.map((t) => [t, safeAll(t)]));
  return { counts, records };
}

export function entityCounts() { return safeCounts(); }

export function buildOperationalKpis() {
  const { counts, records } = fabricSnapshot();
  const sla = buildSlaBoard([...(records.task || []), ...(records.document || [])]);
  const byStatus = counts.byStatus || {};
  return {
    counts,
    records,
    sla,
    totals: {
      reference: counts.reference || 0,
      document: counts.document || 0,
      task: counts.task || 0,
      email: counts.email || 0,
      approval: counts.approval || 0,
      comment: counts.comment || 0,
      activity: counts.activity || 0,
      all: ['reference', 'document', 'task', 'email', 'approval', 'comment', 'activity'].reduce((n, k) => n + (counts[k] || 0), 0)
    },
    closed: (byStatus.closed || 0) + (byStatus.archived || 0) + (byStatus.completed || 0),
    completed: byStatusCount(byStatus, CLOSED_RE),
    pendingReview: byStatusCount(byStatus, PENDING_RE) || (counts.approval || 0),
    statusMix: byStatus,
    priorityMix: counts.byPriority || {},
    assigneeMix: counts.byAssignee || {},
    timeline: counts.timeline || [],
    recent: recentReferences(counts, records.reference || [])
  };
}

export function buildAttentionQueue({ limit = 12 } = {}) {
  const kpis = buildOperationalKpis();
  const itemsFromSla = kpis.sla.items
    .filter((r) => r._sla && (r._sla.key === 'overdue' || r._sla.key === 'dueSoon'))
    .map((r) => ({
      ref: r.__ref || r.referenceId || r.RefIDD || r.__id || r.id || '',
      title: r.title || r.subject || r.Title || r.Subject || r.__id || 'Untitled item',
      assignedTo: r.assignedTo || r.AssignedTo || '',
      type: r.__type || r.type || 'item',
      sla: r._sla
    }));
  return itemsFromSla.slice(0, limit);
}

export function buildHomeDashboard() {
  const k = buildOperationalKpis();
  const records = k.records;
  const total = Math.max(1, (records.reference || []).length);
  return {
    ...k,
    phaseCounts: {
      intake: (records.email || []).length,
      routing: (records.document || []).length,
      action: (records.task || []).length,
      review: (records.approval || []).length,
      dispatch: (records.reference || []).filter((r) => String(r.status || '').toLowerCase() === 'approved').length,
      archive: (records.reference || []).filter((r) => /closed|archived/i.test(String(r.status || ''))).length,
      total
    },
    attention: {
      overdue: k.sla.counts.overdue || 0,
      dueSoon: k.sla.counts.dueSoon || 0,
      queue: buildAttentionQueue({ limit: 6 })
    }
  };
}

export function buildExecutiveSummary() {
  const k = buildOperationalKpis();
  return {
    ...k,
    kpis: {
      references: k.totals.reference,
      openTasks: k.totals.task,
      pendingApprovals: k.totals.approval,
      overdue: k.sla.counts.overdue || 0
    },
    overdueItems: buildAttentionQueue({ limit: 12 }),
    recent: k.recent
  };
}

export function buildReportSummary() {
  const k = buildOperationalKpis();
  return {
    ...k,
    totalActivities: k.totals.all,
    completed: k.completed,
    pendingApprovals: k.pendingReview,
    overdue: k.sla.counts.overdue || 0,
    activitySummary: {
      references: k.totals.reference,
      documents: k.totals.document,
      tasks: k.totals.task,
      emails: k.totals.email,
      approvals: k.totals.approval
    }
  };
}

export function buildOperatorMatrix({ page = 1, pageSize = 50, maxRows = 200 } = {}) {
  const k = buildOperationalKpis();
  const tasks = k.sla.items.filter((r) => (r.__type || r.type || 'task') === 'task' || r.ActivityID || r.assignedTo || r.AssignedTo);
  const total = tasks.length;
  const pageCount = Math.max(1, Math.ceil(total / pageSize));
  const safePage = Math.min(Math.max(1, page), pageCount);
  const start = (safePage - 1) * pageSize;
  const rows = tasks.slice(start, start + Math.min(pageSize, maxRows));
  return { ...k, tasks, total, page: safePage, pageCount, start, rows };
}

export function buildFastTrackBoard(records = null) {
  const source = records || [...safeAll('task'), ...safeAll('document')];
  return buildSlaBoard(source);
}

export function buildStatusMix() { return buildOperationalKpis().statusMix; }
export function buildPriorityMix() { return buildOperationalKpis().priorityMix; }
export function buildRecentActivity() { return buildOperationalKpis().recent; }
export function buildTimelineSeries() { return buildOperationalKpis().timeline; }

export default {
  entityCounts, buildOperationalKpis, buildAttentionQueue, buildHomeDashboard, buildExecutiveSummary,
  buildReportSummary, buildOperatorMatrix, buildFastTrackBoard, buildStatusMix, buildPriorityMix,
  buildRecentActivity, buildTimelineSeries
};
