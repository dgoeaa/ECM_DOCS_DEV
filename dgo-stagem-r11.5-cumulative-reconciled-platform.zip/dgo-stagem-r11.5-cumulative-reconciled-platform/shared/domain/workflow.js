/** Platform Coherence Phase 7 — canonical workflow transition domain.
 * Modules call this layer for workflow-facing mutations. Entities.transitionStatus() remains the sealed
 * state-machine authority underneath; this file normalizes action names, result shapes, and domain wrappers
 * for approval, dispatch, closure, archive, assignment, acknowledgement, and generic transitions. */

function P() { return globalThis.Platform || {}; }
function nowISO() { return new Date().toISOString(); }
function personaEmail(platform = P()) {
  return (platform.Persona?.email && platform.Persona.email()) || `${(platform.Persona?.current && platform.Persona.current()) || 'web-ops'}@nitda.gov.ng`;
}
function currentStatus(ref, platform = P()) {
  const bundle = platform.Entities?.byReference?.(ref) || {};
  return String(bundle.reference?.status || '').toLowerCase();
}
function normalizeFail(kind, message, extra = {}) { return { ok: false, kind, message, ts: nowISO(), ...extra }; }
function emitWorkflowAudit(event, payload) {
  const platform = P();
  platform.Bus?.emit?.(event, payload);
  platform.Log?.info?.(event, payload);
}

export function transitionReference(ref, from = null, to = '', by = null, options = {}) {
  const platform = options.platform || P();
  const refId = String(ref || '').trim();
  const target = String(to || '').trim();
  const actor = by || personaEmail(platform);
  if (!refId) return normalizeFail('NO_REFERENCE', 'No reference supplied for workflow transition.');
  if (!target) return normalizeFail('NO_TARGET_STATUS', 'No target status supplied for workflow transition.', { ref: refId });
  const source = from == null ? currentStatus(refId, platform) : from;
  const svc = platform.Entities?.transitionStatus;
  if (typeof svc !== 'function') return normalizeFail('NO_ENTITY_STORE', 'Workflow transition service is unavailable.', { ref: refId, from: source, to: target });
  const result = svc(refId, source, target, actor);
  if (result && result.ok) {
    const out = { action: 'transition', ref: refId, from: result.from ?? source, to: result.to || target, by: actor, ts: result.ts || nowISO(), ...result };
    emitWorkflowAudit('audit:workflow-transition', out);
    return Object.freeze(out);
  }
  const fail = { action: 'transition', ref: refId, from: source, to: target, by: actor, ...(result || normalizeFail('TRANSITION_FAILED', 'Workflow transition failed.')) };
  platform.Log?.warn?.('workflow.transition-failed', fail);
  return Object.freeze(fail);
}

export function transitionSequence(ref, targets = [], by = null, options = {}) {
  const platform = options.platform || P();
  let from = options.from == null ? currentStatus(ref, platform) : options.from;
  let last = null;
  for (const target of targets) {
    last = transitionReference(ref, from, target, by, { platform });
    if (!last.ok) return last;
    from = last.to;
  }
  return last || normalizeFail('NO_TARGET_STATUS', 'No transition sequence supplied.', { ref });
}

export function assignReference(ref, by = null, options = {}) { return transitionReference(ref, options.from ?? currentStatus(ref), 'assigned', by, options); }
export function acknowledgeReferenceWorkflow(ref, by = null, options = {}) { return transitionReference(ref, options.from ?? currentStatus(ref), 'acknowledged', by, options); }
export function markInProgress(ref, by = null, options = {}) { return transitionReference(ref, options.from ?? currentStatus(ref), 'in-progress', by, options); }
export function completeAction(ref, by = null, options = {}) { return transitionReference(ref, options.from ?? currentStatus(ref), 'action-complete', by, options); }
export function requestReview(ref, by = null, options = {}) { return transitionReference(ref, options.from ?? currentStatus(ref), 'pending-review', by, options); }
export function approveReference(ref, by = null, options = {}) { return transitionReference(ref, options.from ?? currentStatus(ref), 'approved', by, options); }
export function returnReference(ref, by = null, options = {}) { return transitionReference(ref, options.from ?? currentStatus(ref), 'returned', by, options); }
export function dispatchReference(ref, by = null, options = {}) { return transitionReference(ref, options.from ?? currentStatus(ref), 'dispatched', by, options); }
export function noDispatchReference(ref, by = null, options = {}) { return transitionReference(ref, options.from ?? currentStatus(ref), 'no-dispatch', by, options); }
export function closeReference(ref, by = null, options = {}) { return transitionReference(ref, options.from ?? currentStatus(ref), 'closed', by, options); }

export function archiveReference(ref, by = null, options = {}) {
  const platform = options.platform || P();
  const result = transitionReference(ref, options.from ?? currentStatus(ref, platform), 'archived', by, { platform });
  return result;
}

export function canCloseReference(ref) {
  const platform = P();
  return platform.Entities?.canClose?.(ref) || normalizeFail('NO_ENTITY_STORE', 'Closure gate service is unavailable.', { ref });
}

export function setActiveReference(ref, source) { return P().Context?.setActive?.(ref, source); }

export default {
  transitionReference, transitionSequence, assignReference, acknowledgeReferenceWorkflow, markInProgress,
  completeAction, requestReview, approveReference, returnReference, dispatchReference, noDispatchReference,
  closeReference, archiveReference, canCloseReference, setActiveReference
};
