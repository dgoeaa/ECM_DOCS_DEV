/**
 * OBSIDIAN v4.4 - shared/domain/minute-ledger.js
 * Canonical minute-sheet ledger primitives adopted from the Phase 3 parity review.
 * Vanilla ES module only; no dependencies and no DOM APIs.
 */
const DEFAULT_ACTION = 'FOR_ACTION';
const ACTION_LABELS = Object.freeze({
  FOR_ACTION: 'For Action',
  FOR_ATTENTION: 'For Attention',
  FOR_REVIEW: 'For Review',
  FOR_DG_ATTENTION: 'For DG Attention',
  COMPLY: 'Comply',
  NOTE: 'Note',
  ROUTED: 'Routed',
  DISPATCHED: 'Dispatched',
  CLOSED: 'Closed'
});

const PRIORITY_LABELS = Object.freeze({
  LOW: 'Low',
  MEDIUM: 'Medium',
  HIGH: 'High',
  URGENT: 'Urgent'
});

export function minuteStorageKey(referenceId) {
  return `minutes.${String(referenceId || '').trim()}`;
}

export function normalizeMinuteAction(action) {
  const clean = String(action || DEFAULT_ACTION).trim().toUpperCase().replace(/[^A-Z0-9]+/g, '_');
  return ACTION_LABELS[clean] ? clean : DEFAULT_ACTION;
}

export function minuteActionLabel(action) {
  return ACTION_LABELS[normalizeMinuteAction(action)] || ACTION_LABELS[DEFAULT_ACTION];
}

export function normalizePriority(priority) {
  const clean = String(priority || 'MEDIUM').trim().toUpperCase().replace(/[^A-Z0-9]+/g, '_');
  return PRIORITY_LABELS[clean] ? clean : 'MEDIUM';
}

export function priorityLabel(priority) {
  return PRIORITY_LABELS[normalizePriority(priority)] || PRIORITY_LABELS.MEDIUM;
}

function profileName(profile) {
  if (!profile || typeof profile !== 'object') return 'Desk Representative';
  return profile.fullName || profile.name || profile.email || 'Desk Representative';
}

function profileEmail(profile) {
  if (!profile || typeof profile !== 'object') return '';
  return profile.email || profile.userEmail || '';
}

export function normalizeMinute(raw, index = 0) {
  const item = raw && typeof raw === 'object' ? raw : {};
  const action = normalizeMinuteAction(item.action || item.actionCode);
  const priority = normalizePriority(item.priority);
  return {
    id: item.id || `MIN-${Date.now()}-${index + 1}`,
    num: item.num || `MINUTE ${index + 1}`,
    referenceId: item.referenceId || item.ref || '',
    text: String(item.text || item.body || item.note || '').trim(),
    action,
    actionLabel: minuteActionLabel(action),
    priority,
    priorityLabel: priorityLabel(priority),
    author: item.author || item.officerName || 'Desk Representative',
    authorEmail: item.authorEmail || item.email || '',
    routeTo: item.routeTo || item.targetUser || item.officerId || '',
    routeToLabel: item.routeToLabel || item.targetLabel || item.routeTo || '',
    correlationId: item.correlationId || '',
    timestamp: item.timestamp || new Date().toISOString(),
    provenance: item.provenance || 'client-confirmed'
  };
}

export function loadMinutes(storage, referenceId) {
  const key = minuteStorageKey(referenceId);
  const list = storage && typeof storage.get === 'function' ? storage.get(key, []) : [];
  return Array.isArray(list) ? list.map((m, i) => normalizeMinute(m, i)) : [];
}

export function saveMinutes(storage, referenceId, minutes) {
  if (!storage || typeof storage.set !== 'function') return false;
  return storage.set(minuteStorageKey(referenceId), Array.isArray(minutes) ? minutes : []);
}

export function createMinute({ referenceId, text, action, priority, routeTo, routeToLabel, profile, correlationId, timestamp }) {
  const safeText = String(text || '').trim();
  const safeReference = String(referenceId || '').trim();
  if (!safeReference) throw new Error('Minute requires a reference id.');
  if (!safeText) throw new Error('Minute text is required.');
  return normalizeMinute({
    id: `MIN-${safeReference}-${Date.now()}`,
    referenceId: safeReference,
    text: safeText,
    action,
    priority,
    routeTo,
    routeToLabel,
    author: profileName(profile),
    authorEmail: profileEmail(profile),
    correlationId,
    timestamp: timestamp || new Date().toISOString(),
    provenance: 'backend-confirmed'
  }, 0);
}

export function appendConfirmedMinute(storage, referenceId, minute) {
  const current = loadMinutes(storage, referenceId);
  const normalized = normalizeMinute({ ...minute, num: `MINUTE ${current.length + 1}` }, current.length);
  const next = current.concat(normalized);
  saveMinutes(storage, referenceId, next);
  return next;
}

export function summarizeMinutes(minutes) {
  const list = Array.isArray(minutes) ? minutes : [];
  const routed = list.filter((m) => m.routeTo).length;
  const urgent = list.filter((m) => normalizePriority(m.priority) === 'URGENT').length;
  const last = list.length ? normalizeMinute(list[list.length - 1], list.length - 1) : null;
  return { total: list.length, routed, urgent, lastAction: last ? last.actionLabel : 'None', lastAt: last ? last.timestamp : null };
}

export default {
  minuteStorageKey,
  normalizeMinuteAction,
  minuteActionLabel,
  normalizePriority,
  priorityLabel,
  normalizeMinute,
  loadMinutes,
  saveMinutes,
  createMinute,
  appendConfirmedMinute,
  summarizeMinutes
};
