import { loadMovements } from './movement.js';
/** Platform Coherence Phase 6 — canonical Reference trace domain.
 * Produces one consistent Reference view model for full-trace views and compact detail excerpts.
 * Response Tracking remains the canonical full trace surface; other modules consume related counts,
 * compact timelines, and normalized bundles from here. */
const RELATED = Object.freeze([
  ['reference', 'response-tracking', 'table'],
  ['document', 'ops-hub', 'folder'],
  ['email', 'correspondence', 'mail'],
  ['task', 'orchestrator', 'workflow'],
  ['approval', 'approvals', 'check-circle'],
  ['comment', 'comments', 'message-square'],
  ['activity', 'fasttrack', 'activity'],
  ['movement', 'response-tracking', 'git-branch']
]);
const ARRAY_TYPES = RELATED.map(([t]) => t).filter((t) => t !== 'reference');

function P() { return globalThis.Platform || {}; }
function E() { return P().Entities || {}; }
function safeArray(v) { return Array.isArray(v) ? v : []; }
function cloneBundle(bundle = {}, ref = '') {
  const out = { reference: bundle.reference || null };
  ARRAY_TYPES.forEach((type) => { out[type] = type === 'movement' ? loadMovements(ref) : safeArray(bundle[type]); });
  return out;
}
function normalizeRef(input) {
  if (input && typeof input === 'object') return String(input.__ref || input.referenceId || input.RefIDD || input.__id || input.id || '').trim();
  return String(input || '').trim();
}
function recordTs(r = {}) { return r.ts || r.timestamp || r.createdAt || r.Created || r.updatedAt || r.Updated || r.date || r.StartDate || ''; }
function recordTitle(r = {}) { return r.title || r.subject || r.Title || r.Subject || r.action || r.status || r.__id || ''; }

export function getReferenceBundle(refOrRecord) {
  const ref = normalizeRef(refOrRecord);
  if (!ref) return cloneBundle({}, '');
  return cloneBundle(E().byReference?.(ref) || {}, ref);
}

export function getReferencePrimaryRecord(refOrRecord) {
  const bundle = getReferenceBundle(refOrRecord);
  const ref = normalizeRef(refOrRecord);
  return bundle.reference || safeArray(bundle.document)[0] || safeArray(bundle.email)[0] || safeArray(bundle.task)[0] || { __ref: ref, referenceId: ref };
}

export function getReferenceRelatedCounts(refOrRecord) {
  const bundle = getReferenceBundle(refOrRecord);
  return Object.freeze({
    reference: bundle.reference ? 1 : 0,
    document: bundle.document.length,
    email: bundle.email.length,
    task: bundle.task.length,
    approval: bundle.approval.length,
    comment: bundle.comment.length,
    activity: bundle.activity.length,
    movement: bundle.movement.length
  });
}

export function getReferenceOpenTasks(refOrRecord) {
  const bundle = getReferenceBundle(refOrRecord);
  return bundle.task.filter((t) => !/action-complete|closed|archived|cold-archived/i.test(String(t.status || t.Status || '')));
}

export function getReferenceTimeline(refOrRecord, { limit = 50 } = {}) {
  const bundle = getReferenceBundle(refOrRecord);
  const rows = [];
  for (const type of ARRAY_TYPES) {
    for (const record of safeArray(bundle[type])) {
      rows.push({
        type,
        id: record.__id || record.id || '',
        ref: record.__ref || record.referenceId || record.RefIDD || normalizeRef(refOrRecord),
        title: recordTitle(record),
        status: record.status || record.Status || '',
        ts: recordTs(record),
        record
      });
    }
  }
  return rows.sort((a, b) => String(b.ts || '').localeCompare(String(a.ts || ''))).slice(0, limit);
}

export function getRelatedLinks(refOrRecord) {
  const counts = getReferenceRelatedCounts(refOrRecord);
  return RELATED.map(([type, moduleId, icon]) => ({ type, moduleId, icon, count: counts[type] || 0 }))
    .filter((x) => x.count > 0);
}

export function buildTraceViewModel(refOrRecord, { timelineLimit = 50 } = {}) {
  const ref = normalizeRef(refOrRecord);
  const bundle = getReferenceBundle(ref);
  const counts = getReferenceRelatedCounts(ref);
  const timeline = getReferenceTimeline(ref, { limit: timelineLimit });
  const primary = getReferencePrimaryRecord(ref);
  return Object.freeze({
    ref,
    primary,
    reference: bundle.reference,
    bundle,
    counts,
    timeline,
    relatedLinks: getRelatedLinks(ref),
    openTasks: getReferenceOpenTasks(ref)
  });
}

export function buildCompactTrace(refOrRecord) { return buildTraceViewModel(refOrRecord, { timelineLimit: 6 }); }
export default { getReferenceBundle, getReferencePrimaryRecord, getReferenceRelatedCounts, getReferenceOpenTasks, getReferenceTimeline, getRelatedLinks, buildTraceViewModel, buildCompactTrace };
