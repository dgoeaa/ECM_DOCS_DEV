/** Platform Coherence Phase 4 — canonical acknowledgement domain.
 * Owns acknowledgement idempotency, local reference transition, task/reference sync, audit emission,
 * and dynamic acknowledgement action dispatch. UI modules call this instead of deciding acknowledgement
 * status semantics independently. */
import { transitionReference } from './workflow.js';

const ACK_TARGET = 'acknowledged';
const TRIAGE_TARGET = 'triaged';
const TRIAGE_PATH = ['', 'registered', 'triaged', 'triage_complete'];
const ACK_OR_BEYOND = new Set([
  'acknowledged', 'in-progress', 'action-complete', 'reassign-requested', 'pending-review', 'approved',
  'approved-with-edit', 'returned', 'escalated', 'dispatch-pending', 'dispatch-in-flight', 'dispatched',
  'dispatch-failed', 'no-dispatch', 'closed', 'partial-dispatch', 'archived', 'cold-archived'
]);
const TRIAGED_OR_BEYOND = new Set([
  'triaged', 'triage_complete', 'assigning', 'assigned', 'assignment-failed', ...ACK_OR_BEYOND
]);

function P() { return globalThis.Platform || {}; }
function nowISO() { return new Date().toISOString(); }
function personaEmail(platform = P()) {
  return (platform.Persona?.email && platform.Persona.email()) || `${(platform.Persona?.current && platform.Persona.current()) || 'web-ops'}@nitda.gov.ng`;
}
function refStatus(ref, platform = P()) {
  const bundle = platform.Entities?.byReference?.(ref) || {};
  return String(bundle.reference?.status || '').toLowerCase();
}
function emitAudit(name, payload) {
  const platform = P();
  platform.Bus?.emit?.(name, payload);
  platform.Log?.info?.(name, payload);
}
function transition(ref, from, to, by, platform = P()) {
  return transitionReference(ref, from, to, by, { platform });
}
function dispatchAckAction(ref, by, targetStatus, task = null) {
  const platform = P();
  const action = platform.Actions;
  if (!action || typeof action.emit !== 'function') return;
  action.emit('acknowledge', {
    ref,
    by,
    status: targetStatus,
    targetStatus,
    taskId: task?.id || task?.__id || null,
    payload: {
      selection: { single: { RefIDD: ref } },
      ref,
      by,
      targetStatus,
      taskId: task?.id || task?.__id || null
    }
  });
}

export function isAcknowledged(record = {}) {
  return ACK_OR_BEYOND.has(String(record.status || record.Status || '').toLowerCase()) || /acknowledge/i.test(String(record.status || record.Status || ''));
}

export function isTriaged(record = {}) {
  return TRIAGED_OR_BEYOND.has(String(record.status || record.Status || '').toLowerCase());
}

export function normalizeAckTarget(record = {}, fallbackRef = '') {
  const ref = String(record.__ref || record.referenceId || record.RefIDD || record.ref || fallbackRef || record.id || '').trim();
  return { ref, task: record || null };
}

export function canAcknowledge(record = {}, { targetStatus = ACK_TARGET } = {}) {
  if (targetStatus === TRIAGE_TARGET) return { ok: !isTriaged(record), alreadyApplied: isTriaged(record) };
  return { ok: !isAcknowledged(record), alreadyApplied: isAcknowledged(record) };
}

export function buildAckAuditRecord({ ref, by, targetStatus = ACK_TARGET, task = null, alreadyApplied = false, ts = nowISO() } = {}) {
  return Object.freeze({
    ref: String(ref || ''),
    by: by || null,
    targetStatus,
    alreadyApplied: !!alreadyApplied,
    taskId: task?.id || task?.__id || null,
    ts
  });
}

function transitionAlongTriagePath(ref, by, platform = P()) {
  let current = refStatus(ref, platform);
  if (TRIAGED_OR_BEYOND.has(current)) return { ok: true, ref, to: current || TRIAGE_TARGET, alreadyApplied: true, ts: nowISO() };
  let idx = TRIAGE_PATH.indexOf(current);
  if (idx < 0) idx = 0;
  let result = { ok: true, from: current, to: current, ref, ts: nowISO() };
  for (let i = idx + 1; i < TRIAGE_PATH.length; i++) {
    const target = TRIAGE_PATH[i];
    if (!target) continue;
    result = transition(ref, current, target, by, platform);
    if (!result.ok) return result;
    current = target;
    if (target === TRIAGE_TARGET) break;
  }
  return result;
}

export async function acknowledgeReference({ ref, task = null, by = null, targetStatus = ACK_TARGET, updateTask = true, dispatchAction = true } = {}) {
  const platform = P();
  const target = normalizeAckTarget(task || {}, ref);
  const refId = String(ref || target.ref || '').trim();
  const actor = by || personaEmail(platform);
  if (!refId) return { ok: false, kind: 'NO_REFERENCE', message: 'No reference supplied for acknowledgement.' };

  const current = refStatus(refId, platform);
  const alreadyApplied = targetStatus === TRIAGE_TARGET ? TRIAGED_OR_BEYOND.has(current) : ACK_OR_BEYOND.has(current);
  if (alreadyApplied || isAcknowledged(task || {})) {
    if (updateTask && task && platform.Entities?.upsert) {
      platform.Entities.upsert('task', { ...task, status: targetStatus === TRIAGE_TARGET ? (task.status || 'acknowledged') : 'acknowledged', acknowledgedAt: task.acknowledgedAt || nowISO(), acknowledgedBy: task.acknowledgedBy || actor });
    }
    const audit = buildAckAuditRecord({ ref: refId, by: actor, targetStatus, task, alreadyApplied: true });
    emitAudit('audit:acknowledgement-idempotent', audit);
    return { ok: true, ref: refId, by: actor, to: current || targetStatus, alreadyApplied: true, audit };
  }

  const res = targetStatus === TRIAGE_TARGET
    ? transitionAlongTriagePath(refId, actor, platform)
    : transition(refId, current || null, ACK_TARGET, actor, platform);
  if (!res.ok) {
    platform.Log?.warn?.('acknowledgement.failed', { ref: refId, by: actor, targetStatus, kind: res.kind || null, message: res.message || '' });
    return res;
  }

  const ts = res.ts || nowISO();
  if (updateTask && task && platform.Entities?.upsert) {
    platform.Entities.upsert('task', { ...task, status: targetStatus === TRIAGE_TARGET ? (task.status || 'acknowledged') : 'acknowledged', acknowledgedAt: ts, acknowledgedBy: actor });
  }
  if (dispatchAction) dispatchAckAction(refId, actor, targetStatus, task);
  const audit = buildAckAuditRecord({ ref: refId, by: actor, targetStatus, task, alreadyApplied: false, ts });
  emitAudit('audit:acknowledgement-recorded', audit);
  return { ...res, by: actor, acknowledgedAt: ts, alreadyApplied: false, audit };
}

export async function acknowledgeTask(task = {}, options = {}) {
  const { ref } = normalizeAckTarget(task, options.ref);
  return acknowledgeReference({ ...options, ref, task, targetStatus: options.targetStatus || ACK_TARGET, updateTask: options.updateTask !== false });
}

export default { isAcknowledged, isTriaged, normalizeAckTarget, canAcknowledge, buildAckAuditRecord, acknowledgeReference, acknowledgeTask };
