/** Central domain validators for assignment, acknowledgement, endpoint, and governance-sensitive payloads. */
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PRIORITY_RE = /^P[1-4]\s*\(/i;

function err(field, key, message) { return { field, key, message }; }
export function isEmail(value) { return EMAIL_RE.test(String(value || '').trim()); }
export function normalizeValidationErrors(errors = []) { return errors.filter(Boolean); }

export function validateAssignmentDraft(draft = {}, { mode = 'single', selectedCount = 0, requireOtp = false, otpVerified = false } = {}) {
  const d = draft || {};
  const errors = [];
  if (mode === 'single' && !String(d.ref || '').trim()) errors.push(err('ref', 'module.single-item-ops.needRef', 'Reference is required.'));
  if (!String(d.category || '').trim()) errors.push(err('category', 'field.required', 'Category is required.'));
  const assignee = mode === 'bulk' ? d.assignee : d.assignedTo;
  if (!String(assignee || '').trim()) errors.push(err('assignee', 'module.single-item-ops.needAssignee', 'Assignee is required.'));
  if (assignee && !isEmail(assignee)) errors.push(err('assignee', 'validation.email', 'Assignee must be a valid email address.'));
  if (mode === 'bulk' && selectedCount < 1) errors.push(err('selection', 'validation.required', 'At least one selected item is required.'));
  if (d.priority && !PRIORITY_RE.test(String(d.priority))) errors.push(err('priority', 'validation.priority', 'Priority must use a supported P1-P4 token.'));
  if (requireOtp && !otpVerified) errors.push(err('otp', 'otp.required', 'OTP verification is required.'));
  return Object.freeze({ ok: errors.length === 0, errors: normalizeValidationErrors(errors) });
}

export function validateEndpointContract(contract = {}) {
  const errors = [];
  if (!contract.key) errors.push(err('key', 'validation.required', 'Endpoint key is required.'));
  if (!contract.method) errors.push(err('method', 'validation.required', 'HTTP method is required.'));
  if (contract.writeCapable && !contract.idempotencyRequired) errors.push(err('idempotency', 'validation.idempotency', 'Write endpoints require idempotency.'));
  return Object.freeze({ ok: errors.length === 0, errors });
}

export function validateMovementRecord(record = {}) {
  const errors = [];
  if (!record.referenceId) errors.push(err('referenceId', 'validation.required', 'Reference is required.'));
  if (!record.action) errors.push(err('action', 'validation.required', 'Movement action is required.'));
  if (!record.timestamp) errors.push(err('timestamp', 'validation.required', 'Timestamp is required.'));
  return Object.freeze({ ok: errors.length === 0, errors });
}

export default { isEmail, validateAssignmentDraft, validateEndpointContract, validateMovementRecord, normalizeValidationErrors };
