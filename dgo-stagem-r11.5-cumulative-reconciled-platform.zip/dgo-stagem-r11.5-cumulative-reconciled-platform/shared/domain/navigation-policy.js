/** Platform Coherence Phase 1 — navigation policy scaffold. */
export const MODULE_AUTHORITY = Object.freeze({ correspondence:'Owner', registry:'Owner', 'ops-hub':'Owner', 'single-item-ops':'Owner', 'bulk-assignment':'Owner', orchestrator:'Owner', fasttrack:'Lens', ackflow:'Lens', 'response-tracking':'Owner', comments:'Utility', approvals:'Owner', dispatch:'Owner', home:'Aggregator', executive:'Aggregator', stats:'Aggregator', reports:'Aggregator', 'operator-hud':'Aggregator', lookup:'Utility', assistant:'Utility', diagnostics:'System', settings:'System' });
export function authorityFor(moduleId) { return MODULE_AUTHORITY[moduleId] || 'Lens'; }
export default { MODULE_AUTHORITY, authorityFor };
