/** OBSIDIAN v4.0 — <pf-triage-bar> · Phase-1 (INTAKE) triage surface (register C-3, Rebuild Fresh).
 *  A chip row that drives one correspondence reference through INTAKE and hands it to ROUTING */
import { PfBaseElement } from './_base.js';
import { transitionOrToast } from '../utils/transitions.js';
import { acknowledgeReference } from '../domain/acknowledgement.js';

const INTAKE_PATH = ['registered', 'triaged', 'triage_complete'];
const URGENCIES = ['p1', 'p2', 'p3', 'p4'];

class PfTriageBar extends PfBaseElement {
  constructor() {
    super();
    this._meta = { acknowledged: false, category: null, urgency: null, duplicate: false };
    this._status = '';
    this._panel = null;
    this._ref = null;
    this._rec = null;
  }

  set item(rec) {
    this._rec = (rec && typeof rec === 'object') ? rec : null;
    this._ref = this._rec && this._rec.__ref ? String(this._rec.__ref) : (this._ref || null);
    this._hydrate();
  }
  get item() { return this._rec || null; }

  set reference(ref) {
    this._ref = ref ? String(ref) : null;
    if (!this._rec) this._rec = null;
    this._hydrate();
  }
  get reference() { return this._ref || null; }

  onConnect() {
    this._meta = { acknowledged: false, category: null, urgency: null, duplicate: false };
    this._status = '';
    this._panel = null;
    this.render(`<style>
      :host{ display:block; }
      .wrap{ background:var(--color-surface-raised); border:1px solid var(--color-border);
        border-radius:13px; padding:.38rem .48rem; }
      .bar{ display:flex; align-items:center; gap:.3rem; flex-wrap:wrap; }
      .lead{ display:flex; align-items:center; gap:.3rem; margin-right:.1rem; flex:1 1 100%; }
      .pill{ font-size:.7rem; font-weight:var(--fw-semibold); padding:.2rem .44rem;
        border-radius:var(--radius-pill); background:var(--color-surface); border:1px solid var(--color-border);
        color:var(--color-text-muted); white-space:nowrap; }
      .chips{ display:flex; gap:.28rem; flex-wrap:wrap; align-items:center; width:100%; }
      .chip{ font:inherit; font-size:.74rem; font-weight:var(--fw-semibold); padding:.3rem .52rem; border-radius:var(--radius-pill);
        border:1px solid var(--color-border); background:var(--color-surface); color:var(--color-text-muted);
        cursor:pointer; transition:all var(--duration-fast) var(--easing-standard); }
      .chip:hover:not([disabled]){ border-color:var(--color-brand-primary); color:var(--color-text); }
      .chip[aria-pressed="true"]{ background:var(--color-brand-primary); color:var(--color-text-inverse); border-color:var(--color-brand-primary); }
      .chip[disabled]{ opacity:.5; cursor:not-allowed; }
      .chip:focus-visible{ outline:2px solid var(--color-brand-primary); outline-offset:2px; }
      .chip--send{ margin-left:auto; border-color:var(--color-brand-primary); color:var(--color-brand-primary); }
      .chip--send[aria-disabled="true"]{ opacity:.5; cursor:not-allowed; }
      .panel{ display:flex; align-items:center; gap:var(--space-2); flex-wrap:wrap;
        margin-top:var(--space-2); padding-top:var(--space-2); border-top:1px dashed var(--color-border); }
      .panel[hidden]{ display:none; }
      label.fld{ font-size:var(--size-caption); color:var(--color-text-muted); display:flex; align-items:center; gap:var(--space-2); }
      select{ font:inherit; font-size:var(--size-body-sm); padding:var(--space-1) var(--space-2);
        border:1px solid var(--color-border-strong); border-radius:var(--radius-sm);
        background:var(--color-surface); color:var(--color-text); }
      select:focus-visible{ outline:2px solid var(--color-brand-primary); outline-offset:1px; }
      .dup{ display:flex; align-items:center; gap:var(--space-2); margin-top:var(--space-2);
        padding:var(--space-1) var(--space-3); border-radius:var(--radius-sm);
        background:var(--color-warning-soft); border:1px solid var(--color-warning);
        color:var(--color-text); font-size:var(--size-caption); }
      .dup[hidden]{ display:none; }

      /* Coarse Target Overrides */
      @media (pointer: coarse) {
        .chip {
          min-height: 34px;
          display: inline-flex;
          align-items: center;
          justify-content: center;
        }
        select {
          min-height: 34px;
        }
      }
    </style>
    <div class="wrap">
      <div class="bar">
        <span class="lead"><span class="pf-overline">${this.t('triage.bar')}</span>
          <span class="pill" id="status" aria-live="polite"></span></span>
        <div class="chips" role="group" aria-label="${this.t('triage.bar')}">
          <button class="chip" id="ack"  type="button" aria-pressed="false">${this.t('triage.acknowledge')}</button>
          <button class="chip" id="cat"  type="button" aria-pressed="false" aria-expanded="false">${this.t('triage.tagCategory')}</button>
          <button class="chip" id="urg"  type="button" aria-pressed="false" aria-expanded="false">${this.t('triage.flagUrgency')}</button>
          <button class="chip" id="dup"  type="button" aria-pressed="false">${this.t('triage.markDuplicate')}</button>
          <button class="chip" id="send" type="button" aria-disabled="true">${this.t('triage.sendToRouting')}</button>
        </div>
      </div>
      <div class="panel" id="cat-panel" hidden>
        <label class="fld" for="cat-sel">${this.t('triage.tagCategory')}
          <select id="cat-sel"><option value="">${this.t('triage.categoryPlaceholder')}</option></select></label>
      </div>
      <div class="panel" id="urg-panel" hidden>
        <label class="fld" for="urg-sel">${this.t('triage.flagUrgency')}
          <select id="urg-sel"><option value="">${this.t('triage.urgencyPlaceholder')}</option></select></label>
      </div>
      <div class="dup" id="dup-banner" hidden><pf-icon name="activity" size="14"></pf-icon><span id="dup-text"></span></div>
    </div>`);

    this._fillCategories();
    this._fillUrgencies();
    this.on(this.$('#ack'), 'click', () => this._acknowledge());
    this.on(this.$('#cat'), 'click', () => this._togglePanel('cat'));
    this.on(this.$('#urg'), 'click', () => this._togglePanel('urg'));
    this.on(this.$('#dup'), 'click', () => this._toggleDuplicate());
    this.on(this.$('#send'), 'click', () => this._sendToRouting());
    this.on(this.$('#cat-sel'), 'change', (e) => this._setCategory(e.target.value));
    this.on(this.$('#urg-sel'), 'change', (e) => this._setUrgency(e.target.value));
    this.bus('data:lookups', () => this._fillCategories());
    this._hydrate();
  }

  get _E() { return globalThis.Platform && globalThis.Platform.Entities; }
  get _by() { const P = globalThis.Platform && globalThis.Platform.Persona; return (P && typeof P.email === 'function') ? P.email() : null; }

  _fillCategories() {
    const sel = this.$('#cat-sel'); if (!sel) return;
    const L = globalThis.Platform && globalThis.Platform.Lookups;
    const rows = (L && typeof L.categories === 'function') ? L.categories() : null;
    if (!Array.isArray(rows) || !rows.length) return;
    const keep = sel.value;
    while (sel.options.length > 1) sel.remove(1);
    for (const o of rows) {
      if (!o || o.value == null || o.value === '') continue;
      const opt = document.createElement('option');
      opt.value = String(o.value); opt.textContent = String(o.label || o.value);
      sel.appendChild(opt);
    }
    if (keep && [...sel.options].some((o) => o.value === keep)) sel.value = keep;
  }

  _fillUrgencies() {
    const sel = this.$('#urg-sel'); if (!sel) return;
    for (const u of URGENCIES) {
      const opt = document.createElement('option');
      opt.value = u; opt.textContent = this.t('triage.urgency.' + u);
      sel.appendChild(opt);
    }
  }

  _hydrate() {
    if (!this.shadowRoot) return;
    let status = '';
    const E = this._E;
    if (E && this._ref && typeof E.byReference === 'function') {
      const b = E.byReference(this._ref);
      status = String((b && b.reference && b.reference.status) || '');
    } else if (this._rec) {
      status = String(this._rec.status || '');
    }
    this._status = status;
    if (INTAKE_PATH.indexOf(status) >= 1) this._meta.acknowledged = true;
    const dupOf = this._rec && this._rec.__duplicateOf;
    if (dupOf) this._meta.duplicate = true;
    this._reflect();
  }

  _mapStatusToThemeClass(status) {
    const map = {
      'registered': 'draft',
      'triaged': 'pending',
      'triage-complete': 'routed',
      'assigned': 'replied'
    };
    return map[status] || 'archived';
  }

  _reflect() {
    const cur = this._status || 'registered';
    const statusEl = this.$('#status');
    if (statusEl) {
      statusEl.textContent = this.t('triage.statusLabel') + ': ' + cur.replace('_', ' ');
      statusEl.className = 'pill'; 
      const badgeType = cur.toLowerCase().replace('_', '-');
      statusEl.classList.add(`pf-badge--${this._mapStatusToThemeClass(badgeType)}`);
    }

    const set = (id, pressed, disabled) => {
      const b = this.$('#' + id); if (!b) return;
      b.setAttribute('aria-pressed', pressed ? 'true' : 'false');
      if (disabled != null) { if (disabled) b.setAttribute('disabled', ''); else b.removeAttribute('disabled'); }
    };
    set('ack', this._meta.acknowledged);
    set('cat', this._meta.category != null);
    set('urg', this._meta.urgency != null);
    set('dup', this._meta.duplicate);

    const send = this.$('#send');
    const past = INTAKE_PATH.indexOf(this._status) >= 2;
    const canSend = this._meta.acknowledged && !past && !!this._ref;
    if (send) {
      send.setAttribute('aria-disabled', canSend ? 'false' : 'true');
      send.setAttribute('aria-pressed', past ? 'true' : 'false');
    }

    const dupOf = this._rec && this._rec.__duplicateOf;
    const banner = this.$('#dup-banner'); const text = this.$('#dup-text');
    if (banner && text) {
      if (dupOf) { text.textContent = this.t('triage.duplicateHint', { ref: String(dupOf) }); banner.hidden = false; }
      else banner.hidden = true;
    }
  }

  _togglePanel(which) {
    this._panel = (this._panel === which) ? null : which;
    const cat = this.$('#cat-panel'), urg = this.$('#urg-panel');
    if (cat) cat.hidden = this._panel !== 'cat';
    if (urg) urg.hidden = this._panel !== 'urg';
    const cb = this.$('#cat'), ub = this.$('#urg');
    if (cb) cb.setAttribute('aria-expanded', this._panel === 'cat' ? 'true' : 'false');
    if (ub) ub.setAttribute('aria-expanded', this._panel === 'urg' ? 'true' : 'false');
  }

  _setCategory(v) {
    this._meta.category = (v === '' ? null : v);
    if (this._meta.category) {
      const L = globalThis.Platform && globalThis.Platform.Lookups;
      const c = (L && typeof L.resolveCategory === 'function') ? L.resolveCategory(this._meta.category) : null;
      if (c) {
        this._meta.categoryName = c.category || this._meta.category;
        this._meta.responsibleDSU = c.primaryDSU || null;
        this._meta.suggestedAssignee = c.assignee || null;
        this._meta.suggestedCoAssignee = c.coAssignee || null;
        this._meta.suggestedCc = (c.cc && c.cc.length) ? c.cc.slice() : [];
        let applied = false;
        if (!this._meta.urgency && c.priorityToken) {
          this._meta.urgency = c.priorityToken;
          const sel = this.$('#urg-sel'); if (sel) sel.value = c.priorityToken;
          applied = true;
        }
        if (applied || c.primaryDSU) this._toast('triage.cascadeApplied', 'info', { dsu: c.primaryDSU || '—' });
      }
    } else {
      this._meta.categoryName = null; this._meta.responsibleDSU = null;
      this._meta.suggestedAssignee = null; this._meta.suggestedCoAssignee = null; this._meta.suggestedCc = [];
    }
    this._reflect();
    this.emit('pf-triage:changed', { ref: this._ref, meta: { ...this._meta } });
  }

  _setUrgency(v) {
    this._meta.urgency = (v === '' ? null : v);
    this._reflect();
    this.emit('pf-triage:changed', { ref: this._ref, meta: { ...this._meta } });
  }

  _toggleDuplicate() {
    this._meta.duplicate = !this._meta.duplicate;
    this._reflect();
    if (this._meta.duplicate) this._toast('triage.duplicateConfirmed', 'info');
    this.emit('pf-triage:changed', { ref: this._ref, meta: { ...this._meta } });
  }

  _advance(target) {
    const E = this._E;
    if (!E || !this._ref) return { ok: false, error: { kind: 'NO_REFERENCE' } };
    const tIdx = INTAKE_PATH.indexOf(target);
    if (tIdx < 0) return { ok: false, error: { kind: 'INVALID_STATE' } };
    let cur = String((E.byReference(this._ref)?.reference?.status) || '');
    let curIdx = INTAKE_PATH.indexOf(cur);
    if (curIdx >= tIdx) { this._status = cur; return { ok: true, finalStatus: cur, noop: true }; }
    for (let i = Math.max(curIdx + 1, 0); i <= tIdx; i++) {
      const res = transitionOrToast(this._ref, cur, INTAKE_PATH[i], this._by);
      if (!res || !res.ok) { this._status = cur; return { ok: false, error: res || { kind: 'ILLEGAL_TRANSITION' }, finalStatus: cur }; }
      cur = INTAKE_PATH[i];
    }
    this._status = cur;
    return { ok: true, finalStatus: cur };
  }

  async _acknowledge() {
    if (!this._ref) { this._toast('triage.noRef', 'danger'); return; }
    const UI = globalThis.Platform && globalThis.Platform.UI;
    if (UI && typeof UI.confirm === 'function') {
      const ok = await UI.confirm({ titleKey: 'triage.ackTitle', summaryKey: 'triage.ackConfirm',
        details: [{ label: this.t('entity.reference'), value: this._ref }], confirmKey: 'triage.acknowledge' });
      if (!ok) return;
    }
    const r = await acknowledgeReference({ ref: this._ref, by: this._by, targetStatus: 'triaged', updateTask: false });
    if (!r.ok) { this._toastError(r); this._reflect(); return; }
    this._status = r.to || 'triaged';
    this._meta.acknowledged = true;
    this._reflect();
    this._toast('triage.ackDone', 'success', { ref: this._ref });
    this.emit('pf-triage:acknowledged', { ref: this._ref, meta: { ...this._meta }, result: r });
    this.emit('pf-triage:changed', { ref: this._ref, meta: { ...this._meta } });
  }

  async _sendToRouting() {
    const send = this.$('#send');
    if (!this._ref) { this._toast('triage.noRef', 'danger'); return; }
    if (send && send.getAttribute('aria-disabled') === 'true') { this._toast('triage.ackFirst', 'warning'); return; }

    const UI = globalThis.Platform && globalThis.Platform.UI;
    const details = [];
    if (this._meta.category) details.push({ label: this.t('triage.metaCategory'), value: this._meta.category });
    if (this._meta.urgency) details.push({ label: this.t('triage.metaUrgency'), value: this.t('triage.urgency.' + this._meta.urgency) });
    if (this._meta.duplicate) details.push({ label: this.t('triage.markDuplicate'), value: '✓' });
    const ok = UI && typeof UI.confirm === 'function'
      ? await UI.confirm({ titleKey: 'triage.routeTitle', summaryKey: 'triage.routeSummary', details, confirmKey: 'triage.sendToRouting' })
      : true;
    if (!ok) return;

    const r = this._advance('triage_complete');
    if (!r.ok) { this._toastError(r.error); this._reflect(); return; }

    const triageMeta = {
      category: this._meta.category || null,
      categoryName: this._meta.categoryName || null,
      urgency: this._meta.urgency || null,
      duplicate: !!this._meta.duplicate,
      duplicateOf: (this._rec && this._rec.__duplicateOf) || null,
      acknowledgedBy: this._by || null,
      responsibleDSU: this._meta.responsibleDSU || null,
      suggestedAssignee: this._meta.suggestedAssignee || null,
      suggestedCoAssignee: this._meta.suggestedCoAssignee || null,
      suggestedCc: (this._meta.suggestedCc && this._meta.suggestedCc.length) ? this._meta.suggestedCc.slice() : []
    };
    const Context = globalThis.Platform && globalThis.Platform.Context;
    if (Context && typeof Context.setHandoff === 'function')
      Context.setHandoff({ fromPhase: 1, toPhase: 2, refs: [this._ref], triageMeta });

    this._reflect();
    this._toast('triage.routed', 'success', { ref: this._ref });
    this.emit('pf-triage:routed', { ref: this._ref, triageMeta });

    const Router = globalThis.Platform && globalThis.Platform.Router;
    if (Router && typeof Router.navigate === 'function') Router.navigate('ops-hub', this._ref);
  }

  _toast(messageKey, variant, vars) {
    const UI = globalThis.Platform && globalThis.Platform.UI;
    if (UI && typeof UI.toast === 'function') UI.toast({ messageKey, variant: variant || 'info', vars });
  }
  _toastError(result) {
    const UI = globalThis.Platform && globalThis.Platform.UI;
    if (UI && typeof UI.toastError === 'function') UI.toastError(result || {});
    else this._toast('triage.ackFirst', 'danger');
  }
}

customElements.define('pf-triage-bar', PfTriageBar);
export default PfTriageBar;
