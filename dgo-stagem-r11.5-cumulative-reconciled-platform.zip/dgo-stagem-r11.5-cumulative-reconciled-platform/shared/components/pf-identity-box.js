/**
 * OBSIDIAN v4.2 — pf-identity-box compatibility component.
 * Purpose: closes stale/optional import paths and provides a safe identity summary element.
 */
class PfIdentityBox extends HTMLElement {
  connectedCallback() {
    const P = globalThis.Platform || {};
    const profile = P.Persona?.profile?.() || {};
    const name = this.getAttribute('name') || profile.fullName || 'Operator';
    const email = this.getAttribute('email') || profile.email || '';
    const role = this.getAttribute('role-label') || profile.jobTitle || profile.dsuKey || '';
    const box = document.createElement('div');
    box.setAttribute('part', 'box');
    box.style.cssText = 'display:flex;gap:.75rem;align-items:center;padding:.75rem;border:1px solid var(--color-border,var(--dgo-color-border-default,#E8E6E7));border-radius:var(--radius-lg,var(--dgo-radius-card,.75rem));background:var(--color-surface,var(--dgo-color-surface-page,#fff));';
    const avatar = document.createElement('span');
    avatar.setAttribute('part', 'avatar');
    avatar.setAttribute('aria-hidden', 'true');
    avatar.style.cssText = 'display:grid;place-items:center;width:2.25rem;height:2.25rem;border-radius:999px;background:var(--dgo-color-action-primary-soft,#EAF3EF);color:var(--dgo-color-action-primary,#05583B);font-weight:800;';
    avatar.textContent = String((name || 'O').trim()[0] || 'O');
    const meta = document.createElement('span');
    meta.setAttribute('part', 'meta');
    meta.style.cssText = 'min-width:0;display:grid;gap:.1rem;';
    const strong = document.createElement('strong');
    strong.setAttribute('part', 'name');
    strong.style.cssText = 'font-size:var(--size-body-sm,var(--dgo-type-body-sm,.8125rem));white-space:nowrap;overflow:hidden;text-overflow:ellipsis;';
    strong.textContent = name;
    const small = document.createElement('small');
    small.setAttribute('part', 'detail');
    small.style.cssText = 'color:var(--color-text-muted,var(--dgo-color-fg-muted,#5F5C5D));white-space:nowrap;overflow:hidden;text-overflow:ellipsis;';
    small.textContent = role || email || 'DGO';
    meta.append(strong, small);
    box.append(avatar, meta);
    this.replaceChildren(box);
  }
}
function escapeHtml(v){return String(v ?? '').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}
if (!customElements.get('pf-identity-box')) customElements.define('pf-identity-box', PfIdentityBox);
export default PfIdentityBox;
