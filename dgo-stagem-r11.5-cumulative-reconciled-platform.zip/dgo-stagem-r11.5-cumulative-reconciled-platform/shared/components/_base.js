/** OBSIDIAN v4.0 — PfBaseElement (/shared/components/_base.js)
 *  Mandatory base for every <pf-*> custom element (§3.2). Shadow DOM on construction;
 *  one shared, cached stylesheet adopted into every shadow root (tokens pierce the
 *  boundary, so var(--*) works inside). Auto-cleanup listeners, scoped queries, i18n. */
const SHARED_CSS = `
  :host{ box-sizing:border-box; font-family:var(--dgo-family-sans); color:var(--dgo-color-fg-default); }
  *,*::before,*::after{ box-sizing:border-box; }
  button{ font:inherit; color:inherit; background:none; border:none; cursor:pointer; border-radius:var(--dgo-radius-control); }
  a{ color:inherit; text-decoration:none; }
  :where(button,a,[tabindex]):focus-visible{ outline:none; box-shadow:var(--dgo-focus-ring); border-radius:var(--dgo-radius-control); }
  .pf-overline{ font-size:var(--dgo-type-caption); text-transform:uppercase; letter-spacing:var(--dgo-tr-widest); color:var(--dgo-color-fg-muted); font-weight:var(--dgo-wt-600); }
  @media (forced-colors: active){ :where(button,a,[tabindex]):focus-visible{ outline:2px solid Highlight; box-shadow:none; } }
  @media (prefers-reduced-motion:reduce){ *{ animation-duration:50ms !important; transition-duration:50ms !important; } }
`;
const SHARED = (() => {
  if (typeof CSSStyleSheet === 'function') {
    try {
      const sheet = new CSSStyleSheet();
      sheet.replaceSync(SHARED_CSS);
      return sheet;
    } catch (_) { return null; }
  }
  return null;
})();

export class PfBaseElement extends HTMLElement {
  static attrs = [];
  static get observedAttributes() { return this.attrs; }
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
    if (SHARED && 'adoptedStyleSheets' in this.shadowRoot) {
      try { this.shadowRoot.adoptedStyleSheets = [SHARED]; }
      catch (_) { this._appendFallbackStyle(); }
    } else {
      this._appendFallbackStyle();
    }
    this._disposers = [];
    this._renderQueued = false;
    this._listenerKeys = new WeakMap();
  }
  _appendFallbackStyle() {
    if (!this.shadowRoot || this.shadowRoot.querySelector('style[data-pf-shared]')) return;
    const style = document.createElement('style');
    style.setAttribute('data-pf-shared', 'true');
    style.textContent = SHARED_CSS;
    this.shadowRoot.appendChild(style);
  }
  connectedCallback() { this.onConnect?.(); }
  disconnectedCallback() { for (const d of this._disposers.splice(0)) { try { d(); } catch { /* ignore */ } } this.onDisconnect?.(); }
  attributeChangedCallback(name, oldVal, newVal) { this.onAttrChange?.(name, oldVal, newVal); }
  render(html) {
    this._mountHtml(this.shadowRoot, html);
    // Every render() replaces the shadow DOM with brand-new elements, so any listener
    // dedup-key recorded against the OLD elements must be forgotten here — otherwise on()
    // below silently refuses to attach a same-shaped handler to the NEW element (its old
    // target is gone, but the key survives), and that control goes permanently dead the next
    // time this component re-renders. _disposers is intentionally left alone: bus
    // subscriptions must survive a re-render, and disposers for now-detached DOM listeners are
    // harmless no-ops when they eventually run.
    this._listenerKeys = new WeakMap();
  }

  _mountHtml(root, html) {
    const raw = String(html || '');
    if (!root) return;
    if (typeof DOMParser !== 'function') {
      root.textContent = raw;
      return;
    }
    const doc = new DOMParser().parseFromString(raw, 'text/html');
    const fragment = document.createDocumentFragment();
    Array.from(doc.head ? doc.head.childNodes : []).forEach((node) => {
      fragment.appendChild(document.importNode(node, true));
    });
    Array.from(doc.body ? doc.body.childNodes : []).forEach((node) => {
      fragment.appendChild(document.importNode(node, true));
    });
    root.replaceChildren(fragment);
  }

  scheduleRender(fn, delay = 16) {
    if (this._renderQueued) return;
    this._renderQueued = true;
    setTimeout(() => { this._renderQueued = false; try { fn.call(this); } catch (e) { console.warn('component render failed', e); } }, delay);
  }
  on(target, event, handler, opts) {
    if (!target || typeof target.addEventListener !== 'function' || typeof handler !== 'function') return () => {};
    let byEvent = this._listenerKeys.get(target);
    if (!byEvent) { byEvent = new Map(); this._listenerKeys.set(target, byEvent); }
    const capture = !!(opts && typeof opts === 'object' && opts.capture);
    const key = `${event}:${capture}`;
    let handlers = byEvent.get(key);
    if (!handlers) { handlers = new Set(); byEvent.set(key, handlers); }
    if (handlers.has(handler)) return () => {};
    handlers.add(handler);
    target.addEventListener(event, handler, opts);
    const off = () => { try { target.removeEventListener(event, handler, opts); } catch (_) {} handlers.delete(handler); };
    this._disposers.push(off);
    return off;
  }
  bus(event, handler) { const off = (globalThis.Platform?.Bus)?.on(event, handler); if (off) this._disposers.push(off); return off; }
  emit(name, detail, opts) { this.dispatchEvent(new CustomEvent(name, { detail, bubbles: true, composed: true, ...opts })); }
  $(sel) { return this.shadowRoot.querySelector(sel); }
  $$(sel) { return [...this.shadowRoot.querySelectorAll(sel)]; }
  t(key, vars) { return globalThis.Platform?.I18n?.t ? globalThis.Platform.I18n.t(key, vars) : key; }
  define(tag) { if (!customElements.get(tag)) customElements.define(tag, this); }
}
export default PfBaseElement;
