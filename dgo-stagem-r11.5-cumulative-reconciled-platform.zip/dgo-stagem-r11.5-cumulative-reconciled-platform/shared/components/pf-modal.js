/** DGO R7.1.2 — <pf-modal> compliant with NITDA/DGO v2.1 modal/button/focus contracts. */
import { PfBaseElement } from './_base.js';
class PfModal extends PfBaseElement {
  onConnect() {
    this.render(`<style>
      :host{ position:fixed; inset:0; z-index:var(--dgo-z-modal); display:none; }
      :host([open]){ display:grid; place-items:center; padding:var(--dgo-s-4); }
      .scrim{ position:absolute; inset:0; background:var(--dgo-color-surface-overlay); }
      .dialog{ position:relative; inline-size:100%; max-inline-size:var(--dgo-modal-w); max-block-size:90vh; overflow:auto; background:var(--dgo-color-surface-raised); border:1px solid var(--dgo-color-border-default); border-radius:var(--dgo-modal-radius); box-shadow:var(--dgo-modal-shadow); color:var(--dgo-color-fg-default); animation:dgo-modal-in var(--dgo-motion-enter); }
      header{ display:flex; align-items:flex-start; justify-content:space-between; gap:var(--dgo-s-4); padding:var(--dgo-s-5) var(--dgo-s-6); border-block-end:1px solid var(--dgo-color-border-default); }
      header h2{ font-size:var(--dgo-type-h3); font-family:var(--dgo-family-display); font-weight:var(--dgo-wt-700); margin:0; color:var(--dgo-color-fg-strong); }
      #x{ inline-size:var(--dgo-btn-h-sm); block-size:var(--dgo-btn-h-sm); color:var(--dgo-color-fg-muted); }
      #m-body{ padding:var(--dgo-s-6); }
      .actions{ display:flex; justify-content:flex-end; gap:var(--dgo-s-2); flex-wrap:wrap; padding:var(--dgo-s-4) var(--dgo-s-6); border-block-start:1px solid var(--dgo-color-border-default); }
      .actions button{ display:inline-flex; align-items:center; justify-content:center; min-block-size:var(--dgo-btn-h-md); padding-inline:var(--dgo-btn-px-md); border-radius:var(--dgo-btn-radius); font-weight:var(--dgo-btn-fw); border:1px solid transparent; }
      .actions .primary{ background:var(--dgo-color-action-primary); color:var(--dgo-color-fg-on-brand); }
      .actions .ghost{ color:var(--dgo-color-action-primary); border-color:var(--dgo-color-border-strong); background:transparent; }
      .actions .danger{ background:var(--dgo-color-action-danger); color:var(--dgo-color-fg-on-brand); }
      .actions button[disabled]{ opacity:.55; cursor:not-allowed; pointer-events:none; }
      .pf-preview{ display:flex; flex-direction:column; gap:var(--dgo-s-1); margin-top:var(--dgo-s-2); }
      .pf-preview .row{ display:flex; justify-content:space-between; gap:var(--dgo-s-4); padding:var(--dgo-s-2) var(--dgo-s-3); border:1px solid var(--dgo-color-border-default); border-radius:var(--dgo-radius-control); background:var(--dgo-color-surface-sunken); }
      .pf-preview .k{ color:var(--dgo-color-fg-muted); font-size:var(--dgo-type-caption); }.pf-preview .v{ font-weight:var(--dgo-wt-600); font-size:var(--dgo-type-body-sm); }
      @keyframes dgo-modal-in{from{opacity:0;transform:translateY(8px) scale(.98)}to{opacity:1;transform:none}}
      @media (forced-colors:active){.dialog{border:2px solid CanvasText;box-shadow:none}.actions .primary{background:ButtonText;color:ButtonFace}}
      @media (prefers-reduced-motion:reduce){.dialog{animation:none}}
    </style><div class="scrim"></div><div class="dialog" role="dialog" aria-modal="true" aria-labelledby="m-title"><header><h2 id="m-title"></h2><button id="x" type="button" aria-label="${this.t('modal.close')}">&times;</button></header><div id="m-body"></div><div class="actions" id="m-actions"></div></div>`);
    this.bus('platform:ui:modal', (d) => this.open(d || {}));
    this.bus('platform:ui:modal-close', (d) => { if (!d?.id || !this._id || d.id === this._id) this.close('programmatic'); });
    this.bus('platform:ui:modal-busy', ({ busy } = {}) => this.setBusy(busy));
    this.on(this.$('.scrim'), 'click', () => { if (!this._busy) this.close('scrim'); });
    this.on(this.$('#x'), 'click', () => { if (!this._busy) this.close('x'); });
    this.on(document, 'keydown', (e) => { if (e.key === 'Escape' && this.hasAttribute('open') && !this._busy) this.close('escape'); });
  }
  setBusy(busy) { if (!this.hasAttribute('open')) return; this._busy=!!busy; this.$$('.actions button').forEach((b)=>{b.disabled=!!busy;b.setAttribute('aria-disabled',busy?'true':'false');}); this.$('.dialog')?.setAttribute('aria-busy', busy?'true':'false'); }
  open({ id, titleKey, title, bodyKey, bodyEl, component, props, preview, actions=[] }) { this._id=id||('modal-'+Math.random().toString(36).slice(2,8)); this._busy=false; this.$('#m-title').textContent=title||(titleKey?this.t(titleKey):''); const body=this.$('#m-body'); body.replaceChildren(); if(bodyEl instanceof Node) body.appendChild(bodyEl); else if(preview){ if(preview.summaryKey||preview.summary){ const p=document.createElement('p'); p.textContent=preview.summaryKey?this.t(preview.summaryKey):preview.summary; p.style.cssText='color:var(--dgo-color-fg-muted);font-size:var(--dgo-type-body-sm);margin-block-end:var(--dgo-s-3)'; body.appendChild(p);} if(Array.isArray(preview.details)&&preview.details.length){ const dl=document.createElement('div'); dl.className='pf-preview'; preview.details.forEach((d)=>{const row=document.createElement('div');row.className='row';const k=document.createElement('span');k.className='k';k.textContent=String(d.label||'');const v=document.createElement('span');v.className='v';v.textContent=String(d.value||'');row.append(k,v);dl.appendChild(row);}); body.appendChild(dl);} } else if(component){ const el=document.createElement(component); if(props&&typeof props==='object') Object.assign(el,props); body.appendChild(el); } else if(bodyKey) body.textContent=this.t(bodyKey); const acts=this.$('#m-actions'); acts.replaceChildren(); for(const a of actions||[]){ const b=document.createElement('button'); b.type='button'; b.className=a.variant==='danger'?'danger':a.variant==='primary'?'primary':'ghost'; b.textContent=a.label||this.t(a.labelKey||'common.actions.confirm'); b.addEventListener('click',(ev)=>{ev.preventDefault();ev.stopPropagation(); if(this._busy)return; if(a.close===false)this.setBusy(true); if(a.event)globalThis.Platform?.Bus?.emit?.(a.event,{...(a.detail||{}),modalId:this._id}); if(typeof a.onClick==='function')a.onClick({modalId:this._id,close:()=>this.close('action')}); if(a.close!==false)this.close('action');}); acts.appendChild(b);} this.setAttribute('open',''); this._release?.(); this._release=globalThis.Platform?.A11y?.trapFocus?.(this.$('.dialog')); globalThis.Platform?.A11y?.focusFirst?.(this.$('.dialog')); }
  close(reason='close'){ if(!this.hasAttribute('open'))return; const id=this._id; this._busy=false; this.removeAttribute('open'); this._release?.(); this._release=null; this.$('#m-actions')?.replaceChildren(); this.$('#m-body')?.replaceChildren(); globalThis.Platform?.Bus?.emit?.('platform:ui:modal-closed',{id,reason}); this._id=null; }
}
customElements.define('pf-modal', PfModal); export default PfModal;
