/** OBSIDIAN v4.0 — <pf-breadcrumb> · Home › current module, from route changes. */
import { PfBaseElement } from './_base.js';
class PfBreadcrumb extends PfBaseElement {
  onConnect() {
    this.render(`<style>
      :host{ display:block; }
      ol{ list-style:none; display:flex; align-items:center; gap:var(--space-2);
        font-size:var(--size-body-sm); color:var(--color-text-muted); }
      li::after{ content:"›"; margin-left:var(--space-2); color:var(--color-border-strong); }
      li:last-child::after{ content:""; }
      li[aria-current]{ color:var(--color-text); font-weight:var(--fw-semibold); }
    </style><nav aria-label="breadcrumb"><ol id="crumbs"></ol></nav>`);
    this.bus('platform:route:changed', (e) => this.paint(e.id, e.params));
    const cur = globalThis.Platform?.Router?.current?.(); if (cur?.id) this.paint(cur.id, cur.params);
  }
  paint(id, params = {}) {
    const M = globalThis.Platform?.Modules?.get?.(id);
    const label = M ? this.t(M.label) : id;
    const subRef = params?.path?.[0] || params?.ref || '';
    const crumbs = this.$('#crumbs');
    if (!crumbs) return;
    const homeLi = document.createElement('li');
    const homeLink = document.createElement('a');
    homeLink.href = '#/';
    homeLink.textContent = this.t('breadcrumb.home');
    homeLi.appendChild(homeLink);
    const moduleLi = document.createElement('li');
    if (subRef) {
      const moduleLink = document.createElement('a');
      moduleLink.href = '#/' + String(id || '');
      moduleLink.textContent = label;
      moduleLi.appendChild(moduleLink);
      const subLi = document.createElement('li');
      subLi.setAttribute('aria-current', 'page');
      subLi.textContent = subRef;
      crumbs.replaceChildren(homeLi, moduleLi, subLi);
    } else {
      moduleLi.setAttribute('aria-current', 'page');
      moduleLi.textContent = label;
      crumbs.replaceChildren(homeLi, moduleLi);
    }
  }
}
customElements.define('pf-breadcrumb', PfBreadcrumb);
export default PfBreadcrumb;
