/**
 * OBSIDIAN v4.2 — pf-app-shell Component
 * Remediated: Responsive drawer and touch-friendly sidebar toggle.
 */
import { PfBaseElement } from './_base.js';

class PfAppShell extends PfBaseElement {
  onConnect() {
    this.render(`
      <style>
        :host {
          display: block;
          min-width: 0;
          min-height: 0;
        }
        .shell {
          display: grid;
          min-width: 0;
          min-height: 100vh;
          min-height: 100dvh;
          overflow: hidden;
          grid-template-columns: var(--nav-w, 260px) 1fr;
          grid-template-rows: auto var(--header-h, 64px) 1fr auto;
          grid-template-areas:
            "banner banner"
            "header header"
            "nav main"
            "nav footer";
        }
        .banner {
          grid-area: banner;
        }
        .header {
          grid-area: header;
          position: sticky;
          top: 0;
          z-index: var(--z-sticky);
          display: flex;
          align-items: center;
          padding-inline: var(--space-5);
          background: var(--color-surface-raised);
          border-bottom: 1px solid var(--color-border);
          box-shadow: var(--shadow-xs);
        }
        .nav {
          grid-area: nav;
          position: sticky;
          top: var(--header-h, 64px);
          align-self: start;
          height: calc(100vh - var(--header-h, 64px));
          max-height: calc(100dvh - var(--header-h, 64px));
          min-height: 0;
          overflow: hidden;
          background: var(--color-surface);
          border-right: 1px solid var(--color-border);
          padding: var(--space-2) var(--space-2);
          box-sizing: border-box;
        }
        .nav ::slotted(pf-app-nav) {
          display: block;
          height: 100%;
          max-height: 100%;
          min-height: 0;
          overflow: hidden;
        }
        .main {
          grid-area: main;
          padding: clamp(.65rem, 1.2vw, 1rem);
          background: var(--color-surface-sunken);
          min-width: 0;
          overflow: auto;
          max-height: calc(100vh - var(--header-h, 64px));
          max-height: calc(100dvh - var(--header-h, 64px));
          box-sizing: border-box;
        }
        .footer {
          grid-area: footer;
          padding: var(--space-4) var(--space-7);
          background: var(--color-surface);
          border-top: 1px solid var(--color-border);
          color: var(--color-text-muted);
          font-size: var(--size-body-sm);
        }
        .scrim {
          display: none;
          position: fixed;
          inset: 0;
          background: rgba(0, 0, 0, 0.4);
          z-index: calc(var(--z-drawer) - 1);
          animation: fade-in var(--duration-fast) var(--easing-standard);
        }
        @keyframes fade-in {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        @media (orientation: portrait) {
          .shell {
            grid-template-columns: 1fr;
            grid-template-areas:
              "banner"
              "header"
              "main"
              "footer";
          }
          .nav {
            position: fixed;
            top: var(--header-h, 64px);
            bottom: 0;
            left: 0;
            width: min(80vw, 300px);
            height: calc(100vh - var(--header-h, 64px));
            z-index: var(--z-drawer);
            transform: translateX(-105%);
            transition: transform var(--duration-base) var(--easing-standard);
            border-right: 1px solid var(--color-border);
            box-shadow: var(--shadow-lg);
          }
          :host([nav-open]) .nav {
            transform: translateX(0);
          }
          :host([nav-open]) .scrim {
            display: block;
          }
        }
        /* Landscape rail collapse — single source of truth for the "hide the nav to reclaim
           width" behavior, available in landscape at any viewport width (this used to be
           implemented three times over, out-of-band, via injected !important CSS targeting the
           light-DOM <pf-app-nav> element directly; it now lives inside the component that
           actually owns the grid it's collapsing). */
        @media (orientation: landscape) {
          :host([nav-collapsed]) .shell {
            grid-template-columns: 0 1fr;
          }
          :host([nav-collapsed]) .nav {
            width: 0;
            min-width: 0;
            padding-inline: 0;
            overflow: hidden;
            border-right: 0;
            opacity: 0;
            pointer-events: none;
          }
        }
      </style>
      <div class="shell">
        <div class="banner"><slot name="banner"></slot></div>
        <div class="header"><slot name="header"></slot></div>
        <div class="scrim" id="scrim"></div>
        <div class="nav"><slot name="nav"></slot></div>
        <div class="main"><slot name="main"></slot></div>
        <div class="footer"><slot name="footer"></slot></div>
      </div>
    `);

    this.on(this.$('#scrim'), 'click', () => {
      this.removeAttribute('nav-open');
    });

    // Single toggle event, one owner: in portrait this opens/closes the off-canvas drawer; in
    // landscape it collapses/expands the persistent rail — always available in landscape,
    // regardless of how wide or narrow that landscape viewport is. Whichever trigger fires it
    // (header hamburger, keyboard shortcut, etc.), there is exactly one place that decides what
    // "toggle nav" means for the current orientation.
    this.bus('platform:nav:toggle', () => {
      if (matchMedia('(orientation: portrait)').matches) this.toggleAttribute('nav-open');
      else this.toggleAttribute('nav-collapsed');
    });

    const closeDrawer = () => this.removeAttribute('nav-open');
    this.bus('platform:nav:changed', closeDrawer);
    this.bus('platform:route:transition-start', closeDrawer);
    this.bus('platform:nav:item-selected', closeDrawer);
    this.bus('platform:nav:close', closeDrawer);

    this.on(document, 'keydown', (e) => {
      if (e.key === 'Escape' && this.hasAttribute('nav-open')) this.removeAttribute('nav-open');
    });

    // Orientation changed: drop whichever state doesn't apply on the new side so rotating back
    // doesn't resurrect a stale collapsed/open state (e.g. rotate to landscape while the
    // portrait drawer was open shouldn't leave a phantom off-canvas panel behind).
    const mq = matchMedia('(orientation: portrait)');
    const onCross = (e) => {
      if (e.matches) this.removeAttribute('nav-collapsed');
      else this.removeAttribute('nav-open');
    };
    mq.addEventListener ? mq.addEventListener('change', onCross) : mq.addListener(onCross);
    this._disposers.push(() => (mq.removeEventListener ? mq.removeEventListener('change', onCross) : mq.removeListener(onCross)));
  }
}
customElements.define('pf-app-shell', PfAppShell);
export default PfAppShell;
