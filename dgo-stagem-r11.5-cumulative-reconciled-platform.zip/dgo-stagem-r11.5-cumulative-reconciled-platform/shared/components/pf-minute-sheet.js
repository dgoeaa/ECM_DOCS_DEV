/**
 * OBSIDIAN v4.2 — pf-minute-sheet compatibility component.
 * Purpose: closes stale/optional import paths and renders a safe minute/comment container.
 */
class PfMinuteSheet extends HTMLElement {
  connectedCallback() {
    if (this.__rendered) return; this.__rendered = true;
    const title = this.getAttribute('title') || 'Minute Sheet';
    const placeholder = this.getAttribute('placeholder') || 'No minutes recorded.';
    const existingNodes = Array.from(this.childNodes);
    const section = document.createElement('section');
    section.setAttribute('part', 'sheet');
    section.style.cssText = 'border:1px solid var(--color-border,var(--dgo-color-border-default,#E8E6E7));border-radius:var(--radius-lg,var(--dgo-radius-card,.75rem));background:var(--color-surface,var(--dgo-color-surface-page,#fff));overflow:hidden;';
    const header = document.createElement('header');
    header.setAttribute('part', 'header');
    header.style.cssText = 'padding:.875rem 1rem;border-bottom:1px solid var(--color-border,var(--dgo-color-border-default,#E8E6E7));font-weight:800;';
    header.textContent = title;
    const body = document.createElement('div');
    body.setAttribute('part', 'body');
    body.style.cssText = 'padding:1rem;color:var(--color-text,var(--dgo-color-fg-default,#1B1A1A));';
    if (existingNodes.length && existingNodes.some((node) => String(node.textContent || '').trim())) {
      body.append(...existingNodes);
    } else {
      const p = document.createElement('p');
      p.style.cssText = 'margin:0;color:var(--color-text-muted,var(--dgo-color-fg-muted,#5F5C5D));';
      p.textContent = placeholder;
      body.appendChild(p);
    }
    section.append(header, body);
    this.replaceChildren(section);
  }
}
function escapeHtml(v){return String(v ?? '').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}
if (!customElements.get('pf-minute-sheet')) customElements.define('pf-minute-sheet', PfMinuteSheet);
export default PfMinuteSheet;
