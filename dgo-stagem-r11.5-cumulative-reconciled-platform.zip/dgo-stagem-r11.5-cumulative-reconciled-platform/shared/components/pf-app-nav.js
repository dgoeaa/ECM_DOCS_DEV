/** OBSIDIAN v4.0 — <pf-app-nav> · renders the audience-filtered nav model; tracks
 *  active route via aria-current; keyboard arrows/home/end; never renders its own items. */
import { PfBaseElement } from './_base.js';
class PfAppNav extends PfBaseElement {
  onConnect() {
    this.render(`<style>
      :host{ display:block; height:100%; min-height:0; overflow:hidden; }
      nav{ display:flex; flex-direction:column; gap:.35rem; height:100%; min-height:0; max-height:100%; overflow-y:auto; overscroll-behavior:contain; scrollbar-gutter:stable; padding-block:.15rem .4rem; }
      .group{ min-width:0; }
      .group__title{ font-size:var(--size-caption); text-transform:uppercase;
        letter-spacing:.055em; color:var(--color-text-muted);
        font-weight:var(--fw-semibold); padding:0 .55rem; margin:.25rem 0 .15rem; }
      ul{ list-style:none; display:flex; flex-direction:column; gap:1px; margin:0; padding:0; }
      a{ display:flex; align-items:center; min-width:0; gap:.45rem; padding:.42rem .55rem;
        border-radius:10px; color:var(--color-text); font-size:var(--size-body-sm);
        font-weight:var(--fw-medium); line-height:1.15; transition:background var(--duration-fast) var(--easing-standard); }
      a span:not(.badge):not(.dep){ min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
      a:hover{ background:var(--color-surface-sunken); }
      a[aria-current="page"]{ background:var(--color-brand-primary); color:var(--color-text-inverse); }
      a[aria-current="page"] pf-icon{ color:var(--color-text-inverse); }
      .badge{ margin-left:auto; min-width:18px; height:18px; padding:0 5px; border-radius:var(--radius-pill);
        background:var(--color-brand-accent); color:var(--color-text-inverse);
        font-size:var(--size-caption); display:inline-grid; place-items:center; }
      .dep{ margin-left:auto; font-size:var(--size-caption); color:var(--color-warning); }
      /* DGO a11y: 44px touch-target floor on touch devices (B-2 mobile-tablet target). */
      @media (pointer:coarse){ a{ min-height:44px; } }
    </style><nav aria-label="${this.t('shell.nav.aria')}"></nav>`);
    this.bus('platform:nav:rebuilt', (m) => { this._model = m; this.paint(m); });
    this.bus('platform:locale:changed', () => {
      this.$('nav')?.setAttribute('aria-label', this.t('shell.nav.aria'));
      if (this._model) this.paint(this._model);
    });
    const model = globalThis.Platform?.Nav?.model?.(); if (model) { this._model = model; this.paint(model); }
    this.on(this.$('nav'), 'keydown', (e) => this.onKey(e));
    this.on(this.$('nav'), 'click', (e) => {
      const a = e.target?.closest?.('a[href^="#/"]');
      if (!a) return;
      globalThis.Platform?.Bus?.emit?.('platform:nav:item-selected', { href: a.getAttribute('href') });
      globalThis.Platform?.Bus?.emit?.('platform:nav:close', { reason: 'item-selected' });
    });
  }
  paint(model) {
    const nav = this.$('nav'); if (!nav) return;
    nav.replaceChildren();
    (model.groups || []).forEach((g) => {
      const group = document.createElement('div');
      group.className = 'group';
      const title = document.createElement('div');
      title.className = 'group__title';
      title.textContent = this.t(g.labelKey);
      const list = document.createElement('ul');
      list.setAttribute('role', 'list');
      (g.items || []).forEach((it) => {
        const li = document.createElement('li');
        const a = document.createElement('a');
        a.href = '#/' + String(it.id || '');
        if (it.active) a.setAttribute('aria-current', 'page');
        if (it.icon) {
          const icon = document.createElement('pf-icon');
          icon.setAttribute('name', it.icon);
          a.appendChild(icon);
        }
        const label = document.createElement('span');
        label.textContent = this.t(it.labelKey);
        a.appendChild(label);
        if (it.badge) {
          const badge = document.createElement('span');
          badge.className = 'badge';
          badge.textContent = String(it.badge);
          a.appendChild(badge);
        }
        if (it.status === 'deprecated') {
          const dep = document.createElement('span');
          dep.className = 'dep';
          dep.textContent = this.t('nav.badge.deprecated');
          a.appendChild(dep);
        }
        li.appendChild(a);
        list.appendChild(li);
      });
      group.append(title, list);
      nav.appendChild(group);
    });
  }
  onKey(e) {
    const links = this.$$('a'); const i = links.indexOf(this.shadowRoot.activeElement);
    if (e.key === 'ArrowDown') { e.preventDefault(); links[Math.min(i + 1, links.length - 1)]?.focus(); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); links[Math.max(i - 1, 0)]?.focus(); }
    else if (e.key === 'Home') { e.preventDefault(); links[0]?.focus(); }
    else if (e.key === 'End') { e.preventDefault(); links[links.length - 1]?.focus(); }
  }
}
customElements.define('pf-app-nav', PfAppNav);
export default PfAppNav;
