/** DGO/NITDA v1.2.0 — DOM-free HTML entity decoding and HTML-to-text preview normalization. */
const NAMED_ENTITIES = Object.freeze({ amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ', ndash: '–', mdash: '—', hellip: '…', copy: '©', reg: '®' });
export function decodeHtmlEntities(value) {
  const input = String(value == null ? '' : value);
  if (!input || input.indexOf('&') === -1) return input;
  return input.replace(/&(#x[0-9a-f]+|#[0-9]+|[a-z][a-z0-9]+);/gi, (match, body) => {
    const key = String(body || '').toLowerCase();
    if (key[0] === '#') { const hex = key.startsWith('#x'); const n = Number.parseInt(hex ? key.slice(2) : key.slice(1), hex ? 16 : 10); if (!Number.isFinite(n) || n <= 0 || n > 0x10FFFF) return match; try { return String.fromCodePoint(n); } catch (_) { return match; } }
    return Object.prototype.hasOwnProperty.call(NAMED_ENTITIES, key) ? NAMED_ENTITIES[key] : match;
  });
}
export function stripHtmlToText(value) {
  const raw = String(value == null ? '' : value); if (!raw) return '';
  let s = raw.replace(/<!doctype[^>]*>/ig, ' ').replace(/<style[\s\S]*?<\/style>/ig, ' ').replace(/<script[\s\S]*?<\/script>/ig, ' ').replace(/<br\s*\/?\s*>/ig, '\n').replace(/<\/p>/ig, '\n').replace(/<[^>]+>/g, ' ');
  return decodeHtmlEntities(s).replace(/\s+/g, ' ').trim();
}
export default { decodeHtmlEntities, stripHtmlToText };
