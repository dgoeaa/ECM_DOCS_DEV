/** OBSIDIAN v4.4 - dom.js - tiny DOM helpers (no framework). */
const SAFE_HTML_TAGS = new Set([
  'span', 'strong', 'em', 'b', 'i', 'small', 'code', 'kbd', 'mark', 'br',
  'p', 'div', 'ul', 'ol', 'li', 'span', 'pf-icon'
]);
const SAFE_ATTRS = new Set(['class', 'title', 'role', 'aria-label', 'aria-hidden', 'aria-live', 'aria-atomic', 'data-state', 'data-key', 'data-ref', 'data-id', 'name', 'size']);

function isSafeAttr(name) {
  const n = String(name || '').toLowerCase();
  return SAFE_ATTRS.has(n) || n.startsWith('data-') || n.startsWith('aria-');
}

function appendSanitizedNode(target, sourceNode) {
  if (!sourceNode) return;
  if (sourceNode.nodeType === Node.TEXT_NODE) {
    target.append(document.createTextNode(sourceNode.textContent || ''));
    return;
  }
  if (sourceNode.nodeType !== Node.ELEMENT_NODE) return;
  const tag = sourceNode.tagName.toLowerCase();
  if (!SAFE_HTML_TAGS.has(tag)) {
    target.append(document.createTextNode(sourceNode.textContent || ''));
    return;
  }
  const node = document.createElement(tag);
  for (const attr of Array.from(sourceNode.attributes || [])) {
    if (isSafeAttr(attr.name)) node.setAttribute(attr.name, attr.value);
  }
  for (const child of Array.from(sourceNode.childNodes || [])) appendSanitizedNode(node, child);
  target.append(node);
}

export function safeHtmlFragment(html) {
  const fragment = document.createDocumentFragment();
  const raw = String(html || '');
  if (!raw) return fragment;
  if (typeof DOMParser !== 'function') {
    fragment.append(document.createTextNode(raw));
    return fragment;
  }
  const doc = new DOMParser().parseFromString(`<body>${raw}</body>`, 'text/html');
  for (const child of Array.from(doc.body.childNodes)) appendSanitizedNode(fragment, child);
  return fragment;
}

export function el(tag, attrs = {}, children = []) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === 'class') node.className = v;
    else if (k === 'html') node.append(safeHtmlFragment(v));
    else if (k === 'text') node.textContent = v;
    else if (k.startsWith('on') && typeof v === 'function') node.addEventListener(k.slice(2).toLowerCase(), v);
    else if (v !== null && v !== undefined) node.setAttribute(k, v);
  }
  for (const c of [].concat(children)) if (c != null) node.append(c.nodeType ? c : document.createTextNode(String(c)));
  return node;
}
export function clear(node) { while (node && node.firstChild) node.removeChild(node.firstChild); }
export const firstArray = (data) => Array.isArray(data) ? data
  : (data && typeof data === 'object') ? (Object.values(data).find(Array.isArray) || []) : [];

export async function withBusy(control, fn) {
  if (typeof fn !== 'function') return undefined;

  if (control && control.dataset && control.dataset.pfBusy === 'true') {
    return undefined;
  }

  const hadControl = !!control;
  const previousDisabled = hadControl ? !!control.disabled : false;

  try {
    if (hadControl) {
      if (control.dataset) control.dataset.pfBusy = 'true';
      control.disabled = true;
      control.setAttribute('aria-busy', 'true');
    }

    return await fn();
  } finally {
    if (hadControl) {
      if (control.dataset) control.dataset.pfBusy = 'false';
      control.disabled = previousDisabled;
      control.removeAttribute('aria-busy');
    }
  }
}
