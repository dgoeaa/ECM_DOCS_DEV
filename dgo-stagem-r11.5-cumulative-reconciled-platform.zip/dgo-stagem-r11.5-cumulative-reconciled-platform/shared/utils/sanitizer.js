/**
 * OBSIDIAN v4.2 — Sanitizer
 * Remediated (REL-02): Safely support style blocks in incoming email correspondence previews.
 */
const TAG_SAFELIST = new Set([
  'p', 'br', 'strong', 'em', 'u', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 
  'ul', 'ol', 'li', 'span', 'div', 'table', 'thead', 'tbody', 'tr', 'th', 'td', 
  'blockquote', 'a', 'img', 'style' // Remediated: allow style blocks
]);

const ATTRIBUTE_SAFELIST = {
  'a': ['href', 'title', 'target', 'class', 'style'],
  'img': ['src', 'alt', 'title', 'class', 'style', 'width', 'height'],
  'span': ['class', 'style'],
  'div': ['class', 'style'],
  'p': ['class', 'style'],
  'td': ['style', 'class', 'colspan', 'rowspan'],
  'th': ['style', 'class', 'colspan', 'rowspan'],
  'table': ['style', 'class'],
  'style': ['type']
};

const UNSAFE_SCHEMES = /^(javascript|data|vbscript):/i;


function serializeChildren(body) {
  const serializer = typeof XMLSerializer === 'function' ? new XMLSerializer() : null;
  if (!serializer) return body.textContent || '';
  return Array.from(body.childNodes).map((node) => {
    if (node.nodeType === Node.TEXT_NODE) return node.textContent || '';
    return serializer.serializeToString(node);
  }).join('');
}

export const Sanitizer = {
  cleanHTML(htmlString) {
    if (!htmlString || typeof htmlString !== 'string') return '';
    const parser = new DOMParser();
    const doc = parser.parseFromString(htmlString, 'text/html');
    const body = doc.body || doc.createElement('body');
    const treeWalker = document.createTreeWalker(
      body,
      NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT | NodeFilter.SHOW_COMMENT,
      null,
      false
    );
    const nodesToRemove = [];
    let currentNode = treeWalker.nextNode();
    while (currentNode) {
      if (currentNode.nodeType === Node.COMMENT_NODE) {
        nodesToRemove.push(currentNode);
      } else if (currentNode.nodeType === Node.ELEMENT_NODE) {
        const tagName = currentNode.tagName.toLowerCase();
        if (!TAG_SAFELIST.has(tagName)) {
          nodesToRemove.push(currentNode);
        } else if (tagName === 'style') {
          // Remediated (REL-02): Purge style elements containing scripts or expressions, otherwise preserve
          const css = currentNode.textContent;
          if (/expression\s*\(|javascript\s*:|url\s*\(\s*['"]?\s*javascript/i.test(css) || /@import/i.test(css)) {
            nodesToRemove.push(currentNode);
          }
        } else {
          const attrs = Array.from(currentNode.attributes);
          const allowedAttrs = ATTRIBUTE_SAFELIST[tagName] || [];
          for (const attr of attrs) {
            const attrName = attr.name.toLowerCase();
            const isStyleOrClass = ['style', 'class'].includes(attrName);
            if (!isStyleOrClass && !allowedAttrs.includes(attrName)) {
              currentNode.removeAttribute(attr.name);
            } else if (attrName === 'href' || attrName === 'src') {
              if (UNSAFE_SCHEMES.test(attr.value.trim())) {
                currentNode.removeAttribute(attr.name);
              }
            }
          }
        }
      }
      currentNode = treeWalker.nextNode();
    }
    nodesToRemove.forEach(node => {
      if (node.parentNode) {
        node.parentNode.removeChild(node);
      }
    });
    return serializeChildren(body);
  },
  safeUrl(url) {
    const raw = String(url || '').trim();
    if (!raw) return '';
    if (UNSAFE_SCHEMES.test(raw)) return '#';
    return raw
      .replace(/&/g, '&amp;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }
};
export default Sanitizer;
