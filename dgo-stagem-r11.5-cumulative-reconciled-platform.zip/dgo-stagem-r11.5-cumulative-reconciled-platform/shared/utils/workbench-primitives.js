/**
 * DGO Stage M-R8.1 — Shared workbench primitives.
 *
 * These helpers address repeated module shell, toolbar, table-wrapper, and state-region patterns
 * without changing any existing module behavior before browser certification. Modules can adopt
 * these incrementally after visual regression tests.
 */
import { el, clear } from './dom.js';

export function createWorkbenchSection({ title = '', eyebrow = '', body = '', className = 'pf-card', actions = [] } = {}) {
  const header = el('div', { class: 'pf-workbench-section__header' }, [
    eyebrow ? el('span', { class: 'pf-overline', text: eyebrow }) : null,
    title ? el('h2', { class: 'pf-workbench-section__title', text: title }) : null,
    body ? el('p', { class: 'pf-muted', text: body }) : null
  ].filter(Boolean));
  const actionWrap = actions.length ? el('div', { class: 'pf-workbench-section__actions' }, actions) : null;
  return el('section', { class: `pf-workbench-section ${className}` }, [header, actionWrap].filter(Boolean));
}

export function createToolbar({ label = '', actions = [], meta = [] } = {}) {
  return el('div', { class: 'pf-toolbar pf-toolbar--shared' }, [
    label ? el('span', { class: 'pf-overline', text: label }) : null,
    meta.length ? el('div', { class: 'pf-toolbar__meta' }, meta) : null,
    actions.length ? el('div', { class: 'pf-toolbar__actions' }, actions) : null
  ].filter(Boolean));
}

export function createTableShell(table, { renderedRows = 0, totalRows = 0, label = 'Data table' } = {}) {
  return el('div', {
    class: 'pf-table-wrap pf-table-wrap--shared',
    role: 'region',
    'aria-label': label,
    tabindex: '0',
    'data-rendered-rows': String(renderedRows || 0),
    'data-total-rows': String(totalRows || renderedRows || 0)
  }, [table]);
}

export function replaceWithState(container, state = 'empty', { title = '', body = '', action = null } = {}) {
  clear(container);
  const node = el('section', {
    class: `pf-state pf-state--${state}`,
    role: state === 'error' ? 'alert' : 'status',
    'aria-live': state === 'error' ? 'assertive' : 'polite'
  }, [
    el('div', { class: 'pf-state__copy' }, [
      title ? el('div', { class: 'pf-state__title', text: title }) : null,
      body ? el('p', { class: 'pf-state__body', text: body }) : null
    ].filter(Boolean)),
    action
  ].filter(Boolean));
  container.append(node);
  return node;
}

export function createActionFooter(actions = []) {
  return el('div', { class: 'pf-action-footer', role: 'group', 'aria-label': 'Action controls' }, actions);
}

export default { createWorkbenchSection, createToolbar, createTableShell, replaceWithState, createActionFooter };
