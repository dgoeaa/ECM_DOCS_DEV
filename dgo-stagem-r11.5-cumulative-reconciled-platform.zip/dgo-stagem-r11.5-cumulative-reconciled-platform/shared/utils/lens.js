/**
 * OBSIDIAN v4.2 — Central Layout Primitives & Active View Engine
 * Remediated: Solved Operations Hub row click locking; integrated robust state transitions.
 */
import { el, clear } from './dom.js';
import { buildSlaMeterModel } from '../domain/sla-projection.js';
import { buildOperationalKpis } from '../domain/rollups.js';
import { buildTraceViewModel } from '../domain/reference-trace.js';
import { createFilterCache } from './filter-cache.js';
import { stripHtmlToText } from './html-entities.js';
import { BaseService } from '../../core/base-service.js';

const P = () => globalThis.Platform;
const t = (k, v) => (P()?.I18n?.t ? P().I18n.t(k, v) : k);
const SMAP = { pending:'pending', routed:'routed', replied:'replied', acknowledged:'replied',
  'action required':'action', action:'action', closed:'archived', archived:'archived',
  draft:'draft', escalated:'action', resolved:'replied', approved:'replied', rejected:'action', created:'replied' };
const sCls = (v) => SMAP[String(v || '').toLowerCase()] || 'archived';
const badgeEl = (v) => el('span', { class: `pf-badge pf-badge--${sCls(v)}`, text: String(v || '') });
const CROSS = [['email','correspondence','mail'],['comment','comments','message-square'],
  ['approval','approvals','check-circle'],['task','orchestrator','workflow'],
  ['document','ops-hub','folder'],['reference','response-tracking','table']];


function stripHtmlPreview(value) {
  return stripHtmlToText(value);
}
function displayFieldValue(key, value) {
  const k = String(key || '').toLowerCase();
  if (k.includes('body') || k.includes('html') || k.includes('preview') || k.includes('content') || /<!doctype|<html|<body|<head/i.test(String(value || ''))) return stripHtmlPreview(value);
  return value;
}

function fmt(v) { return P()?.Format?.dateTime ? P().Format.dateTime(v) : String(v); }

function cellVal(r, c) {
  if (!r || !c) return '';
  const key = c.key;
  if (key === 'referenceId') return r.__ref || '';
  if (key === 'ts' || key === 'createdAt' || key === 'date') {
    const d = r[key] || r.ts || r.createdAt || r.Created;
    return d ? fmt(d) : '';
  }
  let v = r[key];
  if ((v == null || v === '') && key) v = r[key.charAt(0).toUpperCase() + key.slice(1)];
  return (v == null) ? '' : displayFieldValue(key, v);
}

const META_FIELD_KEYS = new Set(['__ref', '__id', 'status', 'Status', 'referenceId', 'RefIDD', '_sla']);
function humanize(k) { return k.replace(/([A-Z])/g, ' $1').replace(/^./, (c) => c.toUpperCase()).trim(); }
function deriveFields(r, columnsHint) {
  const out = [], shown = new Set();
  if (columnsHint) {
    for (const c of columnsHint) {
      if (META_FIELD_KEYS.has(c.key) || c.key === 'referenceId') continue;
      const v = cellVal(r, c);
      if (v !== '' && v != null && typeof v !== 'object') { out.push({ label: t(c.labelKey), value: String(v) }); shown.add(c.key); }
    }
  }
  for (const [k, v] of Object.entries(r)) {
    if (META_FIELD_KEYS.has(k) || shown.has(k)) continue;
    if (v == null || v === '' || typeof v === 'object') continue;
    out.push({ label: humanize(k), value: String(displayFieldValue(k, v)) });
  }
  return out;
}

export function appendRichSections(detail, r, mod, { type, enableComments = true, enableActivity = true, enableAttachments = true, enableReminder = true } = {}) {
  if (!r) return;
  const ref = r.__ref || r.referenceId || r.RefIDD || '';
  const trace = ref ? buildTraceViewModel(ref) : { bundle: {}, timeline: [], counts: {} };

  if (enableComments && ref && type !== 'comment') {
    const items = trace.bundle.comment || [];
    const sec = el('details', { class: 'pf-detail__section pf-detail__collapsible' });
    if (items.length) sec.setAttribute('open', '');
    sec.append(el('summary', {}, [
      el('span', { class: 'pf-overline', text: t('lens.comments') }),
      el('span', { class: 'pf-detail__count', text: String(items.length) })
    ]));
    const thread = document.createElement('pf-comment-thread');
    thread.reference = ref; thread.items = items;
    sec.append(thread);
    detail.append(sec);
  }

  if (enableActivity && ref && type !== 'activity') {
    const acts = (trace.bundle.activity || []).slice().sort((a, b) => String(b.ts || '').localeCompare(String(a.ts || '')));
    if (acts.length) {
      const sec = el('details', { class: 'pf-detail__section pf-detail__collapsible' });
      sec.append(el('summary', {}, [
        el('span', { class: 'pf-overline', text: t('lens.activity') }),
        el('span', { class: 'pf-detail__count', text: String(acts.length) })
      ]));
      const list = el('ol', { class: 'pf-detail__activity' });
      acts.forEach((a) => list.append(el('li', { class: 'pf-detail__activity-item' }, [
        el('div', { class: 'pf-detail__activity-when', text: a.ts ? fmt(a.ts) : '' }),
        el('div', { class: 'pf-detail__activity-what', text: a.action || a.__id || '' }),
        a.status ? badgeEl(a.status) : null
      ].filter(Boolean))));
      sec.append(list);
      detail.append(sec);
    }
  }

  if (enableAttachments && (r.emailId || (type === 'email' && r.__id))) {
    const sec = el('details', { class: 'pf-detail__section pf-detail__collapsible' });
    sec.setAttribute('open', '');
    sec.append(el('summary', {}, [el('span', { class: 'pf-overline', text: t('lens.attachments') })]));
    const att = document.createElement('pf-attachment');
    att.emailId = r.emailId || r.__id;
    sec.append(att);
    detail.append(sec);
  }
}

export function renderRichDetail(detail, r, mod, opts = {}) {
  const { type, columns = [], linked = true, actions = null, selectHintKey = 'lens.selectHint' } = opts;
  clear(detail);
  if (!r) {
    detail.append(el('div', { class: 'pf-detail__empty' }, [
      el('pf-icon', { name: 'table', size: '22' }),
      el('p', { class: 'pf-muted', text: t(selectHintKey) })]));
    return;
  }
  const ref = r.__ref || r.referenceId || r.RefIDD || '';
  const trace = ref ? buildTraceViewModel(ref) : { bundle: {}, timeline: [], counts: {} };
  detail.append(el('div', { class: 'pf-detail__head' }, [
    el('h3', { class: 'pf-detail__title', text: r.title || r.subject || ref || r.__id || '' }),
    badgeEl(r.status || r.Status || '')]));
  if (ref) detail.append(el('div', { class: 'pf-detail__ref', text: ref }));
  const flds = deriveFields(r, columns);
  if (flds.length) {
    const dl = el('dl', { class: 'pf-detail__fields' });
    flds.forEach((f) => dl.append(el('dt', { text: f.label }), el('dd', { text: f.value })));
    detail.append(dl);
  }
  appendRichSections(detail, r, mod, { type });
}

export function mountMasterDetail(mod, root, { type, cardLabel, detail, enableBulkSelect = false, bulkActions = null, prefilter = null }) {
  const region = root.querySelector('[data-region="content"]') || root;
  clear(region);
  const E = P().Entities;
  const filter = document.createElement('pf-filter-bar');
  filter.statuses = [{ value:'pending', labelKey:'status.pending' }, { value:'routed', labelKey:'status.routed' }, { value:'replied', labelKey:'status.replied' }, { value:'closed', labelKey:'status.closed' }];
  const split = el('div', { class: 'pf-md__split', 'data-view-mode': 'master' });
  const gallery = el('div', { class: 'pf-md__gallery', 'data-region': 'list', role: 'list' });
  const detailPane = el('div', { class: 'pf-card pf-md__detail', 'data-region': 'detail', 'aria-live': 'polite', 'aria-label': t('lens.detailLabel') });
  const back = el('button', { class: 'pf-btn pf-btn--ghost pf-detail-back', type: 'button', text: 'Back to list', 'aria-label': 'Back to list' });
  back.addEventListener('click', () => { split.dataset.viewMode = 'master'; gallery.querySelector('[aria-selected="true"]')?.focus?.(); });
  detailPane.append(back);
  split.append(gallery, detailPane);
  const bulkBar = el('div', { class: 'pf-md__bulkbar', hidden: true, role: 'status', 'aria-live': 'polite' });
  let q = '', st = '';
  region.append(filter, bulkBar, el('div', { style: 'height:var(--space-3)' }), split);
  const selected = new Set();
  let activeKey = '';

  function keyOf(r) { return r && (r.__ref || r.__id || r.referenceId || r.RefIDD || ''); }
  function normalizedStatus(r) { return String((r && (r.status || r.Status)) || '').toLowerCase().trim(); }
  function rowsInScope() {
    return E.all(type).filter((r) => {
      if (typeof prefilter === 'function' && !prefilter(r)) return false;
      const s = normalizedStatus(r);
      if (st && s !== st) return false;
      if (!q) return true;
      return Object.values(r).some((v) => String(v).toLowerCase().includes(q));
    });
  }

  function renderBulkBar() {
    if (!enableBulkSelect) { bulkBar.hidden = true; return; }
    bulkBar.hidden = selected.size === 0;
    clear(bulkBar);
    if (selected.size === 0) return;
    bulkBar.append(el('span', { class: 'pf-md__bulkcount', text: t('lens.selectedN', { n: selected.size }) }));
    if (typeof bulkActions === 'function') {
      const acts = bulkActions({ selected: [...selected], clear: () => { selected.clear(); render(); }, mod }) || [];
      acts.forEach((b) => bulkBar.append(b));
    }
  }

  function renderEmpty() {
    gallery.append(el('div', { class: 'pf-empty' }, [
      el('div', { class: 'pf-empty__title', text: t('common.state.empty') }),
      el('p', { class: 'pf-empty__hint', text: t('lens.emptyHint') })
    ]));
    detail(null, detailPane, mod);
    renderBulkBar();
  }

  function selectRow(r, card) {
    const key = keyOf(r);
    activeKey = key;
    [...gallery.querySelectorAll('.pf-md__card')].forEach((c) => {
      const on = c === card;
      c.classList.toggle('is-active', on);
      c.setAttribute('aria-selected', on ? 'true' : 'false');
    });
    if (r.__ref) P().Context.setActive(r.__ref, mod.id);
    detail(r, detailPane, mod);
    detailPane.prepend(back);
    split.dataset.viewMode = 'detail';
  }

  function toggleBulk(r, checked) {
    const key = keyOf(r); if (!key) return;
    if (checked) selected.add(key); else selected.delete(key);
    renderBulkBar();
  }

  function render() {
    const rows = rowsInScope(); filter.count = rows.length; clear(gallery);
    if (!rows.length) { renderEmpty(); return; }
    rows.forEach((r) => {
      const key = keyOf(r);
      const isSel = enableBulkSelect && selected.has(key);
      const children = [];
      let card;
      if (enableBulkSelect) {
        const check = el('input', { class: 'pf-md__bulkcheck', type: 'checkbox', 'aria-label': t('lens.selectedN', { n: 1 }), ...(isSel ? { checked: 'checked' } : {}) });
        check.addEventListener('click', (e) => e.stopPropagation());
        check.addEventListener('change', (e) => { toggleBulk(r, e.target.checked); card.classList.toggle('is-selected', e.target.checked); });
        children.push(el('div', { class: 'pf-md__select' }, [check]));
      }
      children.push(
        el('div', { class: 'pf-md__card-top' }, [el('span', { class: 'pf-badge', text: r.status || r.Status || 'Pending' }), el('span', { class: 'pf-md__ref', text: r.__ref || '', style: 'color:var(--dgo-color-fg-muted);font-weight:600;' })]),
        el('div', { class: 'pf-md__card-title', text: r[cardLabel] || r.title || r.subject || r.__id || '' }),
        el('div', { class: 'pf-md__card-sub', text: r.assignedTo || r.sender || r.from || '' })
      );
      card = el('div', { class: 'pf-md__card' + (isSel ? ' is-selected' : '') + (activeKey === key ? ' is-active' : ''), role: 'option', tabindex: '0', 'aria-selected': activeKey === key ? 'true' : 'false', 'data-ref': key, style: 'cursor:pointer;position:relative;padding:16px;border:1px solid var(--dgo-color-border-default);border-radius:10px;display:flex;flex-direction:column;gap:8px;background:var(--dgo-color-surface-raised);' }, children);
      card.addEventListener('click', () => selectRow(r, card));
      card.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') { e.preventDefault(); selectRow(r, card); }
        if (e.key === ' ') { e.preventDefault(); if (enableBulkSelect) { const cb = card.querySelector('.pf-md__bulkcheck'); cb.checked = !cb.checked; cb.dispatchEvent(new Event('change', { bubbles: true })); } else selectRow(r, card); }
      });
      gallery.append(card);
    });
    renderBulkBar();
    if (activeKey && !rows.some((r) => keyOf(r) === activeKey)) detail(null, detailPane, mod);
  }

  filter.addEventListener('pf-filter:change', (e) => { q = e.detail.query || ''; st = e.detail.status || ''; render(); });
  mod.bus('entity:loading', render); mod.bus('entity:bootstrapped', render); mod.bus('entity:changed', render);
  render();
}

export function mountTabbedLens(mod, root, { tabs, defaultTab, toolbar = null }) {
  const region = root.querySelector('[data-region="content"]') || root;
  clear(region);
  const bar = el('div', { class: 'pf-subnav', role: 'tablist' });
  const toolHost = el('div', { class: 'pf-subnav__toolbar' });
  const panel = el('div', { class: 'pf-subpanel' });
  region.append(bar, toolHost, panel);
  let active = defaultTab || tabs[0].id;
  function paintBar() {
    clear(bar);
    tabs.forEach((tb) => {
      const count = typeof tb.count === 'function' ? tb.count() : null;
      const b = el('button', { class: 'pf-subnav__tab' + (tb.id === active ? ' is-active' : ''), role: 'tab',
        'aria-selected': tb.id === active ? 'true' : 'false',
        text: t(tb.labelKey) });
      if (count != null) b.append(el('span', { class: 'pf-subnav__count', text: String(count) }));
      b.addEventListener('click', () => { active = tb.id; render(); });
      bar.append(b);
    });
  }
  function render() {
    paintBar(); clear(toolHost);
    if (typeof toolbar === 'function') {
      const items = toolbar({ active, mod }) || [];
      items.forEach((b) => toolHost.append(b));
    }
    clear(panel);
    const tab = tabs.find((x) => x.id === active) || tabs[0];
    tab.render(panel, mod);
  }
  mod.bus('entity:bootstrapped', render); mod.bus('entity:changed', render); mod.bus('context:reference:changed', render);
  render();
}

export function renderFabricTable(container, rows, columns, onRow, opts = {}) {
  const { type, detail = false, linked = true, actions = null, mod = null, selectHintKey = 'lens.selectHint', pageSize = 100 } = opts;
  clear(container);
  if (!rows.length) {
    container.append(el('div', { class: 'pf-empty' }, [el('div', { class: 'pf-empty__title', text: t('common.state.empty') })]));
    return;
  }
  const split = el('div', { class: 'pf-list__split', 'data-view-mode': 'master' });
  const main = el('div', { class: 'pf-list__main' });
  const wrap = el('div', { class: 'pf-card pf-table-wrap' });
  const detailEl = el('aside', { class: 'pf-card pf-list__detail', 'aria-live': 'polite' });
  const back = el('button', { class: 'pf-btn pf-btn--ghost pf-detail-back', type: 'button', text: 'Back to list', 'aria-label': 'Back to list' });
  back.addEventListener('click', () => { split.dataset.viewMode = 'master'; main.querySelector('[aria-selected="true"]')?.focus?.(); });
  
  function _fabricTable(rows, columns, onRow) {
    const head = el('thead', {}, [el('tr', {}, columns.map((c) => el('th', { text: t(c.labelKey) })))]);
    const body = el('tbody', {}, rows.map((r) => {
      const tr = el('tr', { 'data-ref': r.__ref || '', style: 'cursor:pointer;' }, columns.map((c) => {
        const v = cellVal(r, c);
        return c.key === 'status' ? el('td', {}, [badgeEl(v)]) : el('td', { text: String(v) });
      }));
      tr.addEventListener('click', () => onRow(r, tr));
      return tr;
    }));
    return el('table', { class: 'pf-table pf-table--selectable' }, [head, body]);
  }

  function rerender() {
    clear(wrap); 
    wrap.append(_fabricTable(rows, columns, (r, tr) => {
      container.querySelectorAll('tr').forEach(row => row.setAttribute('aria-selected', 'false'));
      tr.setAttribute('aria-selected', 'true');
      renderRichDetail(detailEl, r, mod, { type, columns, linked, actions, selectHintKey });
      detailEl.prepend(back);
      split.dataset.viewMode = 'detail';
      if (onRow) onRow(r, tr);
    }));
  }
  rerender();
  main.append(wrap); split.append(main, detailEl); container.append(split);
  renderRichDetail(detailEl, null, mod, { type, columns, linked, actions, selectHintKey });
}
export function skeletonTiles(count = 3) {
  return el('div', { class: 'pf-grid' }, Array.from({ length: count }, () =>
    el('div', {
      class: 'pf-card pf-skeleton',
      'aria-hidden': 'true',
      style: 'min-height:96px'
    })
  ));
}

export function skeletonTable(rows = 6, cols = 5) {
  const head = el('thead', {}, [
    el('tr', {}, Array.from({ length: cols }, () => el('th', { text: ' ' })))
  ]);

  const body = el('tbody', {}, Array.from({ length: rows }, () =>
    el('tr', {}, Array.from({ length: cols }, () =>
      el('td', {}, [el('span', { class: 'pf-skeleton', style: 'display:block;height:1em' })])
    ))
  ));

  return el('div', { class: 'pf-card pf-table-wrap', 'aria-hidden': 'true' }, [
    el('table', { class: 'pf-table' }, [head, body])
  ]);
}

export function attentionList(titleKey, items = [], { modId = null } = {}) {
  const list = Array.isArray(items) ? items : [];
  const card = el('section', { class: 'pf-card', style: 'padding:var(--space-5)' }, [
    el('div', { class: 'pf-overline', text: t(titleKey) })
  ]);

  if (!list.length) {
    card.append(el('div', { class: 'pf-empty', text: t('agg.clear') }));
    return card;
  }

  card.append(el('ul', { class: 'pf-list' }, list.slice(0, 8).map((r) => {
    const row = el('li', { class: 'pf-list__item' }, [
      el('strong', { text: r.title || r.subject || r.__ref || r.__id || '' }),
      el('span', { text: r.__ref || '' })
    ]);

    if (modId && r.__ref) {
      row.addEventListener('click', () => P().Context.setActive(r.__ref, modId));
    }

    return row;
  })));

  return card;
}

export function breakdownBars(titleKey, counts = {}, { accent = 'var(--color-accent)' } = {}) {
  const entries = Object.entries(counts || {});
  const max = Math.max(1, ...entries.map(([, v]) => Number(v) || 0));

  return el('section', { class: 'pf-card', style: 'padding:var(--space-5)' }, [
    el('div', { class: 'pf-overline', text: t(titleKey) }),
    el('div', { class: 'pf-stack' }, entries.map(([k, v]) =>
      el('div', { class: 'pf-bar-row' }, [
        el('span', { text: k }),
        el('div', {
          class: 'pf-bar',
          style: 'height:8px;background:var(--color-surface-muted);border-radius:999px;overflow:hidden'
        }, [
          el('span', {
            style: `display:block;height:100%;width:${Math.round(((Number(v) || 0) / max) * 100)}%;background:${accent}`
          })
        ]),
        el('strong', { text: String(v) })
      ])
    ))
  ]);
}

export function buildDocEmailPairs() {
  const E = P().Entities;
  const docs = E.all('document') || [];
  const emailsByRef = new Map((E.all('email') || []).map((e) => [e.__ref, e]));

  return docs
    .filter((d) => d.__ref && emailsByRef.has(d.__ref))
    .map((d) => {
      const email = emailsByRef.get(d.__ref);
      return {
        referenceId: d.__ref,
        docTitle: d.title || d.subject || d.__id || '',
        emailSubject: email.subject || email.title || email.__id || ''
      };
    });
}

export function renderHeatmap(
  container,
  rows = [],
  { weeks = 14, startDaysAgo = 21, dueField = 'dueDate', fallbackFields = [], onCellClick = null } = {}
) {
  clear(container);

  const start = new Date();
  start.setDate(start.getDate() - startDaysAgo);

  const days = weeks * 7;
  const byDay = new Map();

  for (const r of rows || []) {
    const raw = r[dueField] || fallbackFields.map((f) => r[f]).find(Boolean);
    if (!raw) continue;

    const d = new Date(raw);
    if (Number.isNaN(d.getTime())) continue;

    const key = d.toISOString().slice(0, 10);
    if (!byDay.has(key)) byDay.set(key, []);
    byDay.get(key).push(r);
  }

  const grid = el('div', { class: 'pf-heatmap', role: 'grid' });

  for (let i = 0; i < days; i++) {
    const d = new Date(start);
    d.setDate(start.getDate() + i);

    const key = d.toISOString().slice(0, 10);
    const items = byDay.get(key) || [];

    const cell = el('button', {
      class: 'pf-heatmap__cell',
      type: 'button',
      title: `${key}: ${items.length}`,
      text: items.length ? String(items.length) : ''
    });

    if (onCellClick) {
      cell.addEventListener('click', () => onCellClick({ date: key, items }));
    }

    grid.append(cell);
  }

  container.append(grid);
}

export function mountListLens(
  mod,
  root,
  { type, columns = [], actions = null, linked = true, prefilter = null } = {}
) {
  const region = root.querySelector('[data-region="content"]') || root;
  const E = P().Entities;

  function render() {
    const rows = (E.all(type) || []).filter((r) => prefilter ? prefilter(r) : true);

    renderFabricTable(
      region,
      rows,
      columns,
      (r) => {
        if (r.__ref) P().Context.setActive(r.__ref, mod.id);
      },
      { type, mod, linked, actions }
    );
  }

  mod.bus('entity:loading', render);
  mod.bus('entity:bootstrapped', render);
  mod.bus('entity:changed', render);
  mod.bus('context:reference:changed', render);

  render();
}
export function mountAggregator(mod, root, { tiles, table = null }) {
  const region = root.querySelector('[data-region="content"]') || root;
  const E = P().Entities;
  function render() {
    clear(region);
    if (!E.isHydrated()) return;
    const model = buildOperationalKpis();
    const c = model.counts || {};
    region.append(el('div', { class: 'pf-grid' }, tiles.map(([type, modId, icon]) => {
      const card = el('button', { class: 'pf-stat', style: 'text-align:left;width:100%;cursor:pointer' }, [
        el('div', { class: 'pf-stat__label', text: `${icon} ${t('entity.' + type)}` }),
        el('div', { class: 'pf-stat__value', text: String(c[type] || 0) })]);
      if (modId) card.addEventListener('click', () => P().Router.navigate(modId));
      return card;
    })));
  }
  mod.bus('entity:loading', render); mod.bus('entity:bootstrapped', render); mod.bus('entity:changed', render); render();
}

/** Operator HUD SLA meter DOM model.
 * renderSlaMeterNode() is the runtime-safe renderer used by modules. renderSlaMeter()
 * remains for export/report string contexts only.
 */
export function renderSlaMeterNode(taskOrValue) {
  const model = buildSlaMeterModel(taskOrValue);
  const pct = Math.max(0, Math.min(100, Math.round(model.pct || 0)));
  const tone = model.key === 'overdue' ? 'danger' : model.key === 'dueSoon' ? 'warn' : model.key === 'onTrack' ? 'ok' : 'muted';
  const label = String(model.label || 'Unknown');
  return el('span', { class: `pf-sla pf-sla--${tone}`, title: `${label}: ${pct}%`, 'aria-label': `${label}: ${pct}%` }, [
    el('span', { class: 'pf-sla__bar' }, [el('span', { class: 'pf-sla__fill', style: `width:${pct}%` })]),
    el('span', { class: 'pf-sla__text', text: label })
  ]);
}

/** Backward-compatible string renderer for export/report contexts only. */
export function renderSlaMeter(taskOrValue) {
  const model = buildSlaMeterModel(taskOrValue);
  const pct = Math.max(0, Math.min(100, Math.round(model.pct || 0)));
  const tone = model.key === 'overdue' ? 'danger' : model.key === 'dueSoon' ? 'warn' : model.key === 'onTrack' ? 'ok' : 'muted';
  const safeLabel = String(model.label || 'Unknown').replace(/[&<>"]/g, (c) => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;' }[c]));
  return `<span class="pf-sla pf-sla--${tone}" title="${safeLabel}: ${pct}%" aria-label="${safeLabel}: ${pct}%"><span class="pf-sla__bar"><span class="pf-sla__fill" style="width:${pct}%"></span></span><span class="pf-sla__text">${safeLabel}</span></span>`;
}
