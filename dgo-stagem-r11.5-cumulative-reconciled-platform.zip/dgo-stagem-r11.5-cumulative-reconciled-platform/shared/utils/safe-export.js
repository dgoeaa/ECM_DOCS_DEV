/** Safe export helper: every user-visible export path must either complete, toast an empty state,
 *  or toast/log a failure. No swallowed exceptions. */
export async function safeExport({ type = 'export', filename = '', hasData = true, action, emptyMessage, failureMessage } = {}) {
  const P = globalThis.Platform || {};
  if (!hasData) {
    P.UI?.toast?.({ message: emptyMessage || 'There is no data to export.', variant: 'info' });
    return { ok: false, kind: 'EMPTY_EXPORT' };
  }
  if (typeof action !== 'function') {
    const message = 'Export action is not available.';
    P.UI?.toast?.({ message, variant: 'danger' });
    P.Log?.warn?.('export.missing-action', { type, filename });
    return { ok: false, kind: 'NO_ACTION', message };
  }
  try {
    const value = await action();
    return { ok: true, value };
  } catch (err) {
    const message = failureMessage || 'Export failed. Please try again.';
    P.Log?.warn?.('export.failed', { type, filename, message: String(err && err.message || err) });
    P.UI?.toast?.({ message, variant: 'danger' });
    return { ok: false, kind: 'EXPORT_FAILED', error: err };
  }
}
export default safeExport;
