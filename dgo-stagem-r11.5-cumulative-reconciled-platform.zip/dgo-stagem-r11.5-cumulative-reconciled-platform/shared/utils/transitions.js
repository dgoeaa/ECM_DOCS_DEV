/** Workflow transition compatibility helper.
 * Phase 7: delegates to shared/domain/workflow.js so legacy callers still work while workflow-facing
 * mutations are centralized through the domain wrapper. */
import { transitionReference } from '../domain/workflow.js';

export function transitionOrToast(ref, from, to, by) {
  const P = globalThis.Platform || {};
  const result = transitionReference(ref, from, to, by);
  if (!result.ok) {
    P.UI?.toast?.({ message: result.message || 'Status transition failed.', variant: 'danger' });
    P.Log?.warn?.('transition.failed', { ref, from, to, by, kind: result.kind || null, message: result.message || '' });
  }
  return result;
}
export default transitionOrToast;
