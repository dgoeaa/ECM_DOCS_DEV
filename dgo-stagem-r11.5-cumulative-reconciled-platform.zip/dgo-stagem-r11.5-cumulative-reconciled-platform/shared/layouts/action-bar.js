import { el } from '../utils/dom.js';export function actionBar(actions=[]){return el('div',{class:'ux-action-bar'},actions)}export default {actionBar};
