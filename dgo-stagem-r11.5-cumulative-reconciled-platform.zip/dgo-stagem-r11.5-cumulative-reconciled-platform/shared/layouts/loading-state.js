import { stateBlock } from './_layout-core.js';export const LoadingState={render:(title='Loading…',body='Preparing this workspace.')=>stateBlock('loading',title,body)};export default LoadingState;
