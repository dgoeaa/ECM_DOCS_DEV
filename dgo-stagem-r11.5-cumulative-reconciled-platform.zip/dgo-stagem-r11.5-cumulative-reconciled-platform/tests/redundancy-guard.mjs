import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const ownershipPath = path.join(root, 'config', 'feature-ownership.config.js');
if (!fs.existsSync(ownershipPath)) throw new Error('missing feature ownership config');

const modules = fs.readdirSync(path.join(root, 'modules')).filter((name) => fs.statSync(path.join(root, 'modules', name)).isDirectory());
const seenIds = new Map();
for (const name of modules) {
  const indexPath = path.join(root, 'modules', name, 'index.js');
  if (!fs.existsSync(indexPath)) continue;
  const source = fs.readFileSync(indexPath, 'utf8');
  const id = /static\s+id\s*=\s*['"]([^'"]+)['"]/.exec(source)?.[1];
  if (!id) throw new Error(`module ${name} has no static id`);
  if (seenIds.has(id)) throw new Error(`duplicate module id ${id}: ${seenIds.get(id)} and ${name}`);
  seenIds.set(id, name);
}

const serviceFiles = modules.map((name) => path.join(root, 'modules', name, 'service.js')).filter(fs.existsSync);
const missingDescriptor = serviceFiles.filter((file) => !/serviceDescriptor/.test(fs.readFileSync(file, 'utf8')));
if (missingDescriptor.length) {
  throw new Error(`service files missing serviceDescriptor: ${missingDescriptor.map((f) => path.relative(root, f)).join(', ')}`);
}

console.log('redundancy-guard: ok');
