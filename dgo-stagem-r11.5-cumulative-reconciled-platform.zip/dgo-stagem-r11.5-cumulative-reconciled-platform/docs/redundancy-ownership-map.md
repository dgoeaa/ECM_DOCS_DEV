# Stage M-R8.1 Redundancy Ownership Map

This document closes the duplication/redundancy observations before browser certification.

## Decision

No route-level module is deleted before browser testing. Redundancy is controlled through declared ownership, shared primitives, service descriptors, and certification guard checks.

## Rules

1. Each write workflow has one authoritative owner.
2. Lens/dashboard modules may overlap, but must not hide unowned write actions.
3. Shared workbench primitives are available for incremental adoption after browser screenshots pass.
4. Thin service wrappers must explicitly declare whether they are local, read-only, fabric-backed, or write-capable.
5. CSS/template consolidation must happen after browser verification, not before.

## Primary owners

- Bulk assignment: `bulk-assignment`
- Single assignment: `single-item-ops`
- Comment write: `comments`
- Reporting/export/send: `reports`
- Dispatch outbound: `dispatch`
- Settings/local config: `settings`
- Reference lookup: `lookup`
- Workflow orchestration lens: `orchestrator`

## Browser certification implication

Proceed to browser tests with all modules intact. During browser testing, report any duplicate action surface that causes operator confusion as a workflow defect.
