NITDA HTML Bundle (TEMPLATE)
==========================

Created: 2026-04-23T06:20:47

Why this is a template
----------------------
This ZIP is a scaffold listing all HTML pages you referenced. In this sandbox environment I can't reliably
reconstruct *all* full HTML source from earlier chat messages into files with 100% fidelity (some snippets are
very long and may be truncated/escaped when copied programmatically).

How to get an exact ZIP with the *complete original HTML* contents
------------------------------------------------------------------
Option A (best): Upload the original .html files here.
- If you upload the files, I will generate a new ZIP with the exact originals (and optionally a second folder
  with decoded versions if your pasted copies were HTML-escaped).

Option B: Paste each HTML again as plain text and tell me whether to preserve it exactly as pasted
(escaped entities like &lt; &gt;) OR to decode it into runnable HTML.

Files expected
--------------
See manifest.json for the exact list.
